"""Construit les calques du lecteur à partir de l'image de référence.

Sorties (dans ../app/ui/assets):
  plate.png   : boîtier recadré, zones dynamiques nettoyées
  reelL.png / reelR.png : bobines détourées (rotation CSS)
  icon.png + icon.ico   : icône de l'application
"""
import sys
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

SRC = Path(sys.argv[1])
OUT = Path(sys.argv[2])
OUT.mkdir(parents=True, exist_ok=True)

im = Image.open(SRC).convert("RGB")
A = np.asarray(im).astype(np.float32)


def is_lit(px):
    r, g, b = px[..., 0], px[..., 1], px[..., 2]
    lum = 0.3 * r + 0.59 * g + 0.11 * b
    orange = (r > 90) & (r - b > 45)
    bright = lum > 95
    return orange | bright


def clean_rect(a, x0, y0, x1, y1, pad=0, cols=None):
    """Remplit un rectangle ligne par ligne avec la médiane des pixels sombres."""
    reg = a[y0:y1, x0:x1]
    lit = is_lit(reg)
    out = reg.copy()
    for j in range(reg.shape[0]):
        row = reg[j]
        m = ~lit[j]
        sample = row[m] if m.sum() >= 4 else row
        # médiane des pixels les plus sombres (évite le halo orange)
        lum = sample.mean(1)
        k = max(4, len(sample) // 3)
        darkest = sample[np.argsort(lum)[:k]]
        out[j, :] = np.median(darkest, axis=0)
    a[y0:y1, x0:x1] = out


def blur_rect(a, x0, y0, x1, y1, r=1.2):
    img = Image.fromarray(a[y0:y1, x0:x1].clip(0, 255).astype(np.uint8))
    a[y0:y1, x0:x1] = np.asarray(img.filter(ImageFilter.GaussianBlur(r))).astype(np.float32)


P = A.copy()

# --- Afficheur principal : spectre + VU-mètres ---------------------------
clean_rect(P, 283, 121, 1388, 283)           # spectre
for (x0, y0, x1, y1) in [(103, 158, 198, 284), (103, 124, 166, 158),
                         (1476, 158, 1571, 284), (1512, 124, 1571, 158)]:
    clean_rect(P, x0, y0, x1, y1)

def calm(a, x0, y0, x1, y1, k=0.35, dark=0.8):
    reg = a[y0:y1, x0:x1]
    lum = reg.mean(2, keepdims=True)
    a[y0:y1, x0:x1] = (lum + (reg - lum) * k) * dark

for r in [(283, 121, 1388, 283), (103, 158, 198, 284), (103, 124, 166, 158),
          (1476, 158, 1571, 284), (1512, 124, 1571, 158)]:
    calm(P, *r)

# --- Bandeau "PLAYING" -----------------------------------------------------
clean_rect(P, 690, 104, 1000, 137)

# --- Panneau infos ---------------------------------------------------------
clean_rect(P, 136, 383, 347, 420)            # titre
for (y0, y1) in [(430, 464), (469, 502), (509, 543)]:
    clean_rect(P, 200, y0, 347, y1)          # valeurs
clean_rect(P, 86, 553, 340, 592)             # barre de progression
clean_rect(P, 90, 610, 336, 671)             # mini spectre
calm(P, 90, 610, 336, 671, 0.5, 0.85)
calm(P, 86, 553, 340, 592, 0.6, 0.9)

# --- LED REPEAT -> éteinte (copie de la LED SHUFFLE) ------------------------
led = A[722:756, 1376:1410].copy()
P[751:785, 1376:1410] = led

# --- Boutons : on efface icônes et libellés --------------------------------
BUTTONS = {
    "prev": (380, 547), "play": (558, 748), "pause": (762, 913),
    "stop": (927, 1107), "next": (1120, 1297),
}
BY0, BY1 = 709, 809
# Face de bouton éteinte de référence : STOP nettoyé
ref = A[BY0:BY1, 927:1108].copy()
tmp = ref.copy()
clean_rect(tmp, 12, 10, ref.shape[1] - 12, ref.shape[0] - 9)
ref_clean = tmp


def nine_slice(src, w, edge=16):
    h = src.shape[0]
    left, right = src[:, :edge], src[:, -edge:]
    mid = src[:, edge:-edge]
    mid_img = Image.fromarray(mid.clip(0, 255).astype(np.uint8)).resize((w - 2 * edge, h), Image.BICUBIC)
    return np.concatenate([left, np.asarray(mid_img).astype(np.float32), right], axis=1)


for name, (x0, x1) in BUTTONS.items():
    w = x1 - x0 + 1
    if name == "play":
        # le bouton PLAY est allumé dans l'image : on le remplace par une face éteinte
        face = nine_slice(ref_clean, w)
        # on garde la bordure extérieure (reflets) d'origine sur 3 px
        P[BY0 + 3:BY1 - 3, x0 + 3:x1 - 2] = face[3:-3, 3:-3]
    else:
        tmp = A[BY0:BY1, x0:x1 + 1].copy()
        clean_rect(tmp, 12, 10, w - 12, BY1 - BY0 - 9)
        P[BY0:BY1, x0:x1 + 1] = tmp

# halo orange résiduel du PLAY dans le cadre : on l'atténue légèrement
def desaturate(a, x0, y0, x1, y1, k=0.55):
    reg = a[y0:y1, x0:x1]
    lum = reg.mean(2, keepdims=True)
    a[y0:y1, x0:x1] = lum + (reg - lum) * k

desaturate(P, 548, 700, 760, 712)
desaturate(P, 548, 806, 760, 822)
desaturate(P, 548, 712, 562, 806)
desaturate(P, 744, 712, 762, 806)

# --- Libellés anglais du panneau infos (Track / Time / Total) ---------------
for (y0, y1) in [(430, 464), (469, 502), (509, 543)]:
    clean_rect(P, 134, y0, 200, y1)

# --- Libellés SHUFFLE / REPEAT / EQ -------------------------------------------
clean_rect(P, 1416, 726, 1527, 811)

# --- Plaque « STEREO CASSETTE DECK » (texte seulement, on garde le logo) -------
clean_rect(P, 1366, 431, 1578, 506)

# --- Intérieur de la cassette : bobinages et oscilloscope redessinés en direct --
CX0, CY0, CX1, CY1 = 402, 323, 1267, 592
h, w = CY1 - CY0, CX1 - CX0
ys = np.linspace(0, 1, h)[:, None]
xs = np.linspace(0, 1, w)[None, :]
top = np.array([16, 12, 13]); mid = np.array([30, 19, 15]); bot = np.array([21, 18, 22])
t = ys[..., None]
base = np.where(t < 0.5, top + (mid - top) * (t / 0.5), mid + (bot - mid) * ((t - 0.5) / 0.5))
base = np.broadcast_to(base, (h, w, 3)).astype(np.float32)
vign = (1 - 0.35 * (np.abs(xs - 0.5) * 2) ** 2)[..., None]
rng = np.random.default_rng(7)
noise = rng.normal(0, 1.4, (h, w, 1))
synth = base * vign + noise
# léger reflet diagonal (vitre)
diag = np.clip(1 - np.abs((xs * 0.8 + ys * 0.5) - 0.62) * 9, 0, 1)[..., None]
synth = synth + diag * 7
# fondu sur 6 px avec l'image d'origine
fe = 6
m = np.ones((h, w), np.float32)
for i in range(fe):
    v = (i + 1) / (fe + 1)
    m[i, :] = np.minimum(m[i, :], v); m[-1 - i, :] = np.minimum(m[-1 - i, :], v)
    m[:, i] = np.minimum(m[:, i], v); m[:, -1 - i] = np.minimum(m[:, -1 - i], v)
m = m[..., None]
P[CY0:CY1, CX0:CX1] = P[CY0:CY1, CX0:CX1] * (1 - m) + synth * m

# --- Recadrage du boîtier + coins arrondis ---------------------------------
CROP = (36, 76, 1638, 862)
plate = Image.fromarray(P.clip(0, 255).astype(np.uint8)).crop(CROP).convert("RGBA")
W, H = plate.size
mask = Image.new("L", (W * 4, H * 4), 0)
ImageDraw.Draw(mask).rounded_rectangle([4 * 4, 4 * 4, W * 4 - 4 * 4, H * 4 - 2 * 4], radius=36 * 4, fill=255)
mask = mask.resize((W, H), Image.LANCZOS)
plate.putalpha(mask)
plate.save(OUT / "plate.png", optimize=True)
print("plate", plate.size)

# --- Bobines détourées ------------------------------------------------------
def reel(cx, cy, name, r_in=106, r_out=114):
    R = r_out + 2
    crop = im.crop((cx - R, cy - R, cx + R, cy + R)).convert("RGBA")
    s = 8
    m = Image.new("L", (2 * R * s, 2 * R * s), 0)
    d = ImageDraw.Draw(m)
    for i in range(r_out - r_in + 1):
        rr = r_out - i
        v = int(255 * (i / (r_out - r_in)))
        d.ellipse([(R - rr) * s, (R - rr) * s, (R + rr) * s, (R + rr) * s], fill=v)
    m = m.resize((2 * R, 2 * R), Image.LANCZOS)
    crop.putalpha(m)
    crop.save(OUT / f"{name}.png", optimize=True)
    return crop

reel(592, 455, "reelL")
reel(1087, 455, "reelR")

# --- Icône ------------------------------------------------------------------
ic = im.crop((592 - 140, 455 - 140, 592 + 140, 455 + 140)).convert("RGBA")
S = 256
ic = ic.resize((S, S), Image.LANCZOS)
bg = Image.new("RGBA", (S, S), (0, 0, 0, 0))
m = Image.new("L", (S * 4, S * 4), 0)
ImageDraw.Draw(m).rounded_rectangle([8, 8, S * 4 - 8, S * 4 - 8], radius=56 * 4, fill=255)
m = m.resize((S, S), Image.LANCZOS)
bg.paste(ic, (0, 0), m)
d = ImageDraw.Draw(bg)
d.rounded_rectangle([4, 4, S - 5, S - 5], radius=56, outline=(255, 140, 20, 255), width=8)
bg.save(OUT / "icon.png")
bg.save(OUT / "icon.ico", sizes=[(16, 16), (24, 24), (32, 32), (48, 48), (64, 64), (128, 128), (256, 256)])
print("ok")

# --- Icônes de la miniature de la barre des tâches -------------------------
def glyph(kind, S=64):
    g = Image.new("RGBA", (S, S), (0, 0, 0, 0))
    d = ImageDraw.Draw(g)
    c = (255, 255, 255, 255)
    u = S / 32
    if kind == "play":
        d.polygon([(9 * u, 6 * u), (26 * u, 16 * u), (9 * u, 26 * u)], fill=c)
    elif kind == "pause":
        d.rectangle([8 * u, 6 * u, 13 * u, 26 * u], fill=c); d.rectangle([19 * u, 6 * u, 24 * u, 26 * u], fill=c)
    elif kind == "prev":
        d.rectangle([5 * u, 7 * u, 8 * u, 25 * u], fill=c)
        d.polygon([(18 * u, 7 * u), (8 * u, 16 * u), (18 * u, 25 * u)], fill=c)
        d.polygon([(28 * u, 7 * u), (18 * u, 16 * u), (28 * u, 25 * u)], fill=c)
    elif kind == "next":
        d.polygon([(4 * u, 7 * u), (14 * u, 16 * u), (4 * u, 25 * u)], fill=c)
        d.polygon([(14 * u, 7 * u), (24 * u, 16 * u), (14 * u, 25 * u)], fill=c)
        d.rectangle([24 * u, 7 * u, 27 * u, 25 * u], fill=c)
    return g

RES = OUT.parent.parent.parent / "res"
if RES.exists():
    for k in ("prev", "play", "pause", "next"):
        glyph(k, 256).save(RES / f"tb_{k}.ico", sizes=[(16, 16), (20, 20), (24, 24), (32, 32), (48, 48)])
    print("icônes miniature ok")
