"""Faux serveur Icecast/Shoutcast pour tester la radio.

/live.mp3      : HTTP/1.0 200 + icy-metaint (titre qui change toutes les 5 s)
/shout         : réponse « ICY 200 OK » (vieux Shoutcast)
/list.pls      : liste .pls pointant vers /live.mp3
/hls.m3u8      : liste HLS (doit être refusée)
"""
import socketserver, sys, time

MP3 = open(sys.argv[1], "rb").read()
METAINT = 8192
PORT = int(sys.argv[2])


class H(socketserver.StreamRequestHandler):
    def handle(self):
        line = self.rfile.readline().decode()
        hdrs = {}
        while True:
            l = self.rfile.readline().decode().strip()
            if not l:
                break
            k, _, v = l.partition(":")
            hdrs[k.lower()] = v.strip()
        path = line.split()[1]
        w = self.wfile
        if path == "/list.pls":
            body = f"[playlist]\nNumberOfEntries=1\nFile1=http://127.0.0.1:{PORT}/live.mp3\nTitle1=Test\n".encode()
            w.write(b"HTTP/1.0 200 OK\r\nContent-Type: audio/x-scpls\r\nContent-Length: %d\r\n\r\n" % len(body) + body)
            return
        if path == "/hls.m3u8":
            body = b"#EXTM3U\n#EXT-X-VERSION:3\n#EXT-X-TARGETDURATION:10\nseg1.ts\n"
            w.write(b"HTTP/1.0 200 OK\r\nContent-Type: application/vnd.apple.mpegurl\r\n\r\n" + body)
            return
        status = b"ICY 200 OK" if path == "/shout" else b"HTTP/1.0 200 OK"
        meta = hdrs.get("icy-metadata") == "1"
        w.write(status + b"\r\nContent-Type: audio/mpeg\r\nicy-name: Radio Test FM\r\n")
        if meta:
            w.write(b"icy-metaint: %d\r\n" % METAINT)
        w.write(b"\r\n")
        pos, t0, n = 0, time.time(), 0
        try:
            while True:
                chunk = MP3[pos:pos + METAINT]
                if len(chunk) < METAINT:
                    pos = 0
                    chunk = MP3[:METAINT]
                pos += METAINT
                w.write(chunk)
                if meta:
                    title = f"StreamTitle='Artiste Été {int((time.time()-t0)//5)} - Morceau';".encode("latin-1")
                    title += b"\0" * (-len(title) % 16)
                    w.write(bytes([len(title) // 16]) + title)
                n += 1
                time.sleep(METAINT / 24000)  # ~192 kbit/s
        except (BrokenPipeError, ConnectionResetError):
            pass


class S(socketserver.ThreadingTCPServer):
    allow_reuse_address = True
    daemon_threads = True


S(("127.0.0.1", PORT), H).serve_forever()
