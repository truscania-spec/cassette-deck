// Cassette Deck — mini lecteur audio.
//
// Le programme embarque l'interface (HTML/CSS/JS), la sert sur 127.0.0.1
// et l'ouvre dans une fenêtre application de Microsoft Edge (WebView du
// système). Le son, l'analyse spectrale et les VU-mètres passent par la
// Web Audio API de cette fenêtre.
package main

import (
	"bytes"
	"crypto/rand"
	"embed"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io/fs"
	"log"
	"net"
	"net/http"
	"os"
	"path/filepath"
	"sort"
	"strconv"
	"strings"
	"sync"
	"time"
)

const (
	AppName    = "Cassette Deck"
	AppID      = "CassetteDeck"
	AppVersion = "2.1.0"
	maxTracks  = 5000
)

//go:embed ui
var uiFS embed.FS

var audioExt = map[string]bool{
	".mp3": true, ".flac": true, ".wav": true, ".ogg": true, ".oga": true,
	".opus": true, ".m4a": true, ".aac": true, ".webm": true, ".mp4": true,
}

// ---------------------------------------------------------------------------
// Bibliothèque

type Track struct {
	ID     int    `json:"id"`
	Title  string `json:"title"`
	Artist string `json:"artist"`
	Path   string `json:"-"`
	meta   bool
}

type Library struct {
	mu       sync.Mutex
	tracks   []*Track
	rev      int
	nextID   int
	playFrom int // id à lancer après un ajout externe (-1 = aucun)
}

var lib = &Library{playFrom: -1}

func (l *Library) set(paths []string, appendMode bool, playFirst bool) {
	l.mu.Lock()
	defer l.mu.Unlock()
	if !appendMode {
		l.tracks = nil
	}
	first := -1
	for _, p := range paths {
		if len(l.tracks) >= maxTracks {
			break
		}
		l.nextID++
		t := &Track{ID: l.nextID, Path: p, Title: titleFromName(p)}
		if first < 0 {
			first = t.ID
		}
		l.tracks = append(l.tracks, t)
	}
	if playFirst && first >= 0 {
		l.playFrom = first
	}
	l.rev++
	go saveConfig()
}

func (l *Library) paths() []string {
	l.mu.Lock()
	defer l.mu.Unlock()
	out := make([]string, 0, len(l.tracks))
	for _, t := range l.tracks {
		out = append(out, t.Path)
	}
	return out
}

func (l *Library) get(id int) *Track {
	l.mu.Lock()
	defer l.mu.Unlock()
	for _, t := range l.tracks {
		if t.ID == id {
			return t
		}
	}
	return nil
}

func titleFromName(p string) string {
	b := filepath.Base(p)
	b = strings.TrimSuffix(b, filepath.Ext(b))
	b = strings.ReplaceAll(b, "_", " ")
	return strings.TrimSpace(b)
}

// expand transforme une liste de fichiers/dossiers en liste de pistes audio.
func expand(inputs []string) []string {
	var out []string
	for _, in := range inputs {
		in = strings.TrimSpace(strings.Trim(in, "\""))
		if in == "" {
			continue
		}
		st, err := os.Stat(in)
		if err != nil {
			continue
		}
		if !st.IsDir() {
			if audioExt[strings.ToLower(filepath.Ext(in))] {
				out = append(out, in)
			}
			continue
		}
		var found []string
		filepath.WalkDir(in, func(p string, d fs.DirEntry, err error) error {
			if err != nil {
				return nil
			}
			if d.IsDir() {
				if strings.HasPrefix(d.Name(), ".") && p != in {
					return filepath.SkipDir
				}
				return nil
			}
			if audioExt[strings.ToLower(filepath.Ext(p))] {
				found = append(found, p)
			}
			if len(found) >= maxTracks {
				return fs.SkipAll
			}
			return nil
		})
		sort.Slice(found, func(i, j int) bool { return strings.ToLower(found[i]) < strings.ToLower(found[j]) })
		out = append(out, found...)
	}
	return out
}

// ---------------------------------------------------------------------------
// Configuration persistante

type Config struct {
	Paths []string `json:"paths"`
}

func dataDir() string {
	base, err := os.UserCacheDir() // %LOCALAPPDATA% sous Windows
	if err != nil {
		base = os.TempDir()
	}
	d := filepath.Join(base, AppID)
	os.MkdirAll(d, 0o755)
	return d
}

var cfgMu sync.Mutex

func saveConfig() {
	cfgMu.Lock()
	defer cfgMu.Unlock()
	b, _ := json.MarshalIndent(Config{Paths: lib.paths()}, "", "  ")
	os.WriteFile(filepath.Join(dataDir(), "playlist.json"), b, 0o644)
}

func loadConfig() []string {
	b, err := os.ReadFile(filepath.Join(dataDir(), "playlist.json"))
	if err != nil {
		return nil
	}
	var c Config
	if json.Unmarshal(b, &c) != nil {
		return nil
	}
	var ok []string
	for _, p := range c.Paths {
		if _, err := os.Stat(p); err == nil {
			ok = append(ok, p)
		}
	}
	return ok
}

func defaultMusicDir() string {
	home, _ := os.UserHomeDir()
	for _, n := range []string{"Music", "Musique"} {
		d := filepath.Join(home, n)
		if st, err := os.Stat(d); err == nil && st.IsDir() {
			return d
		}
	}
	return ""
}

// ---------------------------------------------------------------------------
// Instance unique

type instanceInfo struct {
	Port  int    `json:"port"`
	Token string `json:"token"`
	PID   int    `json:"pid"`
}

func instanceFile() string { return filepath.Join(dataDir(), "instance.json") }

// forwardToRunning envoie les fichiers à une instance déjà ouverte.
func forwardToRunning(paths []string) bool {
	b, err := os.ReadFile(instanceFile())
	if err != nil {
		return false
	}
	var inf instanceInfo
	if json.Unmarshal(b, &inf) != nil || inf.Port == 0 {
		return false
	}
	body, _ := json.Marshal(paths)
	c := &http.Client{Timeout: 3 * time.Second}
	u := fmt.Sprintf("http://127.0.0.1:%d/api/add?t=%s", inf.Port, inf.Token)
	resp, err := c.Post(u, "application/json", bytes.NewReader(body))
	if err != nil {
		return false
	}
	defer resp.Body.Close()
	var res struct {
		Alive bool `json:"alive"`
	}
	if resp.StatusCode != 200 || json.NewDecoder(resp.Body).Decode(&res) != nil {
		return false
	}
	if !res.Alive {
		// serveur orphelin (fenêtre disparue) : on l'arrête et on repart à neuf
		if r2, err := c.Get(fmt.Sprintf("http://127.0.0.1:%d/api/quit?t=%s", inf.Port, inf.Token)); err == nil {
			r2.Body.Close()
		}
		time.Sleep(600 * time.Millisecond)
		return false
	}
	return true
}

// ---------------------------------------------------------------------------
// Serveur HTTP

var (
	token    string
	beatMu   sync.Mutex
	lastBeat time.Time
	everBeat bool
	openMu   sync.Mutex
)

var (
	nativeActive bool     // fenêtre native WebView2 en service
	forceMode    string   // --native / --edge
	startHidden  bool     // --tray : démarrage réduit dans la zone de notification
	exitHooks    []func() // nettoyage avant sortie (icône de notification…)
)

func beat() {
	beatMu.Lock()
	first := !everBeat
	lastBeat = time.Now()
	everBeat = true
	beatMu.Unlock()
	if first {
		go firstBeat()
	}
}

// waitHeartbeats garde le serveur en vie tant que la page donne signe de vie
// (cas où le navigateur rend la main tout de suite).
func waitHeartbeats(start time.Time) {
	if time.Since(start) >= 15*time.Second {
		return
	}
	for {
		time.Sleep(5 * time.Second)
		beatMu.Lock()
		lb, eb := lastBeat, everBeat
		beatMu.Unlock()
		if eb && time.Since(lb) > 150*time.Second {
			return
		}
		if !eb && time.Since(start) > 90*time.Second {
			return
		}
	}
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json; charset=utf-8")
	w.Header().Set("Cache-Control", "no-store")
	json.NewEncoder(w).Encode(v)
}

func libraryPayload() map[string]any {
	lib.mu.Lock()
	defer lib.mu.Unlock()
	list := make([]map[string]any, 0, len(lib.tracks))
	for _, t := range lib.tracks {
		list = append(list, map[string]any{"id": t.ID, "title": t.Title, "artist": t.Artist})
	}
	pf := lib.playFrom
	lib.playFrom = -1
	return map[string]any{"rev": lib.rev, "tracks": list, "playFrom": pf}
}

func authed(h http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		if r.URL.Query().Get("t") != token {
			http.Error(w, "forbidden", http.StatusForbidden)
			return
		}
		h(w, r)
	}
}

func routes() http.Handler {
	mux := http.NewServeMux()
	sub, _ := fs.Sub(uiFS, "ui")
	static := http.FileServer(http.FS(sub))
	mux.Handle("/", http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Cache-Control", "no-cache")
		static.ServeHTTP(w, r)
	}))

	// Liste de lecture (sert aussi de battement de cœur)
	mux.HandleFunc("/api/library", authed(func(w http.ResponseWriter, r *http.Request) {
		beat()
		rev, _ := strconv.Atoi(r.URL.Query().Get("rev"))
		lib.mu.Lock()
		same := rev == lib.rev && lib.playFrom < 0
		cur := lib.rev
		lib.mu.Unlock()
		if same && r.URL.Query().Has("rev") {
			writeJSON(w, map[string]any{"rev": cur, "unchanged": true})
			return
		}
		writeJSON(w, libraryPayload())
	}))

	// Métadonnées d'une piste (tags ID3 / Vorbis lus à la demande)
	mux.HandleFunc("/api/meta", authed(func(w http.ResponseWriter, r *http.Request) {
		id, _ := strconv.Atoi(r.URL.Query().Get("id"))
		t := lib.get(id)
		if t == nil {
			http.NotFound(w, r)
			return
		}
		if !t.meta {
			title, artist := readTags(t.Path)
			lib.mu.Lock()
			if title != "" {
				t.Title = title
			}
			t.Artist = artist
			t.meta = true
			lib.mu.Unlock()
		}
		writeJSON(w, map[string]any{"id": t.ID, "title": t.Title, "artist": t.Artist})
	}))

	// Boîte de dialogue native : fichiers ou dossier
	mux.HandleFunc("/api/open", authed(func(w http.ResponseWriter, r *http.Request) {
		if r.Method != http.MethodPost {
			http.Error(w, "POST", http.StatusMethodNotAllowed)
			return
		}
		openMu.Lock()
		defer openMu.Unlock()
		mode := r.URL.Query().Get("mode")
		appendMode := r.URL.Query().Get("append") == "1"
		picked, err := pickDialog(mode)
		if err != nil {
			writeJSON(w, map[string]any{"error": err.Error()})
			return
		}
		paths := expand(picked)
		if len(paths) == 0 {
			writeJSON(w, map[string]any{"cancelled": true})
			return
		}
		lib.set(paths, appendMode, true)
		writeJSON(w, libraryPayload())
	}))

	// Ajout depuis une 2e instance (« Ouvrir avec… »)
	mux.HandleFunc("/api/add", authed(func(w http.ResponseWriter, r *http.Request) {
		var in []string
		json.NewDecoder(r.Body).Decode(&in)
		paths := expand(in)
		if len(paths) > 0 {
			lib.set(paths, true, true)
		}
		beatMu.Lock()
		alive := everBeat && time.Since(lastBeat) < 75*time.Second
		beatMu.Unlock()
		if alive {
			hostCommand("show", nil)
		}
		writeJSON(w, map[string]any{"ok": true, "alive": alive})
	}))

	mux.HandleFunc("/api/clear", authed(func(w http.ResponseWriter, r *http.Request) {
		lib.set(nil, false, false)
		writeJSON(w, libraryPayload())
	}))

	mux.HandleFunc("/api/remove", authed(func(w http.ResponseWriter, r *http.Request) {
		id, _ := strconv.Atoi(r.URL.Query().Get("id"))
		lib.mu.Lock()
		for i, t := range lib.tracks {
			if t.ID == id {
				lib.tracks = append(lib.tracks[:i], lib.tracks[i+1:]...)
				break
			}
		}
		lib.rev++
		lib.mu.Unlock()
		go saveConfig()
		writeJSON(w, libraryPayload())
	}))

	mux.HandleFunc("/api/reveal", authed(func(w http.ResponseWriter, r *http.Request) {
		id, _ := strconv.Atoi(r.URL.Query().Get("id"))
		if t := lib.get(id); t != nil {
			revealInExplorer(t.Path)
		}
		writeJSON(w, map[string]any{"ok": true})
	}))

	mux.HandleFunc("/api/bye", authed(func(w http.ResponseWriter, r *http.Request) {
		at := time.Now()
		w.WriteHeader(http.StatusNoContent)
		if nativeActive { // la fenêtre native gère elle-même sa fermeture
			return
		}
		go func() {
			time.Sleep(2500 * time.Millisecond)
			beatMu.Lock()
			lb := lastBeat
			beatMu.Unlock()
			if lb.Before(at) { // pas de rechargement de la page entre-temps
				shutdown(0)
			}
		}()
	}))

	radioRoutes(mux)
	recordRoutes(mux)
	updateRoutes(mux)
	eventRoutes(mux)
	mux.HandleFunc("/api/cover", authed(handleCover))

	mux.HandleFunc("/api/quit", authed(func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, map[string]any{"ok": true})
		go func() { time.Sleep(300 * time.Millisecond); shutdown(0) }()
	}))

	// Flux audio (gère les requêtes Range pour la recherche)
	mux.HandleFunc("/media/", authed(func(w http.ResponseWriter, r *http.Request) {
		id, _ := strconv.Atoi(strings.TrimPrefix(r.URL.Path, "/media/"))
		t := lib.get(id)
		if t == nil {
			http.NotFound(w, r)
			return
		}
		f, err := os.Open(t.Path)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		defer f.Close()
		st, _ := f.Stat()
		if ct := mimeFor(t.Path); ct != "" {
			w.Header().Set("Content-Type", ct)
		}
		http.ServeContent(w, r, "", st.ModTime(), f)
	}))
	return mux
}

func mimeFor(p string) string {
	switch strings.ToLower(filepath.Ext(p)) {
	case ".mp3":
		return "audio/mpeg"
	case ".flac":
		return "audio/flac"
	case ".wav":
		return "audio/wav"
	case ".ogg", ".oga":
		return "audio/ogg"
	case ".opus":
		return "audio/ogg; codecs=opus"
	case ".m4a", ".mp4", ".aac":
		return "audio/mp4"
	case ".webm":
		return "audio/webm"
	}
	return ""
}

func shutdown(code int) {
	for _, h := range exitHooks {
		h()
	}
	os.Remove(instanceFile())
	os.Exit(code)
}

func newToken() string {
	b := make([]byte, 16)
	rand.Read(b)
	return hex.EncodeToString(b)
}

// ---------------------------------------------------------------------------

func main() {
	log.SetFlags(0)
	args := os.Args[1:]
	noUI := false
	var files []string
	for _, a := range args {
		switch strings.ToLower(a) {
		case "--uninstall", "/uninstall":
			uninstall()
			return
		case "--no-ui":
			noUI = true
		case "--tray":
			startHidden = true
		case "--native":
			forceMode = "natif"
		case "--edge":
			forceMode = "edge"
		case "--restart":
			time.Sleep(1500 * time.Millisecond)
		default:
			files = append(files, a)
		}
	}

	// Une instance tourne déjà : on lui confie les fichiers et on la ramène devant.
	if forwardToRunning(files) {
		return
	}

	token = newToken()
	if v := os.Getenv("CASSETTE_TOKEN"); v != "" { // pour les tests
		token = v
	}

	// Liste initiale : arguments > dernière liste > dossier Musique
	var initial []string
	if len(files) > 0 {
		initial = expand(files)
	}
	if len(initial) == 0 {
		initial = loadConfig()
	}
	if len(initial) == 0 {
		if d := defaultMusicDir(); d != "" {
			initial = expand([]string{d})
		}
	}
	lib.set(initial, false, len(files) > 0)

	addr := "127.0.0.1:0"
	if v := os.Getenv("CASSETTE_PORT"); v != "" {
		addr = "127.0.0.1:" + v
	}
	ln, err := net.Listen("tcp", addr)
	if err != nil {
		fatal("Impossible d'ouvrir le serveur local : " + err.Error())
	}
	port := ln.Addr().(*net.TCPAddr).Port
	inf, _ := json.Marshal(instanceInfo{Port: port, Token: token, PID: os.Getpid()})
	os.WriteFile(instanceFile(), inf, 0o644)

	srv := &http.Server{Handler: routes(), ReadHeaderTimeout: 10 * time.Second}
	go func() {
		if err := srv.Serve(ln); err != nil && !errors.Is(err, http.ErrServerClosed) {
			fatal(err.Error())
		}
	}()

	url := fmt.Sprintf("http://127.0.0.1:%d/index.html?t=%s", port, token)
	go updateLoop()
	if noUI {
		log.Println(url)
		select {}
	}

	os.Setenv("WEBVIEW2_ADDITIONAL_BROWSER_ARGUMENTS", "--autoplay-policy=no-user-gesture-required")
	runUI(url, filepath.Join(dataDir(), "EdgeProfile"))
	shutdown(0)
}

func fatal(msg string) {
	messageBox(AppName, msg, mbIconError)
	shutdown(1)
}
