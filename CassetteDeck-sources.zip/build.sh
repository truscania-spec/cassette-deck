#!/bin/sh
# Compile le lecteur puis l'installateur Windows (depuis Linux, macOS ou Windows, Go 1.22+).
#
# Mises à jour automatiques :
#   keys/update_public.txt  clé publique (créée par : go run ./tools/release genkey keys)
#   update_url.txt          adresse HTTPS du fichier latest.json publié
set -e
cd "$(dirname "$0")"
LDX=""
if [ -f keys/update_public.txt ] && [ -f update_url.txt ]; then
  LDX="-X main.UpdatePubKey=$(tr -d ' \r\n' < keys/update_public.txt) -X main.UpdateURL=$(tr -d ' \r\n' < update_url.txt)"
  echo "Mises à jour : $(tr -d '\r\n' < update_url.txt)"
else
  echo "Mises à jour automatiques non configurées (keys/update_public.txt et update_url.txt absents)."
fi
cp res/app.syso app/rsrc_windows_amd64.syso
cp res/setup.syso setup/rsrc_windows_amd64.syso
mkdir -p setup/payload dist
(cd app && GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-H windowsgui -s -w $LDX" -o ../setup/payload/CassetteDeck.exe .)
(cd setup && GOOS=windows GOARCH=amd64 CGO_ENABLED=0 go build -trimpath -ldflags "-H windowsgui -s -w" -o ../dist/CassetteDeck-Setup.exe .)
cp setup/payload/CassetteDeck.exe dist/CassetteDeck.exe
ls -la dist
