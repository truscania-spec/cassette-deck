module cassettedeck

go 1.22
