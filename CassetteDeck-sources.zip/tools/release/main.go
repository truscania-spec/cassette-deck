// Outil de publication des mises à jour de Cassette Deck.
//
// 1) Une seule fois — créer la paire de clés de signature :
//
//	go run ./tools/release genkey keys
//	  -> keys/update_private.key  (SECRET : ne jamais publier ni partager)
//	  -> keys/update_public.txt   (intégrée au lecteur lors de la compilation)
//
// 2) À chaque nouvelle version — signer l'installateur :
//
//	go run ./tools/release sign -key keys/update_private.key -version 2.2.0 \
//	    -url https://…/CassetteDeck-Setup.exe -notes notes.txt \
//	    -out dist/latest.json dist/CassetteDeck-Setup.exe
//
// Publiez ensuite latest.json et CassetteDeck-Setup.exe aux adresses prévues.
package main

import (
	"crypto/ed25519"
	"crypto/rand"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"flag"
	"fmt"
	"io"
	"os"
	"path/filepath"
	"strconv"
	"strings"
)

type manifest struct {
	Version string `json:"version"`
	URL     string `json:"url"`
	SHA256  string `json:"sha256"`
	Size    int64  `json:"size"`
	Notes   string `json:"notes"`
	Sig     string `json:"sig"`
}

func die(f string, a ...any) {
	fmt.Fprintf(os.Stderr, f+"\n", a...)
	os.Exit(1)
}

func main() {
	if len(os.Args) < 2 {
		die("usage : release genkey <dossier> | release sign [options] <installateur.exe>")
	}
	switch os.Args[1] {
	case "genkey":
		dir := "keys"
		if len(os.Args) > 2 {
			dir = os.Args[2]
		}
		priv := filepath.Join(dir, "update_private.key")
		if _, err := os.Stat(priv); err == nil {
			die("%s existe déjà : refus de l'écraser (vous perdriez la possibilité de mettre à jour les lecteurs installés).", priv)
		}
		pub, pk, err := ed25519.GenerateKey(rand.Reader)
		if err != nil {
			die("%v", err)
		}
		os.MkdirAll(dir, 0o700)
		os.WriteFile(priv, []byte(base64.StdEncoding.EncodeToString(pk)+"\n"), 0o600)
		os.WriteFile(filepath.Join(dir, "update_public.txt"), []byte(base64.StdEncoding.EncodeToString(pub)+"\n"), 0o644)
		fmt.Println("Clés créées dans", dir, "— conservez update_private.key en lieu sûr (sauvegarde hors ligne).")

	case "sign":
		fs := flag.NewFlagSet("sign", flag.ExitOnError)
		key := fs.String("key", "keys/update_private.key", "clé privée")
		version := fs.String("version", "", "version publiée (ex. 2.2.0)")
		url := fs.String("url", "", "adresse HTTPS de téléchargement de l'installateur")
		notes := fs.String("notes", "", "fichier texte des nouveautés (facultatif)")
		out := fs.String("out", "latest.json", "fichier manifeste produit")
		local := fs.Bool("local", false, "autoriser http://127.0.0.1 (tests uniquement)")
		fs.Parse(os.Args[2:])
		okURL := strings.HasPrefix(*url, "https://") || (*local && strings.HasPrefix(*url, "http://127.0.0.1"))
		if fs.NArg() != 1 || *version == "" || !okURL {
			die("usage : release sign -version X.Y.Z -url https://… [-notes notes.txt] [-out latest.json] installateur.exe")
		}
		kb, err := os.ReadFile(*key)
		if err != nil {
			die("clé privée introuvable : %v", err)
		}
		pk, err := base64.StdEncoding.DecodeString(strings.TrimSpace(string(kb)))
		if err != nil || len(pk) != ed25519.PrivateKeySize {
			die("clé privée invalide")
		}
		f, err := os.Open(fs.Arg(0))
		if err != nil {
			die("%v", err)
		}
		h := sha256.New()
		n, _ := io.Copy(h, f)
		f.Close()
		m := manifest{Version: *version, URL: *url, SHA256: hex.EncodeToString(h.Sum(nil)), Size: n}
		if *notes != "" {
			b, err := os.ReadFile(*notes)
			if err != nil {
				die("%v", err)
			}
			m.Notes = strings.TrimSpace(string(b))
		}
		signed := m.Version + "\n" + m.URL + "\n" + m.SHA256 + "\n" + strconv.FormatInt(m.Size, 10)
		m.Sig = base64.StdEncoding.EncodeToString(ed25519.Sign(ed25519.PrivateKey(pk), []byte(signed)))
		b, _ := json.MarshalIndent(m, "", "  ")
		if err := os.WriteFile(*out, append(b, '\n'), 0o644); err != nil {
			die("%v", err)
		}
		fmt.Printf("%s signé : version %s, %d octets, sha256 %s…\n", *out, m.Version, m.Size, m.SHA256[:16])
	default:
		die("commande inconnue : %s", os.Args[1])
	}
}
