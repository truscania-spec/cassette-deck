package main

// Pochettes : image intégrée (ID3 APIC/PIC, FLAC PICTURE) ou image du dossier
// (cover.jpg, folder.jpg…).

import (
	"bytes"
	"encoding/binary"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
)

type coverData struct {
	data []byte
	mime string
}

var (
	coverMu    sync.Mutex
	coverCache = map[string]*coverData{} // clé : chemin du fichier audio
)

func sniffMime(b []byte) string {
	switch {
	case len(b) > 3 && b[0] == 0xFF && b[1] == 0xD8:
		return "image/jpeg"
	case len(b) > 8 && string(b[1:4]) == "PNG":
		return "image/png"
	case len(b) > 12 && string(b[8:12]) == "WEBP":
		return "image/webp"
	case len(b) > 4 && string(b[:3]) == "GIF":
		return "image/gif"
	}
	return http.DetectContentType(b)
}

func readCover(path string) *coverData {
	coverMu.Lock()
	if c, ok := coverCache[path]; ok {
		coverMu.Unlock()
		return c
	}
	coverMu.Unlock()

	var c *coverData
	if b := embeddedCover(path); len(b) > 0 {
		c = &coverData{b, sniffMime(b)}
	} else if b := folderCover(filepath.Dir(path)); len(b) > 0 {
		c = &coverData{b, sniffMime(b)}
	}
	coverMu.Lock()
	if len(coverCache) > 300 {
		coverCache = map[string]*coverData{}
	}
	coverCache[path] = c
	coverMu.Unlock()
	return c
}

func folderCover(dir string) []byte {
	ents, err := os.ReadDir(dir)
	if err != nil {
		return nil
	}
	pref := []string{"cover", "folder", "front", "album", "albumart"}
	best, bestRank := "", 99
	for _, e := range ents {
		if e.IsDir() {
			continue
		}
		n := strings.ToLower(e.Name())
		ext := filepath.Ext(n)
		if ext != ".jpg" && ext != ".jpeg" && ext != ".png" && ext != ".webp" {
			continue
		}
		base := strings.TrimSuffix(n, ext)
		for i, p := range pref {
			if base == p || strings.HasPrefix(base, p) {
				if i < bestRank {
					best, bestRank = e.Name(), i
				}
				break
			}
		}
	}
	if best == "" {
		return nil
	}
	b, err := os.ReadFile(filepath.Join(dir, best))
	if err != nil || len(b) > 20<<20 {
		return nil
	}
	return b
}

func embeddedCover(path string) []byte {
	f, err := os.Open(path)
	if err != nil {
		return nil
	}
	defer f.Close()
	head := make([]byte, 10)
	if _, err := io.ReadFull(f, head); err != nil {
		return nil
	}
	switch {
	case string(head[:3]) == "ID3":
		return id3Picture(f, head)
	case string(head[:4]) == "fLaC":
		f.Seek(4, io.SeekStart)
		return flacPicture(f)
	}
	return nil
}

func id3Picture(f *os.File, head []byte) []byte {
	ver := head[3]
	size := synchsafe(head[6:10])
	if size > 24<<20 {
		return nil
	}
	data := make([]byte, size)
	n, _ := io.ReadFull(f, data)
	data = data[:n]
	if head[5]&0x80 != 0 { // désynchronisation globale (v2.3)
		data = bytes.ReplaceAll(data, []byte{0xFF, 0x00}, []byte{0xFF})
	}
	pos := 0
	if head[5]&0x40 != 0 && len(data) >= 4 {
		if ver == 4 {
			pos = synchsafe(data[:4])
		} else {
			pos = int(binary.BigEndian.Uint32(data[:4])) + 4
		}
	}
	idLen, hdrLen := 4, 10
	if ver == 2 {
		idLen, hdrLen = 3, 6
	}
	var fallback []byte
	for pos+hdrLen <= len(data) {
		id := string(data[pos : pos+idLen])
		if id[0] == 0 {
			break
		}
		var fsize int
		switch ver {
		case 2:
			fsize = int(data[pos+3])<<16 | int(data[pos+4])<<8 | int(data[pos+5])
		case 4:
			fsize = synchsafe(data[pos+4 : pos+8])
		default:
			fsize = int(binary.BigEndian.Uint32(data[pos+4 : pos+8]))
		}
		pos += hdrLen
		if fsize <= 0 || pos+fsize > len(data) {
			break
		}
		body := data[pos : pos+fsize]
		pos += fsize
		if id != "APIC" && id != "PIC" || len(body) < 4 {
			continue
		}
		enc := body[0]
		p := 1
		if id == "PIC" {
			p += 3 // format sur 3 octets
		} else {
			i := bytes.IndexByte(body[p:], 0)
			if i < 0 {
				continue
			}
			p += i + 1
		}
		if p >= len(body) {
			continue
		}
		ptype := body[p]
		p++
		// description terminée par 0 (ou 00 00 en UTF-16)
		if enc == 1 || enc == 2 {
			for p+1 < len(body) && !(body[p] == 0 && body[p+1] == 0) {
				p += 2
			}
			p += 2
		} else {
			i := bytes.IndexByte(body[p:], 0)
			if i < 0 {
				continue
			}
			p += i + 1
		}
		if p >= len(body) {
			continue
		}
		img := body[p:]
		if ptype == 3 { // couverture avant
			return img
		}
		if fallback == nil {
			fallback = img
		}
	}
	return fallback
}

func flacPicture(f *os.File) []byte {
	hdr := make([]byte, 4)
	for i := 0; i < 128; i++ {
		if _, err := io.ReadFull(f, hdr); err != nil {
			return nil
		}
		last := hdr[0]&0x80 != 0
		typ := hdr[0] & 0x7f
		size := int(hdr[1])<<16 | int(hdr[2])<<8 | int(hdr[3])
		if typ == 6 && size < 24<<20 {
			b := make([]byte, size)
			if _, err := io.ReadFull(f, b); err != nil {
				return nil
			}
			return parseFlacPicture(b)
		}
		if _, err := f.Seek(int64(size), io.SeekCurrent); err != nil || last {
			return nil
		}
	}
	return nil
}

func parseFlacPicture(b []byte) []byte {
	rd := func(p int) (int, bool) {
		if p+4 > len(b) {
			return 0, false
		}
		return int(binary.BigEndian.Uint32(b[p:])), true
	}
	p := 4 // type
	ml, ok := rd(p)
	if !ok {
		return nil
	}
	p += 4 + ml
	dl, ok := rd(p)
	if !ok {
		return nil
	}
	p += 4 + dl + 16 // largeur, hauteur, profondeur, couleurs
	n, ok := rd(p)
	if !ok || p+4+n > len(b) {
		return nil
	}
	return b[p+4 : p+4+n]
}

func handleCover(w http.ResponseWriter, r *http.Request) {
	id, _ := strconv.Atoi(r.URL.Query().Get("id"))
	t := lib.get(id)
	if t == nil {
		http.NotFound(w, r)
		return
	}
	c := readCover(t.Path)
	if c == nil {
		http.NotFound(w, r)
		return
	}
	w.Header().Set("Content-Type", c.mime)
	w.Header().Set("Cache-Control", "max-age=3600")
	w.Write(c.data)
}
