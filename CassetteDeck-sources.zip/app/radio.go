package main

// Radio en ligne : relais des flux (Icecast / Shoutcast / HTTP), lecture des
// métadonnées ICY (titre en cours), listes .pls/.m3u, annuaire Radio Browser
// et favoris.

import (
	"bufio"
	"context"
	"crypto/tls"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net"
	"net/http"
	"net/textproto"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
	"unicode/utf8"
)

const userAgent = "CassetteDeck/1.1"

type Station struct {
	Name    string `json:"name"`
	URL     string `json:"url"`
	Info    string `json:"info,omitempty"`
	Favicon string `json:"favicon,omitempty"`
}

var defaultStations = []Station{
	{"FIP", "https://icecast.radiofrance.fr/fip-midfi.mp3", "France · éclectique", ""},
	{"FIP Electro", "https://icecast.radiofrance.fr/fipelectro-midfi.mp3", "France · électro", ""},
	{"FIP Groove", "https://icecast.radiofrance.fr/fipgroove-midfi.mp3", "France · groove", ""},
	{"France Inter", "https://icecast.radiofrance.fr/franceinter-midfi.mp3", "France · généraliste", ""},
	{"France Culture", "https://icecast.radiofrance.fr/franceculture-midfi.mp3", "France · culture", ""},
	{"France Musique", "https://icecast.radiofrance.fr/francemusique-midfi.mp3", "France · classique", ""},
	{"Radio Paradise", "https://stream.radioparadise.com/mp3-192", "USA · éclectique", ""},
	{"SomaFM Groove Salad", "https://ice2.somafm.com/groovesalad-128-mp3", "USA · ambient / downtempo", ""},
	{"SomaFM Drone Zone", "https://ice2.somafm.com/dronezone-128-mp3", "USA · ambient", ""},
	{"SomaFM DEF CON Radio", "https://ice2.somafm.com/defcon-128-mp3", "USA · électro sombre", ""},
}

// ------------------------------------------------------------------ favoris

var favMu sync.Mutex

func favFile() string { return filepath.Join(dataDir(), "radio.json") }

func loadFavs() []Station {
	favMu.Lock()
	defer favMu.Unlock()
	b, err := os.ReadFile(favFile())
	if err != nil {
		return append([]Station(nil), defaultStations...)
	}
	var s []Station
	if json.Unmarshal(b, &s) != nil {
		return append([]Station(nil), defaultStations...)
	}
	return s
}

func saveFavs(s []Station) error {
	favMu.Lock()
	defer favMu.Unlock()
	b, _ := json.MarshalIndent(s, "", "  ")
	return os.WriteFile(favFile(), b, 0o644)
}

// ------------------------------------------------------------------ titre en cours

var radioNow struct {
	sync.Mutex
	gen     int
	title   string
	icyName string
	err     string
}

func setNow(gen int, f func()) {
	radioNow.Lock()
	if radioNow.gen == gen {
		f()
	}
	radioNow.Unlock()
}

// ------------------------------------------------------------------ connexion au flux

var streamClient = &http.Client{
	Transport: &http.Transport{
		Proxy:                 http.ProxyFromEnvironment,
		DialContext:           (&net.Dialer{Timeout: 10 * time.Second}).DialContext,
		TLSHandshakeTimeout:   10 * time.Second,
		ResponseHeaderTimeout: 15 * time.Second,
		ForceAttemptHTTP2:     false,
		TLSNextProto:          map[string]func(string, *tls.Conn) http.RoundTripper{}, // HTTP/1.1 uniquement
	},
}

type openedStream struct {
	header http.Header
	body   io.ReadCloser
}

var errHLS = errors.New("flux HLS (.m3u8) non pris en charge")

func openStream(ctx context.Context, raw string, depth int) (*openedStream, error) {
	if depth > 3 {
		return nil, errors.New("trop de redirections de liste")
	}
	u, err := url.Parse(strings.TrimSpace(raw))
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		return nil, errors.New("adresse invalide")
	}
	req, _ := http.NewRequestWithContext(ctx, http.MethodGet, u.String(), nil)
	req.Header.Set("User-Agent", userAgent)
	req.Header.Set("Icy-MetaData", "1")
	req.Header.Set("Accept", "*/*")

	var st *openedStream
	resp, err := streamClient.Do(req)
	if err != nil {
		// Les vieux serveurs Shoutcast répondent « ICY 200 OK » : connexion brute.
		if strings.Contains(err.Error(), "malformed HTTP") || strings.Contains(err.Error(), "ICY") {
			st, err = dialICY(ctx, u)
		}
		if err != nil {
			return nil, err
		}
	} else {
		if resp.StatusCode != 200 {
			resp.Body.Close()
			return nil, fmt.Errorf("le serveur répond %s", resp.Status)
		}
		st = &openedStream{resp.Header, resp.Body}
	}

	ct := strings.ToLower(st.header.Get("Content-Type"))
	path := strings.ToLower(u.Path)
	isList := strings.Contains(ct, "mpegurl") || strings.Contains(ct, "scpls") || strings.Contains(ct, "pls+xml") ||
		strings.HasSuffix(path, ".pls") || strings.HasSuffix(path, ".m3u") || strings.HasSuffix(path, ".m3u8") ||
		strings.HasSuffix(path, ".xspf") || strings.HasSuffix(path, ".asx")
	if !isList {
		return st, nil
	}
	b, _ := io.ReadAll(io.LimitReader(st.body, 256*1024))
	st.body.Close()
	next, err := firstURL(string(b), u)
	if err != nil {
		return nil, err
	}
	return openStream(ctx, next, depth+1)
}

// firstURL extrait la première adresse de flux d'une liste .pls / .m3u / .xspf / .asx.
func firstURL(body string, base *url.URL) (string, error) {
	if strings.Contains(body, "#EXT-X-") {
		return "", errHLS
	}
	for _, line := range strings.Split(strings.ReplaceAll(body, "\r", "\n"), "\n") {
		l := strings.TrimSpace(line)
		low := strings.ToLower(l)
		switch {
		case l == "" || strings.HasPrefix(l, "#") || strings.HasPrefix(l, "["):
			continue
		case strings.HasPrefix(low, "file") && strings.Contains(l, "="): // .pls
			l = strings.TrimSpace(l[strings.Index(l, "=")+1:])
		case strings.Contains(low, "<location>"): // .xspf
			l = between(l, "<location>", "</location>")
		case strings.Contains(low, "href="): // .asx
			l = strings.Trim(between(l[strings.Index(low, "href=")+5:], "", ">"), "\"' /")
		case strings.Contains(l, "="):
			continue
		}
		if r, err := base.Parse(l); err == nil && (r.Scheme == "http" || r.Scheme == "https") {
			return r.String(), nil
		}
	}
	return "", errors.New("liste de lecture sans flux exploitable")
}

func between(s, a, b string) string {
	i := 0
	if a != "" {
		i = strings.Index(strings.ToLower(s), a)
		if i < 0 {
			return ""
		}
		i += len(a)
	}
	s = s[i:]
	if j := strings.Index(strings.ToLower(s), b); j >= 0 {
		s = s[:j]
	}
	return strings.TrimSpace(s)
}

type connBody struct {
	*bufio.Reader
	c net.Conn
}

func (b connBody) Close() error { return b.c.Close() }

func dialICY(ctx context.Context, u *url.URL) (*openedStream, error) {
	host := u.Host
	if u.Port() == "" {
		if u.Scheme == "https" {
			host += ":443"
		} else {
			host += ":80"
		}
	}
	c, err := (&net.Dialer{Timeout: 10 * time.Second}).DialContext(ctx, "tcp", host)
	if err != nil {
		return nil, err
	}
	if u.Scheme == "https" {
		tc := tls.Client(c, &tls.Config{ServerName: u.Hostname()})
		if err := tc.HandshakeContext(ctx); err != nil {
			c.Close()
			return nil, err
		}
		c = tc
	}
	go func() { <-ctx.Done(); c.Close() }()
	p := u.RequestURI()
	fmt.Fprintf(c, "GET %s HTTP/1.0\r\nHost: %s\r\nUser-Agent: %s\r\nIcy-MetaData: 1\r\nAccept: */*\r\nConnection: close\r\n\r\n", p, u.Host, userAgent)
	c.SetReadDeadline(time.Now().Add(15 * time.Second))
	br := bufio.NewReaderSize(c, 32*1024)
	tp := textproto.NewReader(br)
	line, err := tp.ReadLine()
	if err != nil {
		c.Close()
		return nil, err
	}
	if !strings.Contains(line, " 200") {
		c.Close()
		return nil, errors.New("réponse du serveur : " + line)
	}
	h, _ := tp.ReadMIMEHeader()
	c.SetReadDeadline(time.Time{})
	return &openedStream{http.Header(h), connBody{br, c}}, nil
}

// ------------------------------------------------------------------ relais vers la page

type flushWriter struct {
	w http.ResponseWriter
	f http.Flusher
}

func (fw flushWriter) Write(p []byte) (int, error) {
	n, err := fw.w.Write(p)
	if fw.f != nil {
		fw.f.Flush()
	}
	return n, err
}

func parseStreamTitle(meta []byte) (string, bool) {
	s := string(meta)
	if !utf8.ValidString(s) { // métadonnées en Latin-1
		r := make([]rune, len(meta))
		for i, c := range meta {
			r[i] = rune(c)
		}
		s = string(r)
	}
	i := strings.Index(s, "StreamTitle='")
	if i < 0 {
		return "", false
	}
	s = s[i+len("StreamTitle='"):]
	if j := strings.Index(s, "';"); j >= 0 {
		s = s[:j]
	} else {
		s = strings.TrimRight(s, "'\x00")
	}
	return strings.TrimSpace(s), true
}

func handleStream(w http.ResponseWriter, r *http.Request) {
	raw := r.URL.Query().Get("u")
	station := strings.TrimSpace(r.URL.Query().Get("n"))
	radioNow.Lock()
	radioNow.gen++
	gen := radioNow.gen
	radioNow.title, radioNow.icyName, radioNow.err = "", "", ""
	radioNow.Unlock()

	st, err := openStream(r.Context(), raw, 0)
	if err != nil {
		msg := friendlyErr(err)
		setNow(gen, func() { radioNow.err = msg })
		http.Error(w, err.Error(), http.StatusBadGateway)
		return
	}
	defer st.body.Close()

	ct := strings.ToLower(st.header.Get("Content-Type"))
	switch {
	case strings.Contains(ct, "aac"):
		ct = "audio/aac"
	case strings.Contains(ct, "mpeg"), strings.Contains(ct, "mp3"), ct == "":
		ct = "audio/mpeg"
	case strings.Contains(ct, "ogg"):
		ct = "audio/ogg"
	case strings.Contains(ct, "flac"):
		ct = "audio/flac"
	}
	icyName := strings.TrimSpace(st.header.Get("icy-name"))
	setNow(gen, func() { radioNow.icyName = icyName })
	if station == "" {
		station = icyName
	}
	if station == "" {
		station = "Radio"
	}
	ext := ".mp3"
	switch ct {
	case "audio/aac":
		ext = ".aac"
	case "audio/ogg":
		ext = ".ogg"
	case "audio/flac":
		ext = ".flac"
	}
	current := func() bool {
		radioNow.Lock()
		defer radioNow.Unlock()
		return radioNow.gen == gen
	}

	w.Header().Set("Content-Type", ct)
	w.Header().Set("Cache-Control", "no-store")
	w.WriteHeader(http.StatusOK)
	fl, _ := w.(http.Flusher)
	out := flushWriter{w, fl}

	metaint, _ := strconv.Atoi(st.header.Get("icy-metaint"))
	br := bufio.NewReaderSize(st.body, 64*1024)
	if metaint <= 0 {
		b := make([]byte, 16*1024)
		for {
			n, err := br.Read(b)
			if n > 0 {
				if _, werr := out.Write(b[:n]); werr != nil {
					return
				}
				if current() {
					rec.write(b[:n], ext)
				}
			}
			if err != nil {
				return
			}
		}
	}
	buf := make([]byte, metaint)
	meta := make([]byte, 255*16)
	for {
		if _, err := io.ReadFull(br, buf); err != nil {
			return
		}
		if _, err := out.Write(buf); err != nil {
			return
		}
		if current() {
			rec.write(buf, ext)
		}
		l, err := br.ReadByte()
		if err != nil {
			return
		}
		if n := int(l) * 16; n > 0 {
			if _, err := io.ReadFull(br, meta[:n]); err != nil {
				return
			}
			if t, ok := parseStreamTitle(meta[:n]); ok && current() {
				radioNow.Lock()
				changed := radioNow.title != t
				radioNow.title = t
				radioNow.Unlock()
				if changed {
					rec.newTitle(t)
					addHistory(station, t)
				}
			}
		}
	}
}

// ------------------------------------------------------------------ annuaire Radio Browser

var rbHosts = []string{"all.api.radio-browser.info", "de1.api.radio-browser.info", "nl1.api.radio-browser.info",
	"fi1.api.radio-browser.info", "at1.api.radio-browser.info", "de2.api.radio-browser.info"}

type rbStation struct {
	Name        string `json:"name"`
	URLResolved string `json:"url_resolved"`
	URL         string `json:"url"`
	Favicon     string `json:"favicon"`
	Tags        string `json:"tags"`
	Country     string `json:"country"`
	CountryCode string `json:"countrycode"`
	Codec       string `json:"codec"`
	Bitrate     int    `json:"bitrate"`
	HLS         int    `json:"hls"`
}

func searchStations(ctx context.Context, q, tag string) ([]Station, error) {
	v := url.Values{}
	if q != "" {
		v.Set("name", q)
	}
	if tag != "" {
		v.Set("tag", tag)
	}
	v.Set("limit", "80")
	v.Set("hidebroken", "true")
	v.Set("order", "clickcount")
	v.Set("reverse", "true")
	c := &http.Client{Timeout: 10 * time.Second}
	var lastErr error
	for _, h := range rbHosts {
		req, _ := http.NewRequestWithContext(ctx, http.MethodGet, "https://"+h+"/json/stations/search?"+v.Encode(), nil)
		req.Header.Set("User-Agent", userAgent)
		resp, err := c.Do(req)
		if err != nil {
			lastErr = err
			continue
		}
		var list []rbStation
		err = json.NewDecoder(resp.Body).Decode(&list)
		resp.Body.Close()
		if err != nil || resp.StatusCode != 200 {
			lastErr = fmt.Errorf("annuaire indisponible (%s)", resp.Status)
			continue
		}
		out := make([]Station, 0, len(list))
		seen := map[string]bool{}
		for _, s := range list {
			u := s.URLResolved
			if u == "" {
				u = s.URL
			}
			codec := strings.ToUpper(s.Codec)
			if s.HLS == 1 || u == "" || seen[u] || strings.Contains(strings.ToLower(u), ".m3u8") ||
				(codec != "" && codec != "MP3" && codec != "AAC" && codec != "AAC+" && codec != "OGG" && codec != "UNKNOWN" && codec != "FLAC" && codec != "OPUS") {
				continue
			}
			seen[u] = true
			info := []string{}
			if s.Country != "" {
				info = append(info, s.Country)
			}
			if s.Tags != "" {
				tags := strings.Split(s.Tags, ",")
				if len(tags) > 3 {
					tags = tags[:3]
				}
				info = append(info, strings.Join(tags, ", "))
			}
			if codec != "" && codec != "UNKNOWN" {
				q := codec
				if s.Bitrate > 0 {
					q += " " + strconv.Itoa(s.Bitrate) + "k"
				}
				info = append(info, q)
			}
			out = append(out, Station{Name: strings.TrimSpace(s.Name), URL: u, Info: strings.Join(info, " · "), Favicon: s.Favicon})
		}
		return out, nil
	}
	if lastErr == nil {
		lastErr = errors.New("annuaire indisponible")
	}
	return nil, lastErr
}

// ------------------------------------------------------------------ routes

func radioRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/radio/stream", authed(handleStream))

	mux.HandleFunc("/api/radio/now", authed(func(w http.ResponseWriter, r *http.Request) {
		radioNow.Lock()
		defer radioNow.Unlock()
		writeJSON(w, map[string]any{"gen": radioNow.gen, "title": radioNow.title, "name": radioNow.icyName, "error": radioNow.err, "rec": rec.status()})
	}))

	mux.HandleFunc("/api/radio/search", authed(func(w http.ResponseWriter, r *http.Request) {
		q := strings.TrimSpace(r.URL.Query().Get("q"))
		tag := strings.TrimSpace(r.URL.Query().Get("tag"))
		list, err := searchStations(r.Context(), q, tag)
		if err != nil {
			writeJSON(w, map[string]any{"error": err.Error()})
			return
		}
		writeJSON(w, map[string]any{"stations": list})
	}))

	mux.HandleFunc("/api/radio/favs", authed(func(w http.ResponseWriter, r *http.Request) {
		if r.Method == http.MethodPost {
			var s []Station
			if err := json.NewDecoder(io.LimitReader(r.Body, 1<<20)).Decode(&s); err != nil {
				http.Error(w, err.Error(), http.StatusBadRequest)
				return
			}
			if s == nil {
				s = []Station{}
			}
			saveFavs(s)
		}
		writeJSON(w, map[string]any{"stations": loadFavs()})
	}))
}

func friendlyErr(err error) string {
	e := err.Error()
	switch {
	case errors.Is(err, errHLS):
		return e
	case strings.Contains(e, "no such host"):
		return "serveur introuvable (adresse incorrecte ou pas de connexion Internet)"
	case strings.Contains(e, "refused"), strings.Contains(e, "unreachable"):
		return "serveur injoignable"
	case strings.Contains(e, "timeout"), strings.Contains(e, "deadline"):
		return "le serveur ne répond pas (délai dépassé)"
	case strings.Contains(e, "certificate"), strings.Contains(e, "x509"):
		return "certificat de sécurité invalide"
	}
	return e
}
