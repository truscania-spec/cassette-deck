//go:build windows

// Installateur de Cassette Deck (par utilisateur, sans droits administrateur).
//
//	CassetteDeck-Setup.exe                    assistant d'installation
//	CassetteDeck-Setup.exe /S                 installation silencieuse (reprend les options précédentes)
//	CassetteDeck-Setup.exe /S /relaunch       idem, puis relance le lecteur (mises à jour automatiques)
//	CassetteDeck-Setup.exe /D=C:\chemin       dossier d'installation
package main

import (
	_ "embed"
	"encoding/json"
	"errors"
	"fmt"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"strings"
	"sync"
	"syscall"
	"time"
)

//go:embed payload/CassetteDeck.exe
var payload []byte

//go:embed licence.txt
var licenceText string

//go:embed licences-tierces.txt
var thirdPartyText string

const (
	appName    = "Cassette Deck"
	appID      = "CassetteDeck"
	exeName    = "CassetteDeck.exe"
	appVersion = "2.1.0"
	uninstKey  = `Software\Microsoft\Windows\CurrentVersion\Uninstall\` + appID
	runKey     = `Software\Microsoft\Windows\CurrentVersion\Run`
)

var audioExts = []string{".mp3", ".flac", ".wav", ".ogg", ".oga", ".opus", ".m4a", ".aac", ".webm"}

type options struct {
	Dir        string
	Desktop    bool
	OpenWith   bool
	AutoUpdate bool
	Startup    bool
}

// previous renvoie les options de l'installation existante (ou les valeurs par défaut).
func previous() (o options, installedVersion string) {
	local := os.Getenv("LOCALAPPDATA")
	o = options{Dir: filepath.Join(local, "Programs", appID), Desktop: true, OpenWith: true, AutoUpdate: true}
	if d := regReadString(uninstKey, "InstallLocation"); d != "" {
		o.Dir = d
		installedVersion = regReadString(uninstKey, "DisplayVersion")
		o.Desktop = regReadDword(uninstKey, "OptDesktop", true)
		o.OpenWith = regReadDword(uninstKey, "OptOpenWith", true)
		o.Startup = regReadDword(uninstKey, "OptStartup", false)
	}
	if b, err := os.ReadFile(settingsPath()); err == nil {
		var m map[string]any
		if json.Unmarshal(b, &m) == nil {
			if v, ok := m["autoUpdate"].(bool); ok {
				o.AutoUpdate = v
			}
		}
	}
	return
}

func settingsPath() string {
	return filepath.Join(os.Getenv("LOCALAPPDATA"), appID, "settings.json")
}

func saveAutoUpdate(on bool) {
	p := settingsPath()
	m := map[string]any{}
	if b, err := os.ReadFile(p); err == nil {
		json.Unmarshal(b, &m)
	}
	m["autoUpdate"] = on
	os.MkdirAll(filepath.Dir(p), 0o755)
	b, _ := json.MarshalIndent(m, "", "  ")
	os.WriteFile(p, b, 0o644)
}

func hiddenCmd(name string, args ...string) *exec.Cmd {
	c := exec.Command(name, args...)
	c.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWin}
	return c
}

// doInstall installe le lecteur ; progress reçoit un pourcentage et un message.
func doInstall(o options, progress func(int, string)) error {
	runtime.LockOSThread()
	defer runtime.UnlockOSThread()
	pCoInitializeEx.Call(0, 0x2)

	exe := filepath.Join(o.Dir, exeName)

	progress(4, "Fermeture de Cassette Deck s'il est ouvert…")
	hiddenCmd("taskkill", "/F", "/IM", exeName).Run()
	time.Sleep(500 * time.Millisecond)

	progress(8, "Création du dossier d'installation…")
	if err := os.MkdirAll(o.Dir, 0o755); err != nil {
		return fmt.Errorf("impossible de créer le dossier :\n%s\n\n%v", o.Dir, err)
	}
	probe := filepath.Join(o.Dir, ".ecriture")
	if err := os.WriteFile(probe, []byte("ok"), 0o644); err != nil {
		return fmt.Errorf("ce dossier n'est pas accessible en écriture :\n%s\n\nChoisissez un dossier de votre profil (sans droits administrateur).", o.Dir)
	}
	os.Remove(probe)

	progress(12, "Copie du lecteur…")
	tmp := exe + ".new"
	f, err := os.Create(tmp)
	if err != nil {
		return fmt.Errorf("impossible d'écrire le programme :\n%v", err)
	}
	const chunk = 256 * 1024
	for i := 0; i < len(payload); i += chunk {
		j := i + chunk
		if j > len(payload) {
			j = len(payload)
		}
		if _, err := f.Write(payload[i:j]); err != nil {
			f.Close()
			os.Remove(tmp)
			return fmt.Errorf("écriture interrompue :\n%v", err)
		}
		progress(12+int(float64(j)/float64(len(payload))*58), "Copie du lecteur…")
	}
	f.Close()
	for i := 0; i < 12; i++ {
		os.Remove(exe)
		if err = os.Rename(tmp, exe); err == nil {
			break
		}
		time.Sleep(300 * time.Millisecond)
	}
	if err != nil {
		os.Remove(tmp)
		return errors.New("le fichier du lecteur est utilisé par un autre programme.\nFermez Cassette Deck puis relancez l'installation.")
	}
	os.WriteFile(filepath.Join(o.Dir, "Licence.txt"), []byte(crlf(licenceText)), 0o644)
	os.WriteFile(filepath.Join(o.Dir, "Licences tierces.txt"), []byte(crlf(thirdPartyText)), 0o644)

	progress(76, "Création des raccourcis…")
	icon := exe + ",0"
	if progs := shellFolder(csidlPrograms); progs != "" {
		createShortcut(filepath.Join(progs, appName+".lnk"), exe, "", o.Dir, exe, "Mini lecteur audio cassette")
		createShortcut(filepath.Join(progs, appName+" (mode compatibilité).lnk"), exe, "--edge", o.Dir, exe, "Cassette Deck dans une fenêtre Edge classique")
	}
	_ = icon
	if desk := shellFolder(csidlDesktop); desk != "" {
		lnk := filepath.Join(desk, appName+".lnk")
		if o.Desktop {
			createShortcut(lnk, exe, "", o.Dir, exe, "Mini lecteur audio cassette")
		} else {
			os.Remove(lnk)
		}
	}

	progress(86, "Inscription dans Windows…")
	if k, ok := regCreate(uninstKey); ok {
		k.str("DisplayName", appName)
		k.str("DisplayVersion", appVersion)
		k.str("DisplayIcon", exe+",0")
		k.str("Publisher", "Christopher")
		k.str("InstallLocation", o.Dir)
		k.str("UninstallString", `"`+exe+`" --uninstall`)
		k.str("QuietUninstallString", `"`+exe+`" --uninstall`)
		k.str("InstallDate", time.Now().Format("20060102"))
		k.dword("EstimatedSize", uint32(len(payload)/1024+64))
		k.dword("NoModify", 1)
		k.dword("NoRepair", 1)
		k.dword("OptDesktop", b2u(o.Desktop))
		k.dword("OptOpenWith", b2u(o.OpenWith))
		k.dword("OptStartup", b2u(o.Startup))
		k.close()
	}

	base := `Software\Classes\Applications\` + exeName
	if o.OpenWith {
		if k, ok := regCreate(base); ok {
			k.str("FriendlyAppName", appName)
			k.close()
		}
		if k, ok := regCreate(base + `\DefaultIcon`); ok {
			k.str("", exe+",0")
			k.close()
		}
		if k, ok := regCreate(base + `\shell\open\command`); ok {
			k.str("", `"`+exe+`" "%1"`)
			k.close()
		}
		if k, ok := regCreate(base + `\SupportedTypes`); ok {
			for _, e := range audioExts {
				k.str(e, "")
			}
			k.close()
		}
		for _, e := range audioExts {
			if k, ok := regCreate(`Software\Classes\` + e + `\OpenWithList\` + exeName); ok {
				k.close()
			}
		}
	} else {
		regDeleteTree(base)
		for _, e := range audioExts {
			regDeleteTree(`Software\Classes\` + e + `\OpenWithList\` + exeName)
		}
	}

	if o.Startup {
		if k, ok := regCreate(runKey); ok {
			k.str(appID, `"`+exe+`" --tray`)
			k.close()
		}
	} else {
		regDeleteValue(runKey, appID)
	}
	saveAutoUpdate(o.AutoUpdate)
	pSHChange.Call(0x08000000, 0, 0, 0) // SHCNE_ASSOCCHANGED

	progress(100, "Installation terminée.")
	return nil
}

func b2u(b bool) uint32 {
	if b {
		return 1
	}
	return 0
}

func crlf(s string) string {
	return strings.ReplaceAll(strings.ReplaceAll(s, "\r\n", "\n"), "\n", "\r\n")
}

func launch(dir string) {
	c := exec.Command(filepath.Join(dir, exeName))
	c.Dir = dir
	c.Start()
}

var logMu sync.Mutex

// setupLog garde une trace des installations silencieuses (mises à jour).
func setupLog(s string) {
	logMu.Lock()
	defer logMu.Unlock()
	p := filepath.Join(os.Getenv("LOCALAPPDATA"), appID, "journal.txt")
	os.MkdirAll(filepath.Dir(p), 0o755)
	f, err := os.OpenFile(p, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	fmt.Fprintf(f, "%s  [installation] %s\r\n", time.Now().Format("2006-01-02 15:04:05"), s)
	f.Close()
}

func main() {
	silent, relaunch := false, false
	dir := ""
	for _, a := range os.Args[1:] {
		switch {
		case strings.EqualFold(a, "/S"), strings.EqualFold(a, "--silent"):
			silent = true
		case strings.EqualFold(a, "/relaunch"):
			relaunch = true
		case strings.HasPrefix(strings.ToUpper(a), "/D="):
			dir = a[3:]
		}
	}
	if os.Getenv("LOCALAPPDATA") == "" {
		msg(0, "Dossier LOCALAPPDATA introuvable.", mbOK|mbIconError)
		os.Exit(1)
	}
	o, installed := previous()
	if dir != "" {
		o.Dir = dir
	}

	if silent {
		setupLog(fmt.Sprintf("mise à jour silencieuse %s -> %s dans %s", installed, appVersion, o.Dir))
		if err := doInstall(o, func(int, string) {}); err != nil {
			setupLog("échec : " + err.Error())
			msg(0, "La mise à jour de Cassette Deck a échoué :\n\n"+err.Error(), mbOK|mbIconError)
			os.Exit(1)
		}
		setupLog("terminée")
		if relaunch {
			launch(o.Dir)
		}
		return
	}
	runWizard(o, installed)
}
