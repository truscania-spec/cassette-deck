package main

// Canal d'événements serveur -> page (Server-Sent Events) et commandes
// page -> fenêtre hôte (/api/win).

import (
	"fmt"
	"net/http"
	"sync"
	"time"
)

type hub struct {
	mu   sync.Mutex
	subs map[chan string]bool
}

var events = &hub{subs: map[chan string]bool{}}

// emit envoie une commande à la page (lecture, piste suivante…).
func (h *hub) emit(cmd string) {
	h.mu.Lock()
	defer h.mu.Unlock()
	for c := range h.subs {
		select {
		case c <- cmd:
		default:
		}
	}
}

func handleEvents(w http.ResponseWriter, r *http.Request) {
	fl, ok := w.(http.Flusher)
	if !ok {
		http.Error(w, "flux indisponible", http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "text/event-stream")
	w.Header().Set("Cache-Control", "no-store")
	c := make(chan string, 16)
	events.mu.Lock()
	events.subs[c] = true
	events.mu.Unlock()
	defer func() {
		events.mu.Lock()
		delete(events.subs, c)
		events.mu.Unlock()
	}()
	fmt.Fprint(w, ": ok\n\n")
	fl.Flush()
	tick := time.NewTicker(25 * time.Second)
	defer tick.Stop()
	for {
		select {
		case <-r.Context().Done():
			return
		case cmd := <-c:
			fmt.Fprintf(w, "data: %s\n\n", cmd)
			fl.Flush()
		case <-tick.C:
			fmt.Fprint(w, ": ping\n\n")
			fl.Flush()
		}
	}
}

// État de lecture transmis par la page (info-bulle, miniature, progression).
type PlayerState struct {
	Playing   bool
	Live      bool
	Recording bool
	Title     string
	Progress  float64
}

func eventRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/api/events", authed(handleEvents))
	mux.HandleFunc("/api/win", authed(func(w http.ResponseWriter, r *http.Request) {
		q := r.URL.Query()
		res := hostCommand(q.Get("cmd"), q)
		if res == nil {
			res = map[string]any{}
		}
		writeJSON(w, res)
	}))
}
