//go:build windows

package main

// Accès Win32 / COM (sans cgo ni bibliothèque tierce).

import (
	"syscall"
	"unsafe"
)

var (
	user32   = syscall.NewLazyDLL("user32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	advapi32 = syscall.NewLazyDLL("advapi32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	comctl32 = syscall.NewLazyDLL("comctl32.dll")

	pMessageBox          = user32.NewProc("MessageBoxW")
	pRegisterClassExW    = user32.NewProc("RegisterClassExW")
	pCreateWindowExW     = user32.NewProc("CreateWindowExW")
	pDefWindowProcW      = user32.NewProc("DefWindowProcW")
	pDestroyWindow       = user32.NewProc("DestroyWindow")
	pShowWindow          = user32.NewProc("ShowWindow")
	pUpdateWindow        = user32.NewProc("UpdateWindow")
	pEnableWindow        = user32.NewProc("EnableWindow")
	pSetWindowTextW      = user32.NewProc("SetWindowTextW")
	pGetWindowTextW      = user32.NewProc("GetWindowTextW")
	pGetWindowTextLenW   = user32.NewProc("GetWindowTextLengthW")
	pSendMessageW        = user32.NewProc("SendMessageW")
	pPostMessageW        = user32.NewProc("PostMessageW")
	pPostQuitMessage     = user32.NewProc("PostQuitMessage")
	pGetMessageW         = user32.NewProc("GetMessageW")
	pTranslateMessage    = user32.NewProc("TranslateMessage")
	pDispatchMessageW    = user32.NewProc("DispatchMessageW")
	pIsDialogMessageW    = user32.NewProc("IsDialogMessageW")
	pLoadCursorW         = user32.NewProc("LoadCursorW")
	pLoadImageW          = user32.NewProc("LoadImageW")
	pGetSystemMetrics    = user32.NewProc("GetSystemMetrics")
	pAdjustWindowRectEx  = user32.NewProc("AdjustWindowRectEx")
	pBeginPaint          = user32.NewProc("BeginPaint")
	pEndPaint            = user32.NewProc("EndPaint")
	pFillRect            = user32.NewProc("FillRect")
	pGetSysColorBrush    = user32.NewProc("GetSysColorBrush")
	pGetDlgCtrlID        = user32.NewProc("GetDlgCtrlID")
	pSetFocus            = user32.NewProc("SetFocus")
	pInvalidateRect      = user32.NewProc("InvalidateRect")
	pGetDpiForSystem     = user32.NewProc("GetDpiForSystem")
	pSetForegroundWindow = user32.NewProc("SetForegroundWindow")

	pCreateFontW        = gdi32.NewProc("CreateFontW")
	pCreateCompatibleDC = gdi32.NewProc("CreateCompatibleDC")
	pSelectObject       = gdi32.NewProc("SelectObject")
	pDeleteDC           = gdi32.NewProc("DeleteDC")
	pStretchBlt         = gdi32.NewProc("StretchBlt")
	pSetStretchBltMode  = gdi32.NewProc("SetStretchBltMode")
	pSetBrushOrgEx      = gdi32.NewProc("SetBrushOrgEx")
	pSetTextColor       = gdi32.NewProc("SetTextColor")
	pSetBkMode          = gdi32.NewProc("SetBkMode")
	pGetStockObject     = gdi32.NewProc("GetStockObject")

	pGetModuleHandleW = kernel32.NewProc("GetModuleHandleW")

	pRegCreate      = advapi32.NewProc("RegCreateKeyExW")
	pRegSetValue    = advapi32.NewProc("RegSetValueExW")
	pRegClose       = advapi32.NewProc("RegCloseKey")
	pRegDeleteValue = advapi32.NewProc("RegDeleteValueW")
	pRegDeleteTree  = advapi32.NewProc("RegDeleteTreeW")
	pRegDeleteKey   = advapi32.NewProc("RegDeleteKeyW")

	pSHChange          = shell32.NewProc("SHChangeNotify")
	pSHGetFolderPathW  = shell32.NewProc("SHGetFolderPathW")
	pSHBrowseForFolder = shell32.NewProc("SHBrowseForFolderW")
	pSHGetPathFromIDL  = shell32.NewProc("SHGetPathFromIDListW")

	pCoInitializeEx   = ole32.NewProc("CoInitializeEx")
	pCoCreateInstance = ole32.NewProc("CoCreateInstance")
	pCoTaskMemFree    = ole32.NewProc("CoTaskMemFree")

	pInitCommonControlsEx = comctl32.NewProc("InitCommonControlsEx")
)

const (
	wsChild        = 0x40000000
	wsVisible      = 0x10000000
	wsTabStop      = 0x00010000
	wsGroup        = 0x00020000
	wsBorder       = 0x00800000
	wsVScroll      = 0x00200000
	wsCaption      = 0x00C00000
	wsSysMenu      = 0x00080000
	wsMinimizeBox  = 0x00020000
	wsClipChildren = 0x02000000
	wsExClientEdge = 0x00000200

	bsPush      = 0x0
	bsDefPush   = 0x1
	bsAutoCheck = 0x3
	bsAutoRadio = 0x9
	bsMultiline = 0x2000

	esMultiline  = 0x4
	esAutoVScrl  = 0x40
	esAutoHScrl  = 0x80
	esReadOnly   = 0x800
	ssNoPrefix   = 0x80
	ssEtchedHorz = 0x10

	wmDestroy        = 0x0002
	wmPaint          = 0x000F
	wmClose          = 0x0010
	wmSetFont        = 0x0030
	wmCommand        = 0x0111
	wmCtlColorStatic = 0x0138
	wmApp            = 0x8000
	bmGetCheck       = 0x00F0
	bmSetCheck       = 0x00F1
	pbmSetRange32    = 0x0406
	pbmSetPos        = 0x0402
	emSetSel         = 0x00B1

	swHide = 0
	swShow = 5

	mbOK          = 0x0
	mbYesNo       = 0x4
	mbIconError   = 0x10
	mbIconQuest   = 0x20
	mbIconWarning = 0x30
	mbIconInfo    = 0x40
	mbTopMost     = 0x40000
	mbSetFg       = 0x10000
	idYes         = 6

	hkcu        = 0x80000001
	keyWrite    = 0x20006
	regSZ       = 1
	regDWORD    = 4
	createNoWin = 0x08000000
)

type rect struct{ Left, Top, Right, Bottom int32 }
type point struct{ X, Y int32 }

type msgT struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      point
	Private uint32
}

type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}

type paintStruct struct {
	Hdc       uintptr
	Erase     int32
	Rc        rect
	Restore   int32
	IncUpdate int32
	Reserved  [32]byte
}

type browseInfo struct {
	Owner       uintptr
	Root        uintptr
	DisplayName *uint16
	Title       *uint16
	Flags       uint32
	Fn          uintptr
	LParam      uintptr
	Image       int32
}

type initCommonControls struct {
	Size uint32
	ICC  uint32
}

type guid struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}

var (
	clsidShellLink = guid{0x00021401, 0, 0, [8]byte{0xC0, 0, 0, 0, 0, 0, 0, 0x46}}
	iidShellLinkW  = guid{0x000214F9, 0, 0, [8]byte{0xC0, 0, 0, 0, 0, 0, 0, 0x46}}
	iidPersistFile = guid{0x0000010B, 0, 0, [8]byte{0xC0, 0, 0, 0, 0, 0, 0, 0x46}}
)

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }
func up(s string) uintptr  { return uintptr(unsafe.Pointer(u16(s))) }

func comCall(obj uintptr, idx int, args ...uintptr) uintptr {
	vtbl := *(*uintptr)(unsafe.Pointer(obj))
	fn := *(*uintptr)(unsafe.Pointer(vtbl + uintptr(idx)*unsafe.Sizeof(uintptr(0))))
	r, _, _ := syscall.SyscallN(fn, append([]uintptr{obj}, args...)...)
	return r
}

func failed(hr uintptr) bool { return int32(uint32(hr)) < 0 }

func msg(owner uintptr, text string, flags uint32) int {
	r, _, _ := pMessageBox.Call(owner, up(text), up("Installation de "+appName), uintptr(flags|mbTopMost|mbSetFg))
	return int(r)
}

// ---------------------------------------------------------------- registre

type regKey uintptr

func regCreate(path string) (regKey, bool) {
	var h uintptr
	r, _, _ := pRegCreate.Call(hkcu, up(path), 0, 0, 0, keyWrite, 0, uintptr(unsafe.Pointer(&h)), 0)
	return regKey(h), r == 0
}

func (k regKey) str(name, val string) {
	v, _ := syscall.UTF16FromString(val)
	var np uintptr
	if name != "" {
		np = up(name)
	}
	pRegSetValue.Call(uintptr(k), np, 0, regSZ, uintptr(unsafe.Pointer(&v[0])), uintptr(len(v)*2))
}

func (k regKey) dword(name string, val uint32) {
	pRegSetValue.Call(uintptr(k), up(name), 0, regDWORD, uintptr(unsafe.Pointer(&val)), 4)
}

func (k regKey) close() { pRegClose.Call(uintptr(k)) }

func regDeleteValue(path, name string) {
	if k, ok := regCreate(path); ok {
		pRegDeleteValue.Call(uintptr(k), up(name))
		k.close()
	}
}

func regDeleteTree(path string) {
	pRegDeleteTree.Call(hkcu, up(path))
	pRegDeleteKey.Call(hkcu, up(path))
}

func regReadString(path, name string) string {
	var h syscall.Handle
	if syscall.RegOpenKeyEx(syscall.HKEY_CURRENT_USER, u16(path), 0, syscall.KEY_READ, &h) != nil {
		return ""
	}
	defer syscall.RegCloseKey(h)
	buf := make([]uint16, 1024)
	n := uint32(len(buf) * 2)
	var typ uint32
	if syscall.RegQueryValueEx(h, u16(name), nil, &typ, (*byte)(unsafe.Pointer(&buf[0])), &n) != nil || typ != regSZ {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

func regReadDword(path, name string, def bool) bool {
	var h syscall.Handle
	if syscall.RegOpenKeyEx(syscall.HKEY_CURRENT_USER, u16(path), 0, syscall.KEY_READ, &h) != nil {
		return def
	}
	defer syscall.RegCloseKey(h)
	var v, typ uint32
	n := uint32(4)
	if syscall.RegQueryValueEx(h, u16(name), nil, &typ, (*byte)(unsafe.Pointer(&v)), &n) != nil || typ != regDWORD {
		return def
	}
	return v != 0
}

// ---------------------------------------------------------------- dossiers et raccourcis

const (
	csidlPrograms = 0x0002
	csidlDesktop  = 0x0010
)

func shellFolder(csidl uintptr) string {
	buf := make([]uint16, 520)
	r, _, _ := pSHGetFolderPathW.Call(0, csidl, 0, 0, uintptr(unsafe.Pointer(&buf[0])))
	if failed(r) {
		return ""
	}
	return syscall.UTF16ToString(buf)
}

// createShortcut crée un fichier .lnk via IShellLinkW / IPersistFile.
// Le fil appelant doit avoir initialisé COM.
func createShortcut(lnk, target, args, dir, icon, desc string) error {
	var sl uintptr
	r, _, _ := pCoCreateInstance.Call(uintptr(unsafe.Pointer(&clsidShellLink)), 0, 1,
		uintptr(unsafe.Pointer(&iidShellLinkW)), uintptr(unsafe.Pointer(&sl)))
	if failed(r) || sl == 0 {
		return syscall.Errno(r)
	}
	defer comCall(sl, 2)
	comCall(sl, 20, up(target))  // SetPath
	comCall(sl, 11, up(args))    // SetArguments
	comCall(sl, 9, up(dir))      // SetWorkingDirectory
	comCall(sl, 7, up(desc))     // SetDescription
	comCall(sl, 17, up(icon), 0) // SetIconLocation
	var pf uintptr
	if r := comCall(sl, 0, uintptr(unsafe.Pointer(&iidPersistFile)), uintptr(unsafe.Pointer(&pf))); failed(r) || pf == 0 {
		return syscall.Errno(r)
	}
	defer comCall(pf, 2)
	if r := comCall(pf, 6, up(lnk), 1); failed(r) { // Save
		return syscall.Errno(r)
	}
	return nil
}
