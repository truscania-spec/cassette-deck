"use strict";
/* Cassette Deck — logique du lecteur */

const $ = (s) => document.querySelector(s);
const TOKEN = new URLSearchParams(location.search).get("t") || "";
const api = (path, opts) => fetch(`${path}${path.includes("?") ? "&" : "?"}t=${TOKEN}`, opts).then((r) => r.json());

/* ------------------------------------------------------------------ état */
const store = {
  get(k, d) { try { const v = localStorage.getItem("cd." + k); return v === null ? d : JSON.parse(v); } catch { return d; } },
  set(k, v) { try { localStorage.setItem("cd." + k, JSON.stringify(v)); } catch {} },
};

const S = {
  tracks: [],          // {id, title, artist, url, local}
  rev: -1,
  idx: -1,
  volume: store.get("volume", 0.7),
  shuffle: store.get("shuffle", false),
  repeat: store.get("repeat", "all"),   // all | one | off
  eq: store.get("eq", false),
  eqGains: store.get("eqGains", [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]),
  eqPre: store.get("eqPre", 0),
  eqPreset: store.get("eqPreset", "Plat"),
  rec: null, recAt: 0,
  native: new URLSearchParams(location.search).has("native"),
  order: [],
  errors: 0,
  meta: new Map(),
  // radio en ligne
  radio: null,          // station en cours {name, url, info, favicon}
  radioState: "off",    // playing | paused | stopped
  radioTitle: "",
  radioRetries: 0,
  buffering: false,
  favs: [],
  radioList: [],
  radioMode: "favs",    // favs | results
};
const isRadio = () => !!S.radio;

/* ------------------------------------------------------------------ audio */
const audio = new Audio();
audio.preload = "auto";
let ctx, analyser, aL, aR, pre, eqNodes = [], gain, freq, tdL, tdR;
const EQ_FREQS = [31, 62, 125, 250, 500, 1000, 2000, 4000, 8000, 16000];

function initAudio() {
  if (ctx) return;
  ctx = new (window.AudioContext || window.webkitAudioContext)({ latencyHint: "playback" });
  const src = ctx.createMediaElementSource(audio);
  analyser = ctx.createAnalyser();
  analyser.fftSize = 8192;
  analyser.smoothingTimeConstant = 0.55;
  analyser.minDecibels = -100;
  analyser.maxDecibels = -10;
  const split = ctx.createChannelSplitter(2);
  aL = ctx.createAnalyser(); aR = ctx.createAnalyser();
  aL.fftSize = aR.fftSize = 2048;
  pre = ctx.createGain();
  eqNodes = EQ_FREQS.map((f, i) => {
    const b = ctx.createBiquadFilter();
    b.type = i === 0 ? "lowshelf" : i === EQ_FREQS.length - 1 ? "highshelf" : "peaking";
    b.frequency.value = f; b.Q.value = 1.1; b.gain.value = 0;
    return b;
  });
  gain = ctx.createGain();
  src.connect(analyser);
  src.connect(split); split.connect(aL, 0); split.connect(aR, 1);
  let node = src.connect(pre);
  for (const b of eqNodes) node = node.connect(b);
  node.connect(gain); gain.connect(ctx.destination);
  freq = new Float32Array(analyser.frequencyBinCount);
  tdL = new Float32Array(aL.fftSize); tdR = new Float32Array(aR.fftSize);
  applyVolume(); applyEq();
}
function resumeAudio() { initAudio(); if (ctx.state === "suspended") ctx.resume(); }

function applyVolume() {
  if (gain) gain.gain.setTargetAtTime(S.volume * S.volume, ctx.currentTime, 0.02);
  $("#knobDot").style.setProperty("--a", `${-135 + 270 * S.volume}deg`);
}
function applyEq() {
  if (!ctx) return;
  eqNodes.forEach((b, i) => b.gain.setTargetAtTime(S.eq ? S.eqGains[i] : 0, ctx.currentTime, 0.03));
  pre.gain.setTargetAtTime(S.eq ? Math.pow(10, S.eqPre / 20) : 1, ctx.currentTime, 0.03);
  if (typeof drawEqCurve === "function") drawEqCurve();
}

/* ------------------------------------------------------------------ afficheur haut */
const ICONS = {
  play: '<svg viewBox="0 0 20 22"><path d="M1 0 L20 11 L1 22 Z"/></svg>',
  pause: '<svg viewBox="0 0 20 22"><path d="M2 0 H8 V22 H2 Z M12 0 H18 V22 H12 Z"/></svg>',
  stop: '<svg viewBox="0 0 20 22"><path d="M1 2 H19 V20 H1 Z"/></svg>',
  none: "",
};
let flashTimer = 0, dots = 0;
function baseStatus() {
  if (isRadio() && S.rec && S.rec.recording && !audio.paused) {
    return ["none", (dots % 2 ? "\u25CF" : "\u25CB") + " ENR. " + fmt(S.rec.elapsed + (performance.now() - S.recAt) / 1000).replace(/^00:/, "")];
  }
  if (isRadio()) {
    const d = ".".repeat(1 + (dots % 3)).padEnd(3, "\u2007");
    if (!audio.paused) return ["play", (S.buffering || audio.readyState < 3 ? "CONNEXION " : "EN DIRECT ") + d];
    return S.radioState === "paused" ? ["pause", "PAUSE"] : ["stop", "ARRÊT"];
  }
  if (!S.tracks.length) return ["none", "PAS DE CASSETTE"];
  if (!audio.paused) return ["play", "LECTURE " + ".".repeat(1 + (dots % 3)).padEnd(3, " ")];
  if (audio.currentTime > 0.05) return ["pause", "PAUSE"];
  return ["stop", "ARRÊT"];
}
function renderStatus() {
  if (flashTimer > performance.now()) return;
  const [ic, txt] = baseStatus();
  setStatus(ic, txt);
}
function setStatus(ic, txt) {
  const i = $("#statusIcon"), t = $("#statusText");
  if (i.dataset.ic !== ic) { i.innerHTML = ICONS[ic]; i.dataset.ic = ic; }
  if (t.textContent !== txt) {
    t.textContent = txt;
    t.style.transform = "none";
    const w = t.scrollWidth, max = 300 - (ic === "none" ? 0 : 34);
    if (w > max) t.style.transform = `scaleX(${(max / w).toFixed(3)})`;
  }
}
function flash(txt, ic = "none", ms = 1400) {
  flashTimer = performance.now() + ms;
  setStatus(ic, txt);
}
setInterval(() => { dots++; renderStatus(); }, 450);

/* ------------------------------------------------------------------ infos */
const fmt = (s) => {
  if (!isFinite(s) || s < 0) s = 0;
  s = Math.floor(s);
  const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60;
  return [h, m, x].map((v) => String(v).padStart(2, "0")).join(":");
};
const pad2 = (n) => String(n).padStart(2, "0");
const NB = " ";

function cur() { return S.tracks[S.idx]; }

function displayTitle(t) {
  if (!t) return "PAS DE CASSETTE";
  const m = S.meta.get(t.id) || t;
  return m.artist ? `${m.artist} - ${m.title}` : m.title;
}

function radioTitleText() {
  const n = S.radio.name || "Radio";
  return S.radioTitle && S.radioTitle !== n ? `${n} · ${S.radioTitle}` : n;
}
function renderInfo() {
  const t = cur();
  const title = isRadio() ? radioTitleText() : displayTitle(t);
  const el = $("#title"), inner = $("#titleInner");
  if (inner.textContent !== title) {
    inner.textContent = title;
    el.classList.remove("scroll");
    requestAnimationFrame(() => {
      if (inner.scrollWidth > el.clientWidth + 2) {
        el.style.setProperty("--dur", `${Math.max(8, title.length * 0.38)}s`);
        el.classList.add("scroll");
      }
    });
    document.title = t || isRadio() ? `Cassette Deck — ${title}` : "Cassette Deck";
  }
  const live = isRadio();
  $("#progress").classList.toggle("live", live && !audio.paused);
  if (live) {
    const k = S.favs.findIndex((f) => f.url === S.radio.url);
    $("#vTrack").textContent = `${k >= 0 ? `${pad2(k + 1)}${NB}/${NB}${pad2(S.favs.length)}` : "DIRECT"}`;
    $("#vTime").textContent = `${fmt(audio.paused ? 0 : audio.currentTime)}`;
    $("#vTotal").textContent = `DIRECT`;
    if (audio.paused) $("#progressFill").style.width = "0%";
    return;
  }
  const n = S.tracks.length;
  $("#vTrack").textContent = `${n ? pad2(S.idx + 1) : "--"}${NB}/${NB}${n ? pad2(n) : "--"}`;
  $("#vTime").textContent = `${fmt(audio.currentTime)}`;
  $("#vTotal").textContent = `${fmt(audio.duration)}`;
  const p = audio.duration > 0 && isFinite(audio.duration) ? audio.currentTime / audio.duration : 0;
  $("#progressFill").style.width = `${(p * 100).toFixed(2)}%`;
}

function renderButtons() {
  const playing = !audio.paused;
  $("#bPlay").classList.toggle("on", playing);
  $("#bPause").classList.toggle("on", !playing && (isRadio() ? S.radioState === "paused" : audio.currentTime > 0.05 && !!cur()));
  document.body.classList.toggle("playing", playing);
  $("#ledShuffle").className = "led" + (S.shuffle ? " on" : "");
  $("#ledRepeat").className = "led" + (S.repeat === "all" ? " on" : S.repeat === "one" ? " blink" : "");
  $("#ledEq").className = "led" + (S.eq ? " on" : "");
  reportState();
}

/* ------------------------------------------------------------------ liste */
function rebuildOrder() {
  S.order = S.tracks.map((_, i) => i);
  if (S.shuffle) {
    for (let i = S.order.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [S.order[i], S.order[j]] = [S.order[j], S.order[i]];
    }
    // la piste courante devient la première de l'ordre aléatoire
    const k = S.order.indexOf(S.idx);
    if (k > 0) { S.order.splice(k, 1); S.order.unshift(S.idx); }
  }
}

function renderList() {
  const ol = $("#plList");
  ol.innerHTML = "";
  const frag = document.createDocumentFragment();
  S.tracks.forEach((t, i) => {
    const li = document.createElement("li");
    li.dataset.i = i;
    if (i === S.idx) li.className = "cur";
    if (t.local) li.classList.add("local");
    li.innerHTML = `<span class="n">${pad2(i + 1)}</span><span class="t"></span><span class="x" title="Retirer">✕</span>`;
    li.querySelector(".t").textContent = displayTitle(t);
    frag.appendChild(li);
  });
  ol.appendChild(frag);
  if (($("#playlist").dataset.tab || "list") === "list") $("#plCount").textContent = `${S.tracks.length} piste${S.tracks.length > 1 ? "s" : ""}`;
  $("#playlist").classList.toggle("empty", !S.tracks.length);
}
function markCurrent() {
  document.querySelectorAll("#plList li").forEach((li) => li.classList.toggle("cur", +li.dataset.i === S.idx));
  const c = document.querySelector("#plList li.cur");
  if (c && !$("#playlist").classList.contains("hidden")) c.scrollIntoView({ block: "nearest" });
}

$("#plList").addEventListener("click", (e) => {
  const li = e.target.closest("li"); if (!li) return;
  const i = +li.dataset.i;
  if (e.target.classList.contains("x")) { removeTrack(i); return; }
  load(i, true);
});

function mergeServer(lib) {
  const curT = cur();
  const locals = S.tracks.filter((t) => t.local);
  S.tracks = lib.tracks.map((t) => ({ ...t, url: `/media/${t.id}?t=${TOKEN}` })).concat(locals);
  S.rev = lib.rev;
  let newIdx = curT ? S.tracks.findIndex((t) => t.id === curT.id && !!t.local === !!curT.local) : -1;
  rebuildOrder();
  renderList();
  if (lib.playFrom >= 0) {
    const k = S.tracks.findIndex((t) => !t.local && t.id === lib.playFrom);
    if (k >= 0) { load(k, true); return; }
  }
  if (newIdx < 0 && curT && !isRadio()) { stop(true); S.idx = S.tracks.length ? 0 : -1; if (S.idx >= 0) load(0, false); }
  else S.idx = newIdx;
  markCurrent(); renderInfo(); renderButtons();
}

async function poll() {
  try {
    const lib = await api(`/api/library?rev=${S.rev}`);
    if (!lib.unchanged) mergeServer(lib);
  } catch {}
  setTimeout(poll, 2000);
}

async function removeTrack(i) {
  const t = S.tracks[i];
  if (!t) return;
  if (i === S.idx && !isRadio()) { stop(true); }
  if (t.local) {
    URL.revokeObjectURL(t.url);
    S.tracks.splice(i, 1);
    if (S.idx > i) S.idx--;
    if (S.idx >= S.tracks.length) S.idx = S.tracks.length - 1;
    rebuildOrder(); renderList(); renderInfo();
  } else {
    if (S.idx > i) S.idx--;
    mergeServer(await api(`/api/remove?id=${t.id}`));
  }
}

async function openDialog(mode, append) {
  flash("CHARGEMENT", "none", 60000);
  try {
    const r = await api(`/api/open?mode=${mode}&append=${append ? 1 : 0}`, { method: "POST" });
    flashTimer = 0;
    if (r.error) flash("ERREUR", "none", 2000);
    else if (!r.cancelled) mergeServer(r);
  } catch { flashTimer = 0; }
  renderStatus();
}
async function clearList() {
  if (!isRadio()) stop(true);
  S.tracks.filter((t) => t.local).forEach((t) => URL.revokeObjectURL(t.url));
  S.tracks = [];
  S.idx = -1;
  mergeServer(await api("/api/clear"));
}

/* ------------------------------------------------------------------ transport */
async function fetchMeta(t) {
  if (!t || t.local || S.meta.has(t.id)) return;
  try {
    const m = await api(`/api/meta?id=${t.id}`);
    S.meta.set(t.id, m);
    renderInfo();
    const li = document.querySelector(`#plList li[data-i="${S.tracks.indexOf(t)}"] .t`);
    if (li) li.textContent = displayTitle(t);
    updateMediaSession();
  } catch {}
}

function load(i, autoplay, startAt = 0) {
  const t = S.tracks[i];
  if (!t) return;
  if (isRadio()) { if (S.rec && S.rec.recording) stopRec(); S.radio = null; S.radioState = "off"; markRadio(); }
  S.idx = i;
  audio.src = t.url;
  if (startAt > 0) {
    audio.addEventListener("loadedmetadata", () => { audio.currentTime = Math.min(startAt, audio.duration - 1); renderInfo(); }, { once: true });
  }
  if (autoplay) play();
  setCover(t.local ? "" : `/api/cover?id=${t.id}&t=${TOKEN}`);
  fetchMeta(t);
  markCurrent(); renderInfo(); renderButtons(); updateMediaSession();
  store.set("lastIndex", i);
}

function play() {
  if (isRadio()) {
    if (!audio.getAttribute("src")) playRadio(S.radio);
    else audio.play().catch(() => {});
    return;
  }
  if (!S.tracks.length) { openDialog("files", false); return; }
  resumeAudio();
  if (S.idx < 0) { load(S.order[0] ?? 0, true); return; }
  if (!audio.src) { load(S.idx, true); return; }
  const p = audio.play();
  if (p) p.catch(() => {});
}
function pause() {
  if (isRadio()) { cutStream(); S.radioState = "paused"; renderButtons(); renderStatus(); renderInfo(); return; }
  audio.pause();
}
function toggle() { audio.paused ? play() : pause(); }
function stop(silent) {
  if (isRadio()) {
    cutStream(); S.radioState = "stopped";
    if (!silent) flash("ARRÊT", "stop", 900);
    renderInfo(); renderButtons(); return;
  }
  audio.pause();
  if (audio.src) { try { audio.currentTime = 0; } catch {} }
  if (!silent) flash("ARRÊT", "stop", 900);
  renderInfo(); renderButtons();
}
function step(dir, auto) {
  if (isRadio()) {
    const list = S.favs.some((f) => f.url === S.radio.url) || !S.radioList.length ? S.favs : S.radioList;
    if (!list.length) return;
    const k = list.findIndex((f) => f.url === S.radio.url);
    playRadio(list[(k + dir + list.length) % list.length]);
    return;
  }
  if (!S.tracks.length) return;
  if (!auto && dir < 0 && audio.currentTime > 3) { audio.currentTime = 0; return; }
  if (auto && S.repeat === "one") { audio.currentTime = 0; play(); return; }
  let k = S.order.indexOf(S.idx) + dir;
  if (k >= S.order.length || k < 0) {
    if (auto && S.repeat === "off") { stop(true); audio.currentTime = 0; renderStatus(); return; }
    if (S.shuffle && dir > 0) rebuildOrder();
    k = (k + S.order.length) % S.order.length;
  }
  load(S.order[k], true);
}

audio.addEventListener("ended", () => (isRadio() ? radioFailed() : step(1, true)));
audio.addEventListener("playing", () => { S.errors = 0; S.buffering = false; if (isRadio()) S.radioRetries = 0; renderButtons(); renderStatus(); });
audio.addEventListener("waiting", () => { S.buffering = true; renderStatus(); });
audio.addEventListener("pause", () => { renderButtons(); renderStatus(); });
audio.addEventListener("durationchange", renderInfo);
audio.addEventListener("error", () => {
  if (isRadio()) { if (audio.getAttribute("src")) radioFailed(); return; }
  if (!audio.src || !cur()) return;
  flash("FORMAT INCONNU", "none", 1600);
  S.errors++;
  if (S.errors < S.tracks.length) setTimeout(() => step(1, false), 1200);
  else stop(true);
});
setInterval(() => { if (audio.src && !audio.paused && !isRadio()) store.set("lastTime", audio.currentTime); }, 2000);

/* Touches multimédia du clavier / overlay Windows */
function updateMediaSession() {
  if (!("mediaSession" in navigator)) return;
  if (isRadio()) {
    navigator.mediaSession.metadata = new MediaMetadata({
      title: S.radioTitle || S.radio.name, artist: S.radioTitle ? S.radio.name : "Radio en ligne", album: "Cassette Deck",
      artwork: [{ src: "assets/icon.png", sizes: "256x256", type: "image/png" }],
    });
    return;
  }
  const t = cur();
  if (!t) return;
  const m = S.meta.get(t.id) || t;
  navigator.mediaSession.metadata = new MediaMetadata({
    title: m.title, artist: m.artist || "", album: "Cassette Deck",
    artwork: [{ src: S.coverUrl || "assets/icon.png" }],
  });
}
if ("mediaSession" in navigator) {
  const ms = navigator.mediaSession;
  ms.setActionHandler("play", play);
  ms.setActionHandler("pause", pause);
  ms.setActionHandler("stop", () => stop());
  ms.setActionHandler("previoustrack", () => step(-1));
  ms.setActionHandler("nexttrack", () => step(1));
  try { ms.setActionHandler("seekto", (d) => { if (!isRadio()) audio.currentTime = d.seekTime; }); } catch {}
}

/* ------------------------------------------------------------------ commandes */
function setVolume(v, show = true) {
  S.volume = Math.min(1, Math.max(0, v));
  store.set("volume", S.volume);
  applyVolume();
  if (show) flash(`VOLUME ${Math.round(S.volume * 100)}\u202f%`, "none", 900);
}
function toggleShuffle() {
  S.shuffle = !S.shuffle; store.set("shuffle", S.shuffle); rebuildOrder();
  flash(S.shuffle ? "ALÉATOIRE OUI" : "ALÉATOIRE NON"); renderButtons();
}
function cycleRepeat() {
  S.repeat = { all: "one", one: "off", off: "all" }[S.repeat];
  store.set("repeat", S.repeat);
  flash({ all: "RÉPÉTER TOUT", one: "RÉPÉTER 1", off: "RÉPÉTER NON" }[S.repeat]); renderButtons();
}
function toggleEq() {
  resumeAudio();
  S.eq = !S.eq; store.set("eq", S.eq); applyEq();
  flash(S.eq ? "ÉGALISEUR OUI" : "ÉGALISEUR NON"); renderButtons(); renderEqPower();
}
function showTab(tab) {
  document.querySelectorAll(".tab").forEach((b) => b.classList.toggle("on", b.dataset.tab === tab));
  $("#viewList").classList.toggle("hidden", tab !== "list");
  $("#viewRadio").classList.toggle("hidden", tab !== "radio");
  $("#viewEq").classList.toggle("hidden", tab !== "eq");
  $("#btnsList").classList.toggle("hidden", tab !== "list");
  $("#btnsRadio").classList.toggle("hidden", tab !== "radio");
  $("#btnsEq").classList.toggle("hidden", tab !== "eq");
  $("#playlist").dataset.tab = tab;
  if (tab === "radio") (S.radioMode === "hist" ? showHistory() : renderRadioList());
  else if (tab === "eq") { $("#plCount").textContent = S.eqPreset; drawEqCurve(); }
  else { markCurrent(); $("#plCount").textContent = `${S.tracks.length} piste${S.tracks.length > 1 ? "s" : ""}`; }
}
function toggleList(force, tab) {
  const pl = $("#playlist");
  const curTab = pl.dataset.tab || "list";
  let show = force === undefined ? pl.classList.contains("hidden") || (tab && tab !== curTab) : force;
  pl.classList.toggle("hidden", !show);
  if (show) showTab(tab || curTab);
}
document.querySelectorAll(".tab").forEach((b) => b.addEventListener("click", (e) => { e.stopPropagation(); showTab(b.dataset.tab); }));

const ACTIONS = {
  play, pause, stop: () => stop(), prev: () => step(-1), next: () => step(1),
  shuffle: toggleShuffle, repeat: cycleRepeat, eq: toggleEq, eqPanel: () => toggleList(undefined, "eq"),
  addFiles: () => openDialog("files", true), addFolder: () => openDialog("folder", true),
  clear: clearList, closeList: () => toggleList(false),
};
document.querySelectorAll("[data-act]").forEach((el) =>
  el.addEventListener("click", (e) => { e.stopPropagation(); resumeAudio(); ACTIONS[el.dataset.act](); }));

let clickT = 0;
$("#cassetteHit").addEventListener("click", () => {
  clearTimeout(clickT);
  clickT = setTimeout(() => (S.tracks.length || isRadio() ? toggleList(undefined, isRadio() ? "radio" : undefined) : openDialog("files", false)), 220);
});
$("#cassetteHit").addEventListener("dblclick", () => { clearTimeout(clickT); openDialog("files", false); });
$("#labelHit").addEventListener("click", () => openDialog("files", false));

$("#progress").addEventListener("pointerdown", (e) => {
  const seek = (ev) => {
    const r = $("#progress").getBoundingClientRect();
    const p = Math.min(1, Math.max(0, (ev.clientX - r.left) / r.width));
    if (audio.duration > 0 && isFinite(audio.duration)) { audio.currentTime = p * audio.duration; renderInfo(); }
  };
  seek(e);
  const mv = (ev) => seek(ev);
  window.addEventListener("pointermove", mv);
  window.addEventListener("pointerup", () => window.removeEventListener("pointermove", mv), { once: true });
});

/* Bouton de volume : glisser verticalement / circulairement, ou molette */
(() => {
  const k = $("#knob");
  let y0 = 0, v0 = 0;
  k.addEventListener("pointerdown", (e) => {
    k.setPointerCapture(e.pointerId); y0 = e.clientY; v0 = S.volume; resumeAudio();
  });
  k.addEventListener("pointermove", (e) => {
    if (!k.hasPointerCapture(e.pointerId)) return;
    setVolume(v0 + (y0 - e.clientY) / (180 * scale));
  });
  k.addEventListener("dblclick", () => setVolume(S.volume > 0 ? 0 : 0.7));
})();
window.addEventListener("wheel", (e) => {
  if (e.ctrlKey) { zoomWindow(e.deltaY < 0 ? 1 : -1); return; }
  if (e.target.closest("#playlist")) return;
  setVolume(S.volume + (e.deltaY < 0 ? 0.04 : -0.04));
}, { passive: true });

window.addEventListener("keydown", (e) => {
  if (e.ctrlKey || e.altKey || e.metaKey) return;
  if (e.target.matches && e.target.matches("input, textarea")) {
    if (e.key === "Escape") e.target.blur();
    return;
  }
  const k = e.key.toLowerCase();
  const map = {
    " ": toggle, arrowup: () => setVolume(S.volume + 0.05), arrowdown: () => setVolume(S.volume - 0.05),
    arrowright: () => { if (isFinite(audio.duration)) audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 5); },
    arrowleft: () => { if (isFinite(audio.duration)) audio.currentTime = Math.max(0, audio.currentTime - 5); },
    n: () => step(1), p: () => step(-1), s: toggleShuffle, r: cycleRepeat, e: toggleEq, q: () => toggleList(undefined, "eq"),
    l: () => toggleList(undefined, "list"), t: () => toggleList(undefined, "radio"), o: () => openDialog("files", false),
    escape: () => { hideMenu(); $("#help").classList.add("hidden"); toggleList(false); },
    f1: () => $("#help").classList.toggle("hidden"),
  };
  if (map[k]) { e.preventDefault(); resumeAudio(); map[k](); }
});

/* ------------------------------------------------------------------ menu contextuel */
const menu = $("#menu");
function hideMenu() { menu.classList.add("hidden"); }
function sizeTo(w) {
  if (S.native) { api(`/api/win?cmd=size&w=${w}`); return; }
  const h = Math.round(w * 786 / 1602);
  try { window.resizeTo(w + (window.outerWidth - window.innerWidth), h + (window.outerHeight - window.innerHeight)); } catch {}
}
window.addEventListener("contextmenu", (e) => {
  e.preventDefault();
  const t = cur();
  const items = [
    ["Ouvrir des fichiers…", "O", () => openDialog("files", false)],
    ["Ouvrir un dossier…", "", () => openDialog("folder", false)],
    ["Ajouter des fichiers…", "", () => openDialog("files", true)],
    ["Ajouter un dossier…", "", () => openDialog("folder", true)],
    "-",
    ["Liste de lecture", "L", () => toggleList(true, "list")],
    ["Radio en ligne", "T", () => toggleList(true, "radio")],
    ["Afficher dans l'Explorateur", "", () => t && api(`/api/reveal?id=${t.id}`), !t || t.local || isRadio()],
    ["Vider la liste", "", clearList, !S.tracks.length],
    "-",
    ["Égaliseur…", "Q", () => toggleList(true, "eq")],
    isRadio() ? [S.rec && S.rec.recording ? "Arrêter l'enregistrement" : "Enregistrer la radio", "", toggleRec] : null,
    ["Dossier des enregistrements", "", () => api("/api/recdir")],
    "-",
    ["Taille : petite", "Ctrl+molette", () => sizeTo(640)],
    ["Taille : moyenne", "", () => sizeTo(900)],
    ["Taille : grande", "", () => sizeTo(1300)],
    S.native ? ["Réduire", "", () => api("/api/win?cmd=min")] : null,
    S.native ? ["Masquer dans la zone de notification", "", () => api("/api/win?cmd=hide")] : null,
    S.native ? ["Fenêtre Edge classique (compatibilité)", "", () => switchMode("edge")]
             : ["Fenêtre native sans cadre", "", () => switchMode("natif")],
    "-",
    ["Raccourcis clavier", "F1", () => $("#help").classList.remove("hidden")],
    U.state !== "disabled" ? ["Rechercher des mises à jour…", "", manualCheck] : null,
    U.state !== "disabled" ? [U.auto ? "✓ Mises à jour automatiques" : "Mises à jour automatiques", "", toggleAutoUpdate] : null,
    ["Quitter", "", () => { api("/api/quit").finally(() => window.close()); }],
  ];
  menu.innerHTML = "";
  for (const it of items) {
    if (!it) continue;
    if (it === "-") { menu.insertAdjacentHTML("beforeend", '<div class="sep"></div>'); continue; }
    const d = document.createElement("div");
    d.className = "it" + (it[3] ? " dis" : "");
    d.innerHTML = `<span></span><small>${it[1]}</small>`;
    d.firstChild.textContent = it[0];
    d.addEventListener("click", () => { hideMenu(); it[2](); });
    menu.appendChild(d);
  }
  menu.classList.remove("hidden");
  const r = menu.getBoundingClientRect();
  menu.style.left = Math.min(e.clientX, innerWidth - r.width - 4) + "px";
  menu.style.top = Math.min(e.clientY, innerHeight - r.height - 4) + "px";
});
window.addEventListener("pointerdown", (e) => {
  if (!e.target.closest("#menu")) hideMenu();
  if (!e.target.closest("#help")) $("#help").classList.add("hidden");
  if (!e.target.closest("#update") && !U.busy) $("#update").classList.add("hidden");
});

/* ------------------------------------------------------------------ glisser-déposer */
let dragDepth = 0;
window.addEventListener("dragenter", (e) => { e.preventDefault(); dragDepth++; $("#drop").classList.remove("hidden"); });
window.addEventListener("dragleave", () => { if (--dragDepth <= 0) { dragDepth = 0; $("#drop").classList.add("hidden"); } });
window.addEventListener("dragover", (e) => e.preventDefault());
window.addEventListener("drop", (e) => {
  e.preventDefault(); dragDepth = 0; $("#drop").classList.add("hidden");
  const files = [...e.dataTransfer.files].filter((f) => /^audio\//.test(f.type) || /\.(mp3|flac|wav|ogg|oga|opus|m4a|aac|webm)$/i.test(f.name));
  if (!files.length) { flash("FICHIER NON AUDIO", "none", 1500); return; }
  const first = S.tracks.length;
  for (const f of files) {
    S.tracks.push({ id: "L" + Math.random().toString(36).slice(2), local: true, url: URL.createObjectURL(f),
      title: f.name.replace(/\.[^.]+$/, "").replace(/_/g, " "), artist: "" });
  }
  rebuildOrder(); renderList();
  load(first, true);
});

/* ------------------------------------------------------------------ mise à l'échelle */
let scale = 1;
function fit() {
  if (!innerWidth || !innerHeight) return;
  scale = Math.min(innerWidth / 1602, innerHeight / 786);
  const x = (innerWidth - 1602 * scale) / 2, y = (innerHeight - 786 * scale) / 2;
  $("#deck").style.transform = `translate(${x}px, ${y}px) scale(${scale})`;
}
window.addEventListener("resize", fit);
fit();
// la fenêtre native peut charger la page alors qu'elle est encore masquée (taille 0) :
// on recalcule l'échelle dès que la taille réelle est connue
window.addEventListener("load", fit);
document.addEventListener("visibilitychange", fit);
try { new ResizeObserver(fit).observe(document.documentElement); } catch {}
setInterval(() => {
  const want = Math.min(innerWidth / 1602, innerHeight / 786);
  if (want > 0 && Math.abs(want - scale) > 0.001) fit();
}, 500);

/* ------------------------------------------------------------------ rendu des vumètres */
function makeSeg(w, h, lit) {
  const c = document.createElement("canvas");
  c.width = w; c.height = h;
  const g = c.getContext("2d");
  if (lit) {
    const gr = g.createLinearGradient(0, 0, 0, h);
    gr.addColorStop(0, "#ffd650"); gr.addColorStop(0.5, "#ffb424"); gr.addColorStop(1, "#ff8a0c");
    g.fillStyle = gr; g.fillRect(0, 0, w, h);
    const sg = g.createLinearGradient(0, 0, w, 0);
    sg.addColorStop(0, "rgba(230,70,0,.55)"); sg.addColorStop(0.18, "rgba(230,70,0,0)");
    sg.addColorStop(0.82, "rgba(230,70,0,0)"); sg.addColorStop(1, "rgba(230,70,0,.55)");
    g.fillStyle = sg; g.fillRect(0, 0, w, h);
    g.fillStyle = "rgba(255,248,210,.45)"; g.fillRect(1, 0, w - 2, 1);
  } else {
    g.fillStyle = "rgba(255,105,15,0.075)"; g.fillRect(0, 0, w, h);
  }
  return c;
}
const segCache = new Map();
function seg(w, h, lit) {
  const k = `${w}x${h}${lit ? "L" : "D"}`;
  if (!segCache.has(k)) segCache.set(k, makeSeg(w, h, lit));
  return segCache.get(k);
}
const PEAK = (() => { const c = makeSeg(14, 6, true); return c; })();

/* Spectre principal : 54 barres, 16 segments */
const SPEC = { c: $("#spec"), bars: 54, segs: 16, x0: 18, x1: 1092, bottom: 147.5, pitch: 8.5, sh: 6, bw: 14 };
SPEC.g = SPEC.c.getContext("2d");
SPEC.v = new Float32Array(SPEC.bars); SPEC.peak = new Float32Array(SPEC.bars); SPEC.hold = new Float32Array(SPEC.bars);

/* Mini spectre du panneau infos : 14 barres */
const MINI = { c: $("#mini"), bars: 14, segs: 7, x0: 6, pitch: 17, bw: 11, bottom: 52, sp: 6.2, sh: 4 };
MINI.g = MINI.c.getContext("2d");
MINI.v = new Float32Array(MINI.bars);

/* VU-mètres : 3 colonnes par canal (graves, RMS, crête) */
const VU = {
  L: { c: $("#vuL"), cols: [[8, 16, 17], [35, 18, 17], [68, 18, 14]] },
  R: { c: $("#vuR"), cols: [[9, 20, 14], [44, 18, 17], [71, 15, 17]] },
  bottom: 158.6, pitch: 8.6, sh: 6.2,
};
VU.L.g = VU.L.c.getContext("2d"); VU.R.g = VU.R.c.getContext("2d");
VU.L.v = [0, 0, 0]; VU.R.v = [0, 0, 0];

let bandEdges = null;
function computeBands(n, fmin, fmax) {
  const sr = ctx.sampleRate, nb = analyser.frequencyBinCount, hz = sr / 2 / nb;
  const e = [];
  for (let i = 0; i <= n; i++) e.push(Math.max(1, Math.round(fmin * Math.pow(fmax / fmin, i / n) / hz)));
  for (let i = 1; i <= n; i++) if (e[i] <= e[i - 1]) e[i] = e[i - 1] + 1;
  return e;
}
const dbTo01 = (db, lo, hi) => Math.min(1, Math.max(0, (db - lo) / (hi - lo)));

function bandLevels(edges, n, tilt) {
  const out = new Float32Array(n);
  for (let i = 0; i < n; i++) {
    // énergie de la bande (somme des puissances) : rendu homogène sur l'échelle log
    let pw = 0;
    for (let b = edges[i]; b < edges[i + 1] && b < freq.length; b++) pw += Math.pow(10, freq[b] / 10);
    const db = 10 * Math.log10(pw + 1e-20);
    // légère compensation des aigus (spectre musical en pente)
    out[i] = dbTo01(db + tilt * (i / n), -70, -10);
  }
  return out;
}

function rms(td) { let s = 0; for (let i = 0; i < td.length; i++) s += td[i] * td[i]; return Math.sqrt(s / td.length); }
function peakOf(td) { let p = 0; for (let i = 0; i < td.length; i++) { const a = Math.abs(td[i]); if (a > p) p = a; } return p; }
const lin2seg = (x) => dbTo01(20 * Math.log10(x + 1e-9), -36, 0);

let last = performance.now(), angL = 0, angR = 0, motor = 0;
function frame(now) {
  const dt = Math.min(0.1, (now - last) / 1000); last = now;
  const playing = !audio.paused && ctx;

  /* -------- données */
  let target = null, miniT = null, vuT = { L: [0, 0, 0], R: [0, 0, 0] };
  if (playing) {
    analyser.getFloatFrequencyData(freq);
    if (!bandEdges) bandEdges = { s: computeBands(SPEC.bars, 40, 16000), m: computeBands(MINI.bars, 50, 12000) };
    target = bandLevels(bandEdges.s, SPEC.bars, 8);
    miniT = bandLevels(bandEdges.m, MINI.bars, 6);
    aL.getFloatTimeDomainData(tdL); aR.getFloatTimeDomainData(tdR);
    let rl = rms(tdL), rr = rms(tdR), pl = peakOf(tdL), pr = peakOf(tdR);
    if (rr < 1e-6 && rl > 1e-6) { rr = rl; pr = pl; } // source mono
    const bass = (target[0] + target[1] + target[2] + target[3] + target[4]) / 5;
    vuT.L = [bass * 0.92, lin2seg(rl * 1.6), lin2seg(pl)];
    vuT.R = [lin2seg(pr), lin2seg(rr * 1.6), bass * 0.9];
  }

  /* -------- spectre */
  const g = SPEC.g;
  g.clearRect(0, 0, SPEC.c.width, SPEC.c.height);
  // pointillés verticaux des bords
  g.fillStyle = "rgba(255,120,20,.55)";
  for (let y = 4; y < 156; y += 4) { g.fillRect(6, y, 2, 2); g.fillRect(1097, y, 2, 2); }
  const pitch = (SPEC.x1 - SPEC.x0) / SPEC.bars;
  for (let i = 0; i < SPEC.bars; i++) {
    const tv = target ? target[i] : 0;
    SPEC.v[i] = tv > SPEC.v[i] ? SPEC.v[i] + (tv - SPEC.v[i]) * Math.min(1, dt * 28) : Math.max(tv, SPEC.v[i] - dt * 1.6);
    const n = Math.round(SPEC.v[i] * SPEC.segs);
    if (n >= SPEC.peak[i]) { SPEC.peak[i] = n; SPEC.hold[i] = 0.45; }
    else if ((SPEC.hold[i] -= dt) < 0) SPEC.peak[i] = Math.max(0, SPEC.peak[i] - dt * 14);
    const x = Math.round(SPEC.x0 + i * pitch + (pitch - SPEC.bw) / 2);
    for (let s = 0; s < SPEC.segs; s++) {
      const y = Math.round(SPEC.bottom - (s + 1) * SPEC.pitch);
      g.drawImage(seg(SPEC.bw, SPEC.sh, s < n), x, y);
    }
    const pk = Math.floor(SPEC.peak[i]);
    if (pk > n && pk > 0) {
      g.globalAlpha = 0.85;
      g.drawImage(seg(SPEC.bw, SPEC.sh, true), x, Math.round(SPEC.bottom - pk * SPEC.pitch));
      g.globalAlpha = 1;
    }
    // reflet sous la barre
    if (n > 0) { g.fillStyle = `rgba(255,110,10,${0.10 + 0.25 * SPEC.v[i]})`; g.fillRect(x, SPEC.bottom + 2, SPEC.bw, 6); }
  }

  /* -------- mini spectre */
  const m = MINI.g;
  m.clearRect(0, 0, MINI.c.width, MINI.c.height);
  for (let i = 0; i < MINI.bars; i++) {
    const tv = miniT ? miniT[i] : 0;
    MINI.v[i] = tv > MINI.v[i] ? MINI.v[i] + (tv - MINI.v[i]) * Math.min(1, dt * 22) : Math.max(tv, MINI.v[i] - dt * 1.8);
    const n = Math.round(MINI.v[i] * MINI.segs);
    const x = MINI.x0 + i * MINI.pitch;
    for (let s = 0; s < MINI.segs; s++) m.drawImage(seg(MINI.bw, MINI.sh, s < n), x, Math.round(MINI.bottom - (s + 1) * MINI.sp));
  }

  /* -------- VU-mètres */
  for (const side of ["L", "R"]) {
    const V = VU[side], vg = V.g;
    vg.clearRect(0, 0, V.c.width, V.c.height);
    V.cols.forEach(([x, w, nseg], ci) => {
      const tv = vuT[side][ci];
      V.v[ci] = tv > V.v[ci] ? V.v[ci] + (tv - V.v[ci]) * Math.min(1, dt * 30) : Math.max(tv, V.v[ci] - dt * 1.3);
      const n = Math.round(V.v[ci] * 17);
      for (let s = 0; s < nseg; s++) vg.drawImage(seg(w, Math.round(VU.sh), s < n), x, Math.round(VU.bottom - (s + 1) * VU.pitch));
    });
  }

  /* -------- bobines : vitesse linéaire constante, rayon du bobinage variable,
     avec inertie au démarrage et à l'arrêt */
  const pk = tapeProgress();
  const packs = packRadii(pk);
  motor += ((playing ? 1 : 0) - motor) * Math.min(1, dt * (playing ? 3.2 : 2.2));
  if (motor > 0.002) {
    const base = 9000; // vitesse linéaire de la bande (px·deg/s)
    angL = (angL + dt * motor * base / packs.l) % 360;
    angR = (angR + dt * motor * base / packs.r) % 360;
    $("#reelL").style.transform = `rotate(${angL}deg)`;
    $("#reelR").style.transform = `rotate(${angR}deg)`;
  }
  drawInterior(packs, playing ? tdL : null, dt);

  if (playing || Math.random() < 0.2) renderInfo();
  requestAnimationFrame(frame);
}

/* ------------------------------------------------------------------ démarrage */
(async function boot() {
  initAudio();
  applyVolume(); renderButtons(); renderStatus();
  try {
    const lib = await api("/api/library");
    mergeServer(lib);
    const li = store.get("lastIndex", 0);
    if (S.tracks.length && S.idx < 0) load(Math.min(li, S.tracks.length - 1), false, store.get("lastTime", 0));
  } catch (e) { flash("ERREUR SERVEUR", "none", 3000); }
  loadFavs();
  requestAnimationFrame(frame);
  setTimeout(poll, 2000);
  window.addEventListener("pointerdown", resumeAudio, { once: true });
  // fermeture de la fenêtre : le serveur local s'arrête
  window.addEventListener("pagehide", () => { try { navigator.sendBeacon(`/api/bye?t=${TOKEN}`); } catch {} });
})();


/* ================================================================== radio en ligne */
function cutStream() {
  if (S.rec && S.rec.recording) stopRec();
  audio.pause();
  audio.removeAttribute("src");
  audio.load();
  S.buffering = false;
}

function playRadio(st, retry = false) {
  if (!st || !st.url) return;
  resumeAudio();
  const changed = !S.radio || S.radio.url !== st.url;
  if (changed && S.rec && S.rec.recording) stopRec();
  S.radio = st;
  S.radioState = "playing";
  if (changed) { S.radioTitle = ""; }
  if (!retry) S.radioRetries = 0;
  S.buffering = true;
  audio.src = `/radio/stream?u=${encodeURIComponent(st.url)}&n=${encodeURIComponent(st.name || "")}&t=${TOKEN}&r=${Date.now()}`;
  setCover(st.favicon && /^https?:/.test(st.favicon) ? st.favicon : "", true);
  audio.play().catch(() => {});
  store.set("lastRadio", st);
  $("#rMsg").textContent = "";
  markCurrent(); markRadio(); renderInfo(); renderButtons(); renderStatus(); updateMediaSession();
}

async function radioFailed() {
  if (!isRadio() || S.radioState !== "playing") return;
  if (S.radioRetries < 2) {
    S.radioRetries++;
    flash("RECONNEXION", "none", 2200);
    setTimeout(() => { if (isRadio() && S.radioState === "playing") playRadio(S.radio, true); }, 2000);
    return;
  }
  cutStream();
  S.radioState = "stopped";
  flash("PAS DE SIGNAL", "none", 3500);
  try {
    const n = await api("/api/radio/now");
    if (n.error) $("#rMsg").textContent = `« ${S.radio.name} » : ${n.error}`;
    else $("#rMsg").textContent = `« ${S.radio.name} » ne répond pas ou utilise un format non pris en charge.`;
  } catch {}
  renderButtons(); renderInfo();
}

/* titre diffusé (métadonnées ICY) */
setInterval(async () => {
  if (!isRadio() || audio.paused) return;
  try {
    const n = await api("/api/radio/now");
    setRecState(n.rec);
    if (n.title !== undefined && n.title !== S.radioTitle) {
      S.radioTitle = n.title;
      renderInfo(); updateMediaSession();
    }
    // flux ajouté sans nom : on reprend le nom annoncé par le serveur (icy-name)
    const host = (() => { try { return new URL(S.radio.url).hostname.replace(/^www\./, ""); } catch { return ""; } })();
    if (n.name && (!S.radio.name || S.radio.custom || S.radio.name === host)) {
      const f = S.favs.find((x) => x.url === S.radio.url);
      S.radio.name = n.name; S.radio.custom = false;
      if (f && f.name === host) { f.name = n.name; saveFavs(); renderRadioList(); }
      renderInfo();
    }
  } catch {}
}, 4000);

/* ---------- favoris */
async function loadFavs() {
  try { S.favs = (await api("/api/radio/favs")).stations || []; } catch { S.favs = []; }
  if ($("#playlist").dataset.tab === "radio") renderRadioList();
}
async function saveFavs() {
  try {
    S.favs = (await api("/api/radio/favs", { method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(S.favs.map(({ name, url, info, favicon }) => ({ name, url, info, favicon }))) })).stations;
  } catch {}
}
const isFav = (url) => S.favs.some((f) => f.url === url);
function toggleFav(st) {
  if (isFav(st.url)) S.favs = S.favs.filter((f) => f.url !== st.url);
  else S.favs.push({ name: st.name, url: st.url, info: st.info || "", favicon: st.favicon || "" });
  saveFavs(); renderRadioList(); renderInfo();
}

/* ---------- liste des stations */
function renderRadioList() {
  const list = S.radioMode === "favs" ? S.favs : S.radioList;
  const ol = $("#rList");
  ol.innerHTML = "";
  const frag = document.createDocumentFragment();
  list.forEach((st, i) => {
    const li = document.createElement("li");
    li.dataset.i = i;
    li.innerHTML = `<span class="star" title="Favori">★</span><img class="ico" alt="" referrerpolicy="no-referrer"><span class="t"></span><span class="i"></span>` +
      (S.radioMode === "favs" ? `<span class="x" title="Retirer des favoris">✕</span>` : "");
    li.querySelector(".t").textContent = st.name;
    li.querySelector(".i").textContent = st.info || "";
    li.querySelector(".star").classList.toggle("on", isFav(st.url));
    const img = li.querySelector(".ico");
    if (st.favicon && /^https?:/.test(st.favicon)) { img.src = st.favicon; img.onerror = () => { img.style.visibility = "hidden"; }; }
    else img.style.visibility = "hidden";
    frag.appendChild(li);
  });
  ol.appendChild(frag);
  if (!list.length && !$("#rMsg").textContent) {
    $("#rMsg").textContent = S.radioMode === "favs" ? "Aucun favori. Cherchez une station puis cliquez sur ★." : "Aucune station trouvée.";
  }
  const n = list.length;
  $("#plCount").textContent = S.radioMode === "favs" ? `${n} favori${n > 1 ? "s" : ""}` : `${n} station${n > 1 ? "s" : ""}`;
  markRadio();
}
function markRadio() {
  document.querySelectorAll("#rList li").forEach((li) => {
    const list = S.radioMode === "favs" ? S.favs : S.radioList;
    const st = list[+li.dataset.i];
    li.classList.toggle("cur", !!(S.radio && st && st.url === S.radio.url));
  });
}
$("#rList").addEventListener("click", (e) => {
  const li = e.target.closest("li"); if (!li) return;
  const list = S.radioMode === "favs" ? S.favs : S.radioList;
  const st = list[+li.dataset.i]; if (!st) return;
  if (e.target.classList.contains("star") || e.target.classList.contains("x")) { toggleFav(st); return; }
  if (S.radioMode === "results") S.radioList = list;
  playRadio(st);
});

/* ---------- recherche dans l'annuaire Radio Browser */
async function searchRadio(q, tag) {
  S.radioMode = "results";
  S.radioList = [];
  $("#rList").innerHTML = "";
  $("#rMsg").textContent = "Recherche dans l'annuaire Radio Browser…";
  try {
    const r = await api(`/api/radio/search?q=${encodeURIComponent(q || "")}&tag=${encodeURIComponent(tag || "")}`);
    if (r.error) { $("#rMsg").textContent = `Annuaire indisponible : ${r.error}`; renderRadioList(); return; }
    S.radioList = r.stations || [];
    $("#rMsg").textContent = "";
    renderRadioList();
  } catch {
    $("#rMsg").textContent = "Annuaire indisponible (connexion Internet ?).";
  }
}
function selectChip(tag) {
  document.querySelectorAll("#rChips button").forEach((b) => b.classList.toggle("on", b.dataset.tag === tag));
}
$("#rChips").addEventListener("click", (e) => {
  const b = e.target.closest("button"); if (!b) return;
  e.stopPropagation();
  const tag = b.dataset.tag;
  selectChip(tag);
  $("#rMsg").textContent = "";
  if (!tag) { S.radioMode = "favs"; renderRadioList(); }
  else searchRadio("", tag);
});
$("#rSearch").addEventListener("submit", (e) => {
  e.preventDefault();
  const q = $("#rQuery").value.trim();
  selectChip(q ? null : "");
  $("#hTools").classList.add("hidden");
  $("#rMsg").textContent = "";
  if (q) searchRadio(q, ""); else { S.radioMode = "favs"; renderRadioList(); }
});

/* ---------- flux par adresse */
$("#rAddUrl").addEventListener("click", (e) => {
  e.stopPropagation();
  $("#rUrlForm").classList.toggle("hidden");
  if (!$("#rUrlForm").classList.contains("hidden")) $("#rUrl").focus();
});
function urlStation() {
  const url = $("#rUrl").value.trim();
  if (!/^https?:\/\//i.test(url)) { $("#rMsg").textContent = "L'adresse doit commencer par http:// ou https://"; return null; }
  let name = $("#rUrlName").value.trim();
  const custom = !name;
  if (!name) { try { name = new URL(url).hostname.replace(/^www\./, ""); } catch { name = "Radio"; } }
  return { name, url, info: "Flux personnalisé", custom };
}
$("#rUrlForm").addEventListener("submit", (e) => { e.preventDefault(); const st = urlStation(); if (st) playRadio(st); });
$("#rUrlFav").addEventListener("click", () => {
  const st = urlStation(); if (!st) return;
  if (!isFav(st.url)) toggleFav(st);
  S.radioMode = "favs"; selectChip(""); renderRadioList();
  $("#rUrl").value = ""; $("#rUrlName").value = "";
  $("#rUrlForm").classList.add("hidden");
});

/* ================================================================== v2 : cassette animée */
const PACK = { rMin: 121, rMax: 176, cl: [190, 132], cr: [685, 132] };
const IC = $("#interior"), ig = IC.getContext("2d");

function tapeProgress() {
  if (isRadio()) return 0.5;
  if (!S.tracks.length) return 0;
  return audio.duration > 0 && isFinite(audio.duration) ? audio.currentTime / audio.duration : 0;
}
// la quantité de bande se conserve : rl² + rr² = rMin² + rMax²
function packRadii(p) {
  const a = PACK.rMin ** 2, b = PACK.rMax ** 2;
  return { l: Math.sqrt(b - p * (b - a)), r: Math.sqrt(a + p * (b - a)) };
}

/* texture du bobinage : anneaux concentriques légèrement irréguliers */
const packTex = (() => {
  const R = PACK.rMax + 4, c = document.createElement("canvas");
  c.width = c.height = R * 2;
  const g = c.getContext("2d");
  let seed = 11;
  const rnd = () => ((seed = (seed * 16807) % 2147483647) / 2147483647);
  for (let r = R; r > 0; r -= 0.7) {
    const v = 0.75 + rnd() * 0.5;
    g.beginPath(); g.arc(R, R, r, 0, Math.PI * 2);
    g.fillStyle = `rgb(${Math.round(46 * v)},${Math.round(26 * v)},${Math.round(16 * v)})`;
    g.fill();
  }
  // reflet satiné (fixe, la bande est réfléchissante)
  const sh = g.createLinearGradient(0, 0, R * 2, R * 2);
  sh.addColorStop(0.0, "rgba(255,190,140,0.10)");
  sh.addColorStop(0.35, "rgba(255,190,140,0.02)");
  sh.addColorStop(0.55, "rgba(0,0,0,0.18)");
  sh.addColorStop(1.0, "rgba(255,150,80,0.06)");
  g.fillStyle = sh; g.fillRect(0, 0, R * 2, R * 2);
  return { c, R };
})();

const osc = { hist: new Float32Array(56), acc: 0 };

function tangentPoint(c, r, g, outerLeft) {
  const dx = g[0] - c[0], dy = g[1] - c[1], d = Math.hypot(dx, dy);
  if (d <= r) return null;
  const th = Math.atan2(dy, dx), al = Math.acos(r / d);
  const a1 = th + al, a2 = th - al;
  const p1 = [c[0] + r * Math.cos(a1), c[1] + r * Math.sin(a1)], p2 = [c[0] + r * Math.cos(a2), c[1] + r * Math.sin(a2)];
  return outerLeft ? (p1[0] < p2[0] ? p1 : p2) : (p1[0] > p2[0] ? p1 : p2);
}

function drawPack(c, r, rimSide) {
  const g = ig, R = packTex.R;
  g.save();
  g.beginPath(); g.arc(c[0], c[1], r, 0, Math.PI * 2); g.clip();
  g.drawImage(packTex.c, c[0] - R, c[1] - R);
  // assombrissement vers le moyeu
  const rg = g.createRadialGradient(c[0], c[1], PACK.rMin - 8, c[0], c[1], r);
  rg.addColorStop(0, "rgba(0,0,0,0.35)"); rg.addColorStop(1, "rgba(0,0,0,0)");
  g.fillStyle = rg; g.fillRect(c[0] - r, c[1] - r, r * 2, r * 2);
  g.restore();
  // tranche du bobinage
  g.beginPath(); g.arc(c[0], c[1], r - 0.5, 0, Math.PI * 2);
  g.strokeStyle = "rgba(120,72,44,0.85)"; g.lineWidth = 1.5; g.stroke();
  // liseré lumineux orange (comme le boîtier d'origine)
  g.save();
  g.shadowColor = "rgba(255,120,10,0.9)"; g.shadowBlur = 10;
  g.strokeStyle = "rgba(255,140,30,0.85)"; g.lineWidth = 1.6;
  g.beginPath();
  const a0 = rimSide < 0 ? Math.PI * 0.62 : -Math.PI * 0.38;
  g.arc(c[0], c[1], r + 3, a0, a0 + Math.PI * 0.76);
  g.stroke();
  g.strokeStyle = "rgba(255,140,30,0.35)"; g.lineWidth = 1;
  g.beginPath(); g.arc(c[0], c[1], r + 3, a0 + Math.PI, a0 + Math.PI * 1.76); g.stroke();
  g.restore();
}

function drawInterior(packs, td, dt) {
  const g = ig, W = IC.width, H = IC.height;
  g.clearRect(0, 0, W, H);

  // repères de la fenêtre de la cassette
  g.strokeStyle = "rgba(235,225,220,0.16)"; g.lineWidth = 1;
  for (const y of [39.5, 72.5, 202.5, 225.5]) { g.beginPath(); g.moveTo(250, y); g.lineTo(625, y); g.stroke(); }

  // bande : du bobinage vers les galets de guidage (sous la fenêtre)
  const GL = [40, 330], GR = [825, 330];
  const tl = tangentPoint(PACK.cl, packs.l, GL, true), tr = tangentPoint(PACK.cr, packs.r, GR, false);
  g.lineCap = "round";
  for (const [p, q] of [[tl, GL], [tr, GR]]) {
    if (!p) continue;
    g.strokeStyle = "rgba(70,40,24,0.95)"; g.lineWidth = 2.6;
    g.beginPath(); g.moveTo(p[0], p[1]); g.lineTo(q[0], q[1]); g.stroke();
    g.strokeStyle = "rgba(255,170,110,0.18)"; g.lineWidth = 0.8;
    g.beginPath(); g.moveTo(p[0] + 1, p[1]); g.lineTo(q[0] + 1, q[1]); g.stroke();
  }

  drawPack(PACK.cl, packs.l, -1);
  drawPack(PACK.cr, packs.r, 1);

  // oscilloscope défilant entre les bobines
  const cx = 437, cy = 132, step = 4.2, half = 52;
  osc.acc += dt;
  if (osc.acc >= 1 / 30) {
    osc.acc = 0;
    let p = 0;
    if (td) for (let i = 0; i < td.length; i += 4) p = Math.max(p, Math.abs(td[i]));
    osc.hist.copyWithin(0, 1);
    osc.hist[osc.hist.length - 1] = td ? Math.min(1, p * 1.25) : osc.hist[osc.hist.length - 2] * 0.85;
  }
  const n = osc.hist.length;
  const leftW = Math.min(Math.max(30, cx - (PACK.cl[0] + packs.l) - 10), 110);
  const cols = Math.min(n, Math.floor(leftW / step));
  g.save();
  g.shadowColor = "rgba(255,120,0,0.9)"; g.shadowBlur = 6;
  for (let i = 0; i < cols; i++) {
    const v = osc.hist[n - 1 - i];
    const x = Math.round(cx - 6 - i * step) + 0.5;
    const h = 3 + v * half * (1 - i / (cols * 1.6));
    g.strokeStyle = `rgba(255,${150 + Math.round(60 * v)},60,${(0.95 - i / cols * 0.75).toFixed(3)})`;
    g.lineWidth = 1.6;
    g.beginPath(); g.moveTo(x, cy - h); g.lineTo(x, cy + h); g.stroke();
  }
  // côté droit : écho atténué
  const rightW = Math.min(Math.max(20, (PACK.cr[0] - packs.r) - cx - 10), 90);
  const rc = Math.floor(rightW / (step * 1.6));
  for (let i = 0; i < rc; i++) {
    const v = osc.hist[n - 1 - i * 2] || 0;
    const x = Math.round(cx + 8 + i * step * 1.6) + 0.5;
    const h = 2 + v * half * 0.45 * (1 - i / rc);
    g.strokeStyle = `rgba(255,170,90,${(0.55 - i / rc * 0.45).toFixed(3)})`;
    g.lineWidth = 1.2;
    g.beginPath(); g.moveTo(x, cy - h); g.lineTo(x, cy + h); g.stroke();
  }
  // tête de lecture
  g.strokeStyle = "rgba(255,190,90,0.95)"; g.lineWidth = 2;
  g.beginPath(); g.moveTo(cx + 0.5, cy - 58); g.lineTo(cx + 0.5, cy + 58); g.stroke();
  g.restore();
  g.strokeStyle = "rgba(255,150,60,0.18)"; g.lineWidth = 1;
  g.beginPath(); g.moveTo(cx - leftW, cy + 0.5); g.lineTo(cx + rightW, cy + 0.5); g.stroke();
}

/* ================================================================== pochette */
var coverToken = 0;
function setCover(url, isFavicon = false) {
  const tok = ++coverToken;
  S.coverUrl = "";
  document.body.classList.remove("hascover");
  if (!url) { updateMediaSession(); return; }
  const im = new Image();
  im.referrerPolicy = "no-referrer";
  im.onload = () => {
    if (tok !== coverToken) return;
    if (isFavicon && im.naturalWidth < 96) return; // icône trop petite : on garde la plaque
    $("#coverImg").src = url;
    S.coverUrl = url;
    document.body.classList.add("hascover");
    updateMediaSession();
  };
  im.src = url;
}

/* ================================================================== égaliseur 10 bandes */
const EQ_PRESETS = {
  "Plat":      [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
  "Loudness":  [6, 5, 3, 1, 0, 0, 0, 1, 3, 4],
  "Rock":      [5, 4, 2, -1, -2, -1, 1, 3, 4, 5],
  "Pop":       [-1, 1, 3, 4, 3, 1, -1, -1, 0, 1],
  "Jazz":      [3, 2, 1, 2, -1, -1, 0, 1, 2, 3],
  "Classique": [4, 3, 2, 1, -1, -1, 0, 2, 3, 4],
  "Électro":   [5, 4, 1, 0, -2, 1, 0, 1, 4, 5],
  "Hip-hop":   [6, 5, 2, 3, -1, -1, 1, 0, 2, 3],
  "Voix":      [-3, -2, -1, 1, 3, 4, 4, 3, 1, -1],
  "Graves +":  [7, 6, 5, 3, 1, 0, 0, 0, 0, 0],
  "Aigus +":   [0, 0, 0, 0, 0, 1, 2, 4, 6, 7],
  "Nuit":      [-2, -1, 0, 1, 2, 2, 1, 0, -2, -4],
};
const fmtHz = (f) => (f >= 1000 ? `${f / 1000}k` : `${f}`);

function buildEq() {
  const pr = $("#eqPresets");
  for (const name of Object.keys(EQ_PRESETS)) {
    const b = document.createElement("button");
    b.textContent = name; b.dataset.p = name;
    b.addEventListener("click", (e) => { e.stopPropagation(); applyPreset(name); });
    pr.appendChild(b);
  }
  const bands = $("#eqBands");
  const mk = (label, val, cls, onInput) => {
    const d = document.createElement("div");
    d.className = "band " + cls;
    d.innerHTML = `<span class="db"></span><input type="range" min="-12" max="12" step="0.5"><span class="hz"></span>`;
    d.querySelector(".hz").textContent = label;
    const inp = d.querySelector("input");
    inp.value = val;
    const show = () => { const v = +inp.value; d.querySelector(".db").textContent = (v > 0 ? "+" : "") + v.toFixed(v % 1 ? 1 : 0); };
    show();
    inp.addEventListener("input", () => { show(); onInput(+inp.value); });
    inp.addEventListener("dblclick", () => { inp.value = 0; show(); onInput(0); });
    bands.appendChild(d);
    return { inp, show };
  };
  S.eqUi = [];
  S.eqUiPre = mk("Préampli", S.eqPre, "pre", (v) => { S.eqPre = v; eqChanged(true); });
  EQ_FREQS.forEach((f, i) => S.eqUi.push(mk(fmtHz(f), S.eqGains[i], "", (v) => { S.eqGains[i] = v; eqChanged(true); })));
  $("#eqPower").addEventListener("click", (e) => { e.stopPropagation(); toggleEq(); });
  $("#eqReset").addEventListener("click", (e) => { e.stopPropagation(); applyPreset("Plat"); });
  renderEqPower();
}
function eqChanged(manual) {
  if (manual) S.eqPreset = "Personnalisé";
  if (!S.eq) { S.eq = true; store.set("eq", true); renderButtons(); renderEqPower(); }
  store.set("eqGains", S.eqGains); store.set("eqPre", S.eqPre); store.set("eqPreset", S.eqPreset);
  document.querySelectorAll("#eqPresets button").forEach((b) => b.classList.toggle("on", b.dataset.p === S.eqPreset));
  if ($("#playlist").dataset.tab === "eq") $("#plCount").textContent = S.eqPreset;
  applyEq();
}
function applyPreset(name) {
  S.eqGains = EQ_PRESETS[name].slice();
  S.eqPre = -Math.max(0, ...S.eqGains) / 2;
  S.eqPreset = name;
  S.eqUi.forEach((u, i) => { u.inp.value = S.eqGains[i]; u.show(); });
  S.eqUiPre.inp.value = S.eqPre; S.eqUiPre.show();
  eqChanged(false);
  flash(`ÉGALISEUR ${name.toUpperCase()}`, "none", 1200);
}
function renderEqPower() {
  const b = $("#eqPower");
  if (!b) return;
  b.textContent = S.eq ? "Activé" : "Désactivé";
  b.classList.toggle("off", !S.eq);
  $("#viewEq").classList.toggle("off", !S.eq);
  document.querySelectorAll("#eqPresets button").forEach((x) => x.classList.toggle("on", x.dataset.p === S.eqPreset));
  drawEqCurve();
}
function drawEqCurve() {
  const c = $("#eqCurve"); if (!c || !ctx || !eqNodes.length) return;
  const g = c.getContext("2d"), W = c.width, H = c.height;
  g.clearRect(0, 0, W, H);
  const N = 240, fr = new Float32Array(N), mag = new Float32Array(N), ph = new Float32Array(N), tot = new Float32Array(N);
  for (let i = 0; i < N; i++) fr[i] = 20 * Math.pow(1000, i / (N - 1));
  for (const b of eqNodes) {
    const tmp = ctx.createBiquadFilter();
    tmp.type = b.type; tmp.frequency.value = b.frequency.value; tmp.Q.value = b.Q.value;
    tmp.gain.value = S.eq ? S.eqGains[eqNodes.indexOf(b)] : 0;
    tmp.getFrequencyResponse(fr, mag, ph);
    for (let i = 0; i < N; i++) tot[i] += 20 * Math.log10(mag[i] || 1e-6);
  }
  const pre = S.eq ? S.eqPre : 0;
  // grille 0 dB
  const x0 = W / 11, y = (db) => H / 2 - (db / 15) * (H / 2 - 10);
  g.strokeStyle = "rgba(255,138,18,.18)"; g.lineWidth = 1;
  for (const d of [-12, -6, 0, 6, 12]) { g.beginPath(); g.moveTo(x0, y(d) + 0.5); g.lineTo(W, y(d) + 0.5); g.stroke(); }
  g.beginPath();
  for (let i = 0; i < N; i++) {
    const x = x0 + (i / (N - 1)) * (W - x0);
    const v = Math.max(-15, Math.min(15, tot[i] + pre));
    i ? g.lineTo(x, y(v)) : g.moveTo(x, y(v));
  }
  g.strokeStyle = "rgba(255,160,50,.9)"; g.lineWidth = 2.2;
  g.shadowColor = "rgba(255,120,0,.8)"; g.shadowBlur = 8; g.stroke();
  g.shadowBlur = 0;
  g.lineTo(W, H); g.lineTo(x0, H); g.closePath();
  const fill = g.createLinearGradient(0, 0, 0, H);
  fill.addColorStop(0, "rgba(255,138,18,.22)"); fill.addColorStop(1, "rgba(255,138,18,0)");
  g.fillStyle = fill; g.fill();
}

/* ================================================================== enregistrement radio */
function setRecState(r) {
  if (!r) return;
  const was = S.rec && S.rec.recording;
  S.rec = r; S.recAt = performance.now();
  $("#rRec").classList.toggle("on", !!r.recording);
  $("#rRec").textContent = r.recording ? "■ STOP REC" : "● REC";
  document.body.classList.toggle("recording", !!r.recording);
  if (was && !r.recording) {
    showRecSaved(r);
  }
  reportState(true);
}
function showRecSaved(r) {
  const m = $("#rMsg");
  m.innerHTML = "";
  m.append(`Enregistrement terminé${r.files ? ` (${r.files} fichier${r.files > 1 ? "s" : ""})` : ""} · `);
  const a = document.createElement("button");
  a.className = "act"; a.textContent = "Ouvrir le dossier";
  a.addEventListener("click", (e) => { e.stopPropagation(); api("/api/recdir"); });
  m.append(a);
}
async function startRec() {
  if (!isRadio() || audio.paused) { flash("LANCEZ UNE RADIO", "none", 1600); return; }
  try {
    setRecState(await api(`/api/radio/rec?on=1&name=${encodeURIComponent(S.radio.name || "Radio")}`));
    flash("ENREGISTREMENT", "none", 1200);
  } catch {}
}
async function stopRec() {
  try { setRecState(await api("/api/radio/rec?on=0")); } catch {}
}
function toggleRec() { (S.rec && S.rec.recording) ? stopRec() : startRec(); }
$("#rRec").addEventListener("click", (e) => { e.stopPropagation(); toggleRec(); });

/* ================================================================== historique des titres */
async function showHistory() {
  S.radioMode = "hist";
  $("#hTools").classList.remove("hidden");
  $("#rMsg").textContent = "";
  const r = await api("/api/radio/history").catch(() => ({ items: [] }));
  const items = r.items || [];
  const ol = $("#rList");
  ol.innerHTML = "";
  const today = new Date().toDateString();
  for (const it of items) {
    const d = new Date(it.time);
    const li = document.createElement("li");
    li.className = "hist";
    const tm = d.toDateString() === today ? d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" })
      : d.toLocaleDateString("fr-FR", { day: "2-digit", month: "2-digit" }) + " " + d.toLocaleTimeString("fr-FR", { hour: "2-digit", minute: "2-digit" });
    li.innerHTML = `<span class="tm"></span><span class="t"></span><span class="i"></span><span class="acts">
      <button class="act" data-a="copy" title="Copier le titre">Copier</button>
      <button class="act" data-a="youtube" title="Chercher sur YouTube">YouTube</button>
      <button class="act" data-a="spotify" title="Chercher sur Spotify">Spotify</button>
      <button class="act" data-a="google" title="Chercher sur le Web">Web</button></span>`;
    li.querySelector(".tm").textContent = tm;
    li.querySelector(".t").textContent = it.title;
    li.querySelector(".i").textContent = it.station;
    li.addEventListener("click", async (e) => {
      const a = e.target.dataset && e.target.dataset.a;
      if (!a) return;
      e.stopPropagation();
      if (a === "copy") {
        try { await navigator.clipboard.writeText(it.title); flash("TITRE COPIÉ", "none", 1000); } catch { flash("COPIE IMPOSSIBLE", "none", 1200); }
      } else api(`/api/websearch?s=${a}&q=${encodeURIComponent(it.title)}`);
    });
    ol.appendChild(li);
  }
  $("#hInfo").textContent = items.length ? `${items.length} titre${items.length > 1 ? "s" : ""} entendu${items.length > 1 ? "s" : ""}` : "";
  $("#plCount").textContent = "Historique";
  if (!items.length) $("#rMsg").textContent = "Aucun titre pour l'instant : les titres diffusés par les radios s'ajoutent ici automatiquement.";
}
$("#hClear").addEventListener("click", async (e) => {
  e.stopPropagation();
  if (!confirm("Effacer tout l'historique des titres ?")) return;
  await api("/api/radio/history?clear=1");
  showHistory();
});
// le bouton « Historique » des puces de genre
$("#rChips").addEventListener("click", (e) => {
  const b = e.target.closest("button"); if (!b) return;
  $("#hTools").classList.toggle("hidden", b.dataset.tag !== "@hist");
  if (b.dataset.tag === "@hist") { e.stopImmediatePropagation(); selectChip("@hist"); showHistory(); }
}, true);
// rafraîchir l'historique s'il est affiché quand un titre change
setInterval(() => {
  if (S.radioMode === "hist" && $("#playlist").dataset.tab === "radio" && !$("#playlist").classList.contains("hidden") && isRadio() && !audio.paused) showHistory();
}, 15000);

/* ================================================================== fenêtre native */
if (S.native) {
  document.body.classList.add("native");
  // déplacer la fenêtre en faisant glisser le boîtier
  $("#deck").addEventListener("pointerdown", (e) => {
    if (e.button !== 0) return;
    if (e.target !== $("#deck") && !e.target.closest(".lcd, #status")) return;
    try { window.chrome.webview.postMessage("drag"); } catch {}
  });
  $("#wMin").addEventListener("click", (e) => { e.stopPropagation(); api("/api/win?cmd=min"); });
  $("#wTray").addEventListener("click", (e) => { e.stopPropagation(); api("/api/win?cmd=hide"); });
  $("#wClose").addEventListener("click", (e) => { e.stopPropagation(); api("/api/win?cmd=close"); });
}
function zoomWindow(d) {
  if (S.native) api(`/api/win?cmd=zoom&d=${d}`);
  else sizeTo(Math.round(innerWidth * (d > 0 ? 1.1 : 1 / 1.1)));
}
async function switchMode(m) {
  const txt = m === "edge"
    ? "Passer à la fenêtre Edge classique (avec barre de titre) ? Le lecteur va redémarrer."
    : "Passer à la fenêtre native sans cadre ? Le lecteur va redémarrer.\nSi elle ne s'ouvre pas, le lecteur reviendra automatiquement à la fenêtre classique.";
  if (!confirm(txt)) return;
  await api(`/api/win?cmd=mode&v=${m}`).catch(() => {});
}

/* ================================================================== zone de notification / miniature */
// commandes reçues de l'icône de notification et des boutons de la miniature
(() => {
  let es;
  const open = () => {
    es = new EventSource(`/api/events?t=${TOKEN}`);
    es.onmessage = (e) => {
      resumeAudio();
      switch (e.data) {
        case "toggle": toggle(); break;
        case "next": step(1); break;
        case "prev": step(-1); break;
        case "stop": stop(); break;
        case "radio": toggleList(true, "radio"); break;
        case "rec": toggleRec(); break;
        case "update": refreshUpdate(true); break;
      }
    };
    es.onerror = () => { es.close(); setTimeout(open, 3000); };
  };
  open();
})();

var lastState = "", lastStateAt = 0;
function reportState(force) {
  const t = cur();
  const live = isRadio();
  const title = live ? radioTitleText() : t ? displayTitle(t) : "";
  const playing = !audio.paused;
  const prog = !live && audio.duration > 0 && isFinite(audio.duration) ? (audio.currentTime / audio.duration).toFixed(3) : 0;
  const rec = S.rec && S.rec.recording ? 1 : 0;
  const key = `${playing}|${live}|${rec}|${title}`;
  const now = performance.now();
  if (!force && key === lastState && now - lastStateAt < 2000) return;
  lastState = key; lastStateAt = now;
  api(`/api/win?cmd=state&playing=${playing ? 1 : 0}&live=${live ? 1 : 0}&rec=${rec}&prog=${prog}&title=${encodeURIComponent(title)}`).catch(() => {});
}
setInterval(() => { if (!audio.paused) reportState(true); }, 2000);

buildEq();

/* libellés : resserrés si la police de remplacement est plus large */
function fitLabels() {
  document.querySelectorAll(".fit").forEach((el) => {
    el.style.transform = "none";
    const max = +el.dataset.w, w = el.scrollWidth;
    if (w > max) el.style.transform = `scaleX(${(max / w).toFixed(3)})`;
  });
}
fitLabels();
if (document.fonts) document.fonts.ready.then(fitLabels);


/* ================================================================== mises à jour */
let U = { state: "disabled", auto: true, busy: false };
let uTimer = 0;

async function refreshUpdate(show) {
  try { U = { ...U, ...(await api("/api/update/status")) }; } catch { return; }
  $("#helpVer").textContent = `version ${U.current || ""}`;
  if (show && (U.state === "available" || U.state === "ready")) renderUpdate();
  if (!$("#update").classList.contains("hidden")) renderUpdate();
}

function renderUpdate() {
  const box = $("#update");
  box.classList.remove("hidden");
  const st = U.state;
  const mo = U.size ? ` · ${(U.size / 1048576).toFixed(1)} Mo` : "";
  $("#uTitle").textContent =
    st === "uptodate" ? "Cassette Deck est à jour" :
    st === "checking" ? "Recherche de mises à jour…" :
    st === "error" ? "Mise à jour impossible" :
    st === "ready" ? "Mise à jour prête" : "Mise à jour disponible";
  $("#uSub").textContent = st === "uptodate"
    ? `Vous utilisez la dernière version (${U.current}).`
    : U.latest ? `Version ${U.latest} — vous avez la version ${U.current}${mo}` : "";
  $("#uNotes").textContent = (st === "available" || st === "ready" || st === "downloading") ? (U.notes || "") : "";
  const dl = st === "downloading";
  $("#uBar").classList.toggle("hidden", !dl && st !== "ready");
  $("#uFill").style.width = `${Math.round((st === "ready" ? 1 : U.progress || 0) * 100)}%`;
  $("#uMsg").textContent = st === "error" ? U.error || "" :
    dl ? `Téléchargement… ${Math.round((U.progress || 0) * 100)} %` :
    st === "ready" ? "Fichier téléchargé et vérifié (signature et empreinte)." : "";
  const go = $("#uGo"), later = $("#uLater"), skip = $("#uSkip");
  go.style.display = st === "available" || st === "ready" || dl ? "" : "none";
  go.disabled = dl;
  go.textContent = st === "ready" ? "Installer et redémarrer" : dl ? "Téléchargement…" : "Télécharger et installer";
  skip.style.display = st === "available" ? "" : "none";
  later.textContent = st === "available" || st === "ready" || dl ? "Plus tard" : "Fermer";
  U.busy = dl;
  clearTimeout(uTimer);
  if (dl || st === "checking") uTimer = setTimeout(() => refreshUpdate(false), 400);
}

$("#uGo").addEventListener("click", async (e) => {
  e.stopPropagation();
  if (U.state === "ready") {
    $("#uMsg").textContent = "Installation… Cassette Deck va redémarrer.";
    $("#uGo").disabled = true;
    const r = await api("/api/update/apply").catch(() => ({ error: "serveur local injoignable" }));
    if (r.error) { $("#uMsg").textContent = r.error; $("#uGo").disabled = false; }
    return;
  }
  U = { ...U, ...(await api("/api/update/download")) };
  renderUpdate();
});
$("#uLater").addEventListener("click", (e) => { e.stopPropagation(); $("#update").classList.add("hidden"); U.busy = false; });
$("#uSkip").addEventListener("click", async (e) => {
  e.stopPropagation();
  await api("/api/update/skip");
  $("#update").classList.add("hidden");
});

async function manualCheck() {
  U.state = "checking"; renderUpdate();
  U = { ...U, ...(await api("/api/update/check").catch(() => ({ state: "error", error: "serveur local injoignable" }))) };
  renderUpdate();
}
async function toggleAutoUpdate() {
  U = { ...U, ...(await api(`/api/update/auto?on=${U.auto ? 0 : 1}`)) };
  flash(U.auto ? "MÀJ AUTO OUI" : "MÀJ AUTO NON", "none", 1200);
}
refreshUpdate(false);
