//go:build windows

package main

import (
	"encoding/base64"
	"errors"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"time"
	"unicode/utf16"
	"unsafe"
)

const (
	mbOK        = 0x0
	mbYesNo     = 0x4
	mbIconError = 0x10
	mbIconQuest = 0x20
	mbIconInfo  = 0x40
	mbTopMost   = 0x40000
	mbSetForegr = 0x10000
	idYes       = 6
	createNoWin = 0x08000000
	detached    = 0x00000008
	swRestore   = 9
)

var (
	user32              = syscall.NewLazyDLL("user32.dll")
	advapi32            = syscall.NewLazyDLL("advapi32.dll")
	procMessageBoxW     = user32.NewProc("MessageBoxW")
	procEnumWindows     = user32.NewProc("EnumWindows")
	procGetWindowTextW  = user32.NewProc("GetWindowTextW")
	procIsWindowVisible = user32.NewProc("IsWindowVisible")
	procShowWindow      = user32.NewProc("ShowWindow")
	procSetForeground   = user32.NewProc("SetForegroundWindow")
	procIsIconic        = user32.NewProc("IsIconic")
	procRegDeleteTreeW  = advapi32.NewProc("RegDeleteTreeW")
	procRegDeleteKeyW   = advapi32.NewProc("RegDeleteKeyW")
)

func messageBox(title, text string, flags uint32) int {
	t, _ := syscall.UTF16PtrFromString(title)
	m, _ := syscall.UTF16PtrFromString(text)
	r, _, _ := procMessageBoxW.Call(0, uintptr(unsafe.Pointer(m)), uintptr(unsafe.Pointer(t)),
		uintptr(flags|mbTopMost|mbSetForegr))
	return int(r)
}

func hidden(cmd *exec.Cmd) *exec.Cmd {
	cmd.SysProcAttr = &syscall.SysProcAttr{HideWindow: true, CreationFlags: createNoWin}
	return cmd
}

// runPS exécute un script PowerShell (encodé en base64 UTF-16LE) et renvoie la sortie.
func runPS(script string) (string, error) {
	u := utf16.Encode([]rune("[Console]::OutputEncoding=[System.Text.Encoding]::UTF8\n" + script))
	b := make([]byte, len(u)*2)
	for i, v := range u {
		b[2*i] = byte(v)
		b[2*i+1] = byte(v >> 8)
	}
	enc := base64.StdEncoding.EncodeToString(b)
	ps := filepath.Join(os.Getenv("SystemRoot"), "System32", "WindowsPowerShell", "v1.0", "powershell.exe")
	if _, err := os.Stat(ps); err != nil {
		ps = "powershell.exe"
	}
	cmd := hidden(exec.Command(ps, "-NoProfile", "-NonInteractive", "-STA", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc))
	out, err := cmd.Output()
	return string(out), err
}

func psQuote(s string) string { return "'" + strings.ReplaceAll(s, "'", "''") + "'" }

func pickDialog(mode string) ([]string, error) {
	var script string
	if mode == "folder" {
		script = `Add-Type -AssemblyName System.Windows.Forms
$o = New-Object System.Windows.Forms.Form -Property @{TopMost=$true; ShowInTaskbar=$false}
$d = New-Object System.Windows.Forms.FolderBrowserDialog
$d.Description = 'Choisir un dossier de musique'
$d.ShowNewFolderButton = $false
if ($d.ShowDialog($o) -eq [System.Windows.Forms.DialogResult]::OK) { [Console]::Out.WriteLine($d.SelectedPath) }`
	} else {
		script = `Add-Type -AssemblyName System.Windows.Forms
$o = New-Object System.Windows.Forms.Form -Property @{TopMost=$true; ShowInTaskbar=$false}
$d = New-Object System.Windows.Forms.OpenFileDialog
$d.Multiselect = $true
$d.Title = 'Charger des pistes audio'
$d.Filter = 'Fichiers audio|*.mp3;*.flac;*.wav;*.ogg;*.oga;*.opus;*.m4a;*.aac;*.webm|Tous les fichiers|*.*'
if ($d.ShowDialog($o) -eq [System.Windows.Forms.DialogResult]::OK) { foreach ($f in $d.FileNames) { [Console]::Out.WriteLine($f) } }`
	}
	out, err := runPS(script)
	if err != nil {
		return nil, err
	}
	var res []string
	for _, l := range strings.Split(strings.ReplaceAll(out, "\r", ""), "\n") {
		l = strings.TrimSpace(strings.TrimPrefix(l, "\uFEFF"))
		if l != "" {
			res = append(res, l)
		}
	}
	return res, nil
}

func findBrowser() string {
	var cands []string
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"} {
		if b := os.Getenv(env); b != "" {
			cands = append(cands,
				filepath.Join(b, "Microsoft", "Edge", "Application", "msedge.exe"))
		}
	}
	for _, env := range []string{"ProgramFiles", "ProgramFiles(x86)", "LOCALAPPDATA"} {
		if b := os.Getenv(env); b != "" {
			cands = append(cands,
				filepath.Join(b, "Google", "Chrome", "Application", "chrome.exe"),
				filepath.Join(b, "BraveSoftware", "Brave-Browser", "Application", "brave.exe"))
		}
	}
	for _, c := range cands {
		if st, err := os.Stat(c); err == nil && !st.IsDir() {
			return c
		}
	}
	return ""
}

func launchUI(url, profile string) (func(), error) {
	br := findBrowser()
	if br == "" {
		// Pas d'Edge/Chrome : navigateur par défaut, sans attente de processus.
		exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", url).Start()
		return nil, nil
	}
	os.MkdirAll(profile, 0o755)
	cmd := exec.Command(br,
		"--app="+url,
		"--user-data-dir="+profile,
		"--window-size=940,520",
		"--no-first-run",
		"--no-default-browser-check",
		"--disable-sync",
		"--force-dark-mode",
		"--autoplay-policy=no-user-gesture-required",
		"--disable-background-mode",
		"--disable-features=Translate,msEdgeSidebarV2,msHubApps,msImplicitSignin,msEdgeShopping,EdgeCollections,msUndersideButton,msEdgeStartupBoost",
	)
	if err := cmd.Start(); err != nil {
		return nil, errors.New("Impossible de lancer Microsoft Edge : " + err.Error())
	}
	return func() { cmd.Wait() }, nil
}

var (
	focusOnce   sync.Once
	focusCB     uintptr
	focusPrefix string
	focusMu     sync.Mutex
)

func focusWindow(prefix string) {
	time.Sleep(150 * time.Millisecond)
	focusMu.Lock()
	defer focusMu.Unlock()
	focusPrefix = prefix
	focusOnce.Do(func() { focusCB = syscall.NewCallback(enumProc) })
	procEnumWindows.Call(focusCB, 0)
}

func enumProc(hwnd uintptr, _ uintptr) uintptr {
	prefix := focusPrefix
	{
		vis, _, _ := procIsWindowVisible.Call(hwnd)
		if vis == 0 {
			return 1
		}
		buf := make([]uint16, 256)
		procGetWindowTextW.Call(hwnd, uintptr(unsafe.Pointer(&buf[0])), 256)
		if strings.HasPrefix(syscall.UTF16ToString(buf), prefix) {
			if ic, _, _ := procIsIconic.Call(hwnd); ic != 0 {
				procShowWindow.Call(hwnd, swRestore)
			}
			procSetForeground.Call(hwnd)
			return 0
		}
		return 1
	}
}

func revealInExplorer(p string) {
	hidden(exec.Command("explorer.exe", "/select,", p)).Start()
}

func regDeleteTree(sub string) {
	const hkcu = 0x80000001
	s, _ := syscall.UTF16PtrFromString(sub)
	procRegDeleteTreeW.Call(hkcu, uintptr(unsafe.Pointer(s)))
	// RegDeleteTree vide la clé mais ne la supprime pas : on la retire ensuite.
	procRegDeleteKeyW.Call(hkcu, uintptr(unsafe.Pointer(s)))
}

// uninstall supprime raccourcis, clés de registre, données et dossier d'installation.
func uninstall() {
	if messageBox(AppName, "Désinstaller "+AppName+" ?\n\nLes raccourcis, la liste de lecture et les réglages seront supprimés. Vos fichiers audio ne sont pas touchés.", mbYesNo|mbIconQuest) != idYes {
		return
	}
	exe, _ := os.Executable()
	dir := filepath.Dir(exe)
	data := dataDir()

	runPS(`$p = Get-CimInstance Win32_Process | Where-Object { $_.CommandLine -like '*` + strings.ReplaceAll(filepath.Join(data, "EdgeProfile"), "'", "''") + `*' }
foreach ($x in $p) { try { Invoke-CimMethod -InputObject $x -MethodName Terminate | Out-Null } catch {} }
Get-Process -Name 'CassetteDeck' -ErrorAction SilentlyContinue | Where-Object { $_.Id -ne ` + itoa(os.Getpid()) + ` } | Stop-Process -Force -ErrorAction SilentlyContinue
$lnk = @([IO.Path]::Combine([Environment]::GetFolderPath('Programs'), '` + AppName + `.lnk'), [IO.Path]::Combine([Environment]::GetFolderPath('Programs'), '` + AppName + ` (mode compatibilité).lnk'), [IO.Path]::Combine([Environment]::GetFolderPath('Desktop'), '` + AppName + `.lnk'))
foreach ($l in $lnk) { Remove-Item -LiteralPath $l -Force -ErrorAction SilentlyContinue }`)

	regDeleteTree(`Software\Microsoft\Windows\CurrentVersion\Uninstall\` + AppID)
	regDeleteTree(`Software\Classes\Applications\CassetteDeck.exe`)
	hidden(exec.Command("reg", "delete", `HKCU\Software\Microsoft\Windows\CurrentVersion\Run`, "/v", AppID, "/f")).Run()
	for _, e := range []string{".mp3", ".flac", ".wav", ".ogg", ".opus", ".m4a", ".aac"} {
		regDeleteTree(`Software\Classes\` + e + `\OpenWithList\CassetteDeck.exe`)
	}

	time.Sleep(800 * time.Millisecond)
	os.RemoveAll(data)

	messageBox(AppName, AppName+" a été désinstallé.", mbOK|mbIconInfo)

	// Le dossier contenant l'exécutable est supprimé une fois le processus terminé.
	cmdExe := filepath.Join(os.Getenv("SystemRoot"), "System32", "cmd.exe")
	cmd := hidden(exec.Command(cmdExe))
	cmd.SysProcAttr.CmdLine = `"` + cmdExe + `" /C "ping 127.0.0.1 -n 3 > nul & rmdir /S /Q ` + psQuoteCmd(dir) + `"`
	cmd.SysProcAttr.CreationFlags |= detached
	cmd.Start()
	os.Exit(0)
}

func psQuoteCmd(s string) string { return `"` + s + `"` }

func itoa(i int) string {
	if i == 0 {
		return "0"
	}
	var b []byte
	for i > 0 {
		b = append([]byte{byte('0' + i%10)}, b...)
		i /= 10
	}
	return string(b)
}
