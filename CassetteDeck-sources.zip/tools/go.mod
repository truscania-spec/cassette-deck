module cassettedecktools

go 1.22
