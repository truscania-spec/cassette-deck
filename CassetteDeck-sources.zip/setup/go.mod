module cassettedecksetup

go 1.22
