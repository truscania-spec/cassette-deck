//go:build windows

package main

// Fenêtre hôte Windows :
//   - mode natif : fenêtre sans cadre aux coins arrondis contenant une WebView2
//     (moteur Edge intégré à Windows), pilotée directement en COM, sans DLL tierce ;
//   - mode compatibilité : fenêtre application Microsoft Edge (version 1.x).
// Dans les deux cas : icône dans la zone de notification ; en mode natif,
// boutons ⏮ ⏯ ⏭ dans la miniature de la barre des tâches et progression.
//
// Si la fenêtre native échoue (WebView2 absent, erreur, plantage au lancement
// précédent), le lecteur bascule automatiquement en mode compatibilité.

import (
	"encoding/json"
	"fmt"
	"math"
	"net/url"
	"os"
	"os/exec"
	"path/filepath"
	"runtime"
	"sort"
	"strconv"
	"strings"
	"sync"
	"syscall"
	"time"
	"unsafe"
)

// ------------------------------------------------------------------ Win32

const (
	wmNull          = 0x0000
	wmDestroy       = 0x0002
	wmMove          = 0x0003
	wmSize          = 0x0005
	wmClose         = 0x0010
	wmSetIcon       = 0x0080
	wmNCLButtonDown = 0x00A1
	wmCommand       = 0x0111
	wmTimer         = 0x0113
	wmLButtonUp     = 0x0202
	wmLButtonDblClk = 0x0203
	wmRButtonUp     = 0x0205
	wmExitSizeMove  = 0x0232
	wmDpiChanged    = 0x02E0
	wmApp           = 0x8000
	wmAppRun        = wmApp + 1
	wmAppTray       = wmApp + 2
	wmAppDrag       = wmApp + 3

	wsPopup        = 0x80000000
	wsSysMenu      = 0x00080000
	wsMinimizeBox  = 0x00020000
	wsClipChildren = 0x02000000
	wsExAppWindow  = 0x00040000

	swHide     = 0
	swShow     = 5
	swMinimize = 6

	swpNoZOrder   = 0x0004
	swpNoActivate = 0x0010

	htCaption      = 2
	imageIcon      = 1
	smCxScreen     = 0
	smCyScreen     = 1
	smCxIcon       = 11
	smCyIcon       = 12
	smSwapBtn      = 23
	smCxSmIcon     = 49
	smCySmIcon     = 50
	idcArrow       = 32512
	vkLButton      = 0x01
	vkRButton      = 0x02
	mfString       = 0x0000
	mfSeparator    = 0x0800
	mfGrayed       = 0x0001
	tpmReturnCmd   = 0x0100
	tpmRightButton = 0x0002
	tpmBottomAlign = 0x0020

	nimAdd     = 0
	nimModify  = 1
	nimDelete  = 2
	nifMessage = 0x1
	nifIcon    = 0x2
	nifTip     = 0x4

	thbIcon     = 0x2
	thbTooltip  = 0x4
	thbFlags    = 0x8
	thbnClicked = 0x1800

	tbpfNoProgress    = 0x0
	tbpfIndeterminate = 0x1
	tbpfNormal        = 0x2
	tbpfError         = 0x4
	tbpfPaused        = 0x8

	timerFallback = 1
)

var (
	kernel32 = syscall.NewLazyDLL("kernel32.dll")
	ole32    = syscall.NewLazyDLL("ole32.dll")
	shell32  = syscall.NewLazyDLL("shell32.dll")
	gdi32    = syscall.NewLazyDLL("gdi32.dll")

	pGetModuleHandleW   = kernel32.NewProc("GetModuleHandleW")
	pCoInitializeEx     = ole32.NewProc("CoInitializeEx")
	pCoCreateInstance   = ole32.NewProc("CoCreateInstance")
	pCoTaskMemFree      = ole32.NewProc("CoTaskMemFree")
	pShellNotifyIconW   = shell32.NewProc("Shell_NotifyIconW")
	pCreateRoundRectRgn = gdi32.NewProc("CreateRoundRectRgn")
	pCreateSolidBrush   = gdi32.NewProc("CreateSolidBrush")

	pRegisterClassExW       = user32.NewProc("RegisterClassExW")
	pCreateWindowExW        = user32.NewProc("CreateWindowExW")
	pDefWindowProcW         = user32.NewProc("DefWindowProcW")
	pDestroyWindow          = user32.NewProc("DestroyWindow")
	pGetMessageW            = user32.NewProc("GetMessageW")
	pTranslateMessage       = user32.NewProc("TranslateMessage")
	pDispatchMessageW       = user32.NewProc("DispatchMessageW")
	pPostMessageW           = user32.NewProc("PostMessageW")
	pSendMessageW           = user32.NewProc("SendMessageW")
	pPostQuitMessage        = user32.NewProc("PostQuitMessage")
	pLoadImageW             = user32.NewProc("LoadImageW")
	pLoadCursorW            = user32.NewProc("LoadCursorW")
	pGetSystemMetrics       = user32.NewProc("GetSystemMetrics")
	pSetWindowPos           = user32.NewProc("SetWindowPos")
	pGetWindowRect          = user32.NewProc("GetWindowRect")
	pSetWindowRgn           = user32.NewProc("SetWindowRgn")
	pSetWindowTextW         = user32.NewProc("SetWindowTextW")
	pReleaseCapture         = user32.NewProc("ReleaseCapture")
	pGetAsyncKeyState       = user32.NewProc("GetAsyncKeyState")
	pSetTimer               = user32.NewProc("SetTimer")
	pKillTimer              = user32.NewProc("KillTimer")
	pCreatePopupMenu        = user32.NewProc("CreatePopupMenu")
	pAppendMenuW            = user32.NewProc("AppendMenuW")
	pTrackPopupMenu         = user32.NewProc("TrackPopupMenu")
	pDestroyMenu            = user32.NewProc("DestroyMenu")
	pGetCursorPos           = user32.NewProc("GetCursorPos")
	pRegisterWindowMessageW = user32.NewProc("RegisterWindowMessageW")
	pMonitorFromPoint       = user32.NewProc("MonitorFromPoint")
	pGetDpiForSystem        = user32.NewProc("GetDpiForSystem")
	pGetDpiForWindow        = user32.NewProc("GetDpiForWindow")
)

type guid struct {
	Data1 uint32
	Data2 uint16
	Data3 uint16
	Data4 [8]byte
}

type rect struct{ Left, Top, Right, Bottom int32 }

type point struct{ X, Y int32 }

type msgT struct {
	Hwnd    uintptr
	Message uint32
	WParam  uintptr
	LParam  uintptr
	Time    uint32
	Pt      point
	Private uint32
}

type wndClassEx struct {
	Size       uint32
	Style      uint32
	WndProc    uintptr
	ClsExtra   int32
	WndExtra   int32
	Instance   uintptr
	Icon       uintptr
	Cursor     uintptr
	Background uintptr
	MenuName   *uint16
	ClassName  *uint16
	IconSm     uintptr
}

type notifyIconData struct {
	CbSize           uint32
	HWnd             uintptr
	UID              uint32
	UFlags           uint32
	UCallbackMessage uint32
	HIcon            uintptr
	SzTip            [128]uint16
	DwState          uint32
	DwStateMask      uint32
	SzInfo           [256]uint16
	UVersion         uint32
	SzInfoTitle      [64]uint16
	DwInfoFlags      uint32
	GuidItem         guid
	HBalloonIcon     uintptr
}

type thumbButton struct {
	Mask   uint32
	ID     uint32
	Bitmap uint32
	Icon   uintptr
	Tip    [260]uint16
	Flags  uint32
}

func u16(s string) *uint16 { p, _ := syscall.UTF16PtrFromString(s); return p }

func copyTip(dst []uint16, s string) {
	u, _ := syscall.UTF16FromString(s)
	if len(u) > len(dst) {
		u = u[:len(dst)-1]
		u = append(u, 0)
	}
	copy(dst, u)
}

func loword(v uintptr) int32 { return int32(int16(v & 0xFFFF)) }
func hiword(v uintptr) int32 { return int32(int16((v >> 16) & 0xFFFF)) }

// comCall appelle la méthode n° idx de la table virtuelle d'un objet COM.
func comCall(obj uintptr, idx int, args ...uintptr) uintptr {
	vtbl := *(*uintptr)(unsafe.Pointer(obj))
	fn := *(*uintptr)(unsafe.Pointer(vtbl + uintptr(idx)*unsafe.Sizeof(uintptr(0))))
	all := append([]uintptr{obj}, args...)
	r, _, _ := syscall.SyscallN(fn, all...)
	return r
}

func failed(hr uintptr) bool { return int32(uint32(hr)) < 0 }

// ------------------------------------------------------------------ objets COM (gestionnaires)

type comVtbl struct{ QueryInterface, AddRef, Release, Invoke uintptr }
type comObj struct{ vtbl *comVtbl }

var (
	cbQI      = syscall.NewCallback(func(this, riid, ppv uintptr) uintptr { *(*uintptr)(unsafe.Pointer(ppv)) = this; return 0 })
	cbAddRef  = syscall.NewCallback(func(this uintptr) uintptr { return 1 })
	cbRelease = syscall.NewCallback(func(this uintptr) uintptr { return 1 })

	envHandler  = &comObj{&comVtbl{cbQI, cbAddRef, cbRelease, syscall.NewCallback(onEnvCreated)}}
	ctrlHandler = &comObj{&comVtbl{cbQI, cbAddRef, cbRelease, syscall.NewCallback(onControllerCreated)}}
	msgHandler  = &comObj{&comVtbl{cbQI, cbAddRef, cbRelease, syscall.NewCallback(onWebMessage)}}
	navHandler  = &comObj{&comVtbl{cbQI, cbAddRef, cbRelease, syscall.NewCallback(onNavCompleted)}}

	iidController2 = guid{0xc979903e, 0xd4ca, 0x4228, [8]byte{0x92, 0xeb, 0x47, 0xee, 0x3f, 0xa9, 0x6e, 0xab}}
	clsidTaskbar   = guid{0x56FDF344, 0xFD6D, 0x11d0, [8]byte{0x95, 0x8A, 0x00, 0x60, 0x97, 0xC9, 0xA0, 0x90}}
	iidTaskbar3    = guid{0xEA1AFB91, 0x9E28, 0x4B86, [8]byte{0x90, 0xE9, 0x9E, 0x9F, 0x8A, 0x5E, 0xEF, 0xAF}}
)

// ------------------------------------------------------------------ état de l'hôte

var host struct {
	hwnd    uintptr
	hinst   uintptr
	native  bool
	ready   bool
	url     string
	profile string
	env     uintptr
	ctrl    uintptr
	webview uintptr
	taskbar uintptr
	tbMsg   uint32
	trayOn  bool
	iconBig uintptr
	iconSm  uintptr
	tbIcons map[string]uintptr
	edge    *exec.Cmd
	lastW   int32

	qmu   sync.Mutex
	queue []func()

	smu   sync.Mutex
	state PlayerState
}

var wndProcCB = syscall.NewCallback(wndProc)

func hostLog(format string, a ...any) {
	p := filepath.Join(dataDir(), "journal.txt")
	if st, err := os.Stat(p); err == nil && st.Size() > 200*1024 {
		os.Remove(p)
	}
	f, err := os.OpenFile(p, os.O_CREATE|os.O_APPEND|os.O_WRONLY, 0o644)
	if err != nil {
		return
	}
	fmt.Fprintf(f, "%s  %s\r\n", time.Now().Format("2006-01-02 15:04:05"), fmt.Sprintf(format, a...))
	f.Close()
}

// post exécute fn sur le fil de la fenêtre.
func post(fn func()) {
	host.qmu.Lock()
	host.queue = append(host.queue, fn)
	host.qmu.Unlock()
	if host.hwnd != 0 {
		pPostMessageW.Call(host.hwnd, wmAppRun, 0, 0)
	}
}

// ------------------------------------------------------------------ préférence de mode

func modeFile() string { return filepath.Join(dataDir(), "fenetre.txt") }

func readMode() string {
	b, _ := os.ReadFile(modeFile())
	return strings.TrimSpace(string(b))
}

func writeMode(m string) { os.WriteFile(modeFile(), []byte(m), 0o644) }

// firstBeat est appelé au premier signe de vie de la page.
func firstBeat() {
	if host.native && readMode() == "essai" {
		writeMode("natif")
		hostLog("fenêtre native opérationnelle")
	}
}

// ------------------------------------------------------------------ fenêtre

type winPos struct{ X, Y, W int32 }

func posFile() string { return filepath.Join(dataDir(), "position.json") }

func dpi() int32 {
	if host.hwnd != 0 && pGetDpiForWindow.Find() == nil {
		if d, _, _ := pGetDpiForWindow.Call(host.hwnd); d > 0 {
			return int32(d)
		}
	}
	if pGetDpiForSystem.Find() == nil {
		if d, _, _ := pGetDpiForSystem.Call(); d > 0 {
			return int32(d)
		}
	}
	return 96
}

func heightFor(w int32) int32 { return int32(math.Round(float64(w) * 786 / 1602)) }

func initialRect() (x, y, w, h int32) {
	w = 900 * dpi() / 96
	var p winPos
	if b, err := os.ReadFile(posFile()); err == nil && json.Unmarshal(b, &p) == nil && p.W >= 300 && p.W <= 8000 {
		w = p.W
		h = heightFor(w)
		pt := point{p.X + w/2, p.Y + h/2}
		if m, _, _ := pMonitorFromPoint.Call(uintptr(*(*uint64)(unsafe.Pointer(&pt))), 0); m != 0 {
			return p.X, p.Y, w, h
		}
	}
	h = heightFor(w)
	sw, _, _ := pGetSystemMetrics.Call(smCxScreen)
	sh, _, _ := pGetSystemMetrics.Call(smCyScreen)
	return (int32(sw) - w) / 2, (int32(sh) - h) / 2, w, h
}

func savePos() {
	var r rect
	pGetWindowRect.Call(host.hwnd, uintptr(unsafe.Pointer(&r)))
	if r.Right-r.Left < 200 {
		return
	}
	b, _ := json.Marshal(winPos{r.Left, r.Top, r.Right - r.Left})
	os.WriteFile(posFile(), b, 0o644)
}

func applyRegion(w, h int32) {
	if !host.native || w <= 0 || h <= 0 {
		return
	}
	s := float64(w) / 1602
	in := func(v float64) int32 { return int32(math.Round(v * s)) }
	rgn, _, _ := pCreateRoundRectRgn.Call(uintptr(in(4)), uintptr(in(4)), uintptr(w-in(4)+1), uintptr(h-in(2)+1), uintptr(in(72)), uintptr(in(72)))
	pSetWindowRgn.Call(host.hwnd, rgn, 1)
}

func resizeTo(w int32) {
	if w < 320*dpi()/96 {
		w = 320 * dpi() / 96
	}
	sw, _, _ := pGetSystemMetrics.Call(smCxScreen)
	if w > int32(sw) {
		w = int32(sw)
	}
	var r rect
	pGetWindowRect.Call(host.hwnd, uintptr(unsafe.Pointer(&r)))
	cx, cy := (r.Left+r.Right)/2, (r.Top+r.Bottom)/2
	h := heightFor(w)
	pSetWindowPos.Call(host.hwnd, 0, uintptr(cx-w/2), uintptr(cy-h/2), uintptr(w), uintptr(h), swpNoZOrder|swpNoActivate)
	savePos()
}

func setBounds(w, h int32) {
	if host.ctrl == 0 {
		return
	}
	r := rect{0, 0, w, h}
	comCall(host.ctrl, 6, uintptr(unsafe.Pointer(&r))) // put_Bounds
}

func showMain() {
	if host.native {
		pShowWindow := procShowWindow
		pShowWindow.Call(host.hwnd, swRestore)
		pShowWindow.Call(host.hwnd, swShow)
		procSetForeground.Call(host.hwnd)
	} else {
		go focusWindow(AppName)
	}
}

func toggleMain() {
	if !host.native {
		go focusWindow(AppName)
		return
	}
	vis, _, _ := procIsWindowVisible.Call(host.hwnd)
	ic, _, _ := procIsIconic.Call(host.hwnd)
	if vis != 0 && ic == 0 {
		procShowWindow.Call(host.hwnd, swHide)
	} else {
		showMain()
	}
}

func quitHost() {
	if host.edge != nil && host.edge.Process != nil {
		host.edge.Process.Kill()
	}
	pDestroyWindow.Call(host.hwnd)
}

// ------------------------------------------------------------------ WebView2

// regWebView2 lit le dossier d'installation du runtime WebView2 dans le registre
// (clé ClientState d'EdgeUpdate, valeur « EBWebView »).
func regWebView2() []string {
	const id = `{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}`
	var out []string
	for _, k := range []struct {
		root syscall.Handle
		path string
	}{
		{syscall.HKEY_LOCAL_MACHINE, `SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\ClientState\` + id},
		{syscall.HKEY_LOCAL_MACHINE, `SOFTWARE\Microsoft\EdgeUpdate\ClientState\` + id},
		{syscall.HKEY_CURRENT_USER, `Software\Microsoft\EdgeUpdate\ClientState\` + id},
	} {
		var h syscall.Handle
		if syscall.RegOpenKeyEx(k.root, u16(k.path), 0, syscall.KEY_READ, &h) != nil {
			continue
		}
		buf := make([]uint16, 1024)
		n := uint32(len(buf) * 2)
		var typ uint32
		if syscall.RegQueryValueEx(h, u16("EBWebView"), nil, &typ, (*byte)(unsafe.Pointer(&buf[0])), &n) == nil {
			if d := syscall.UTF16ToString(buf); d != "" {
				dll := filepath.Join(d, "EBWebView", "x64", "EmbeddedBrowserWebView.dll")
				if _, err := os.Stat(dll); err == nil {
					out = append(out, dll)
				}
			}
		}
		syscall.RegCloseKey(h)
	}
	return out
}

func findWebView2() string {
	if r := regWebView2(); len(r) > 0 {
		return r[0]
	}
	var roots []string
	for _, env := range []string{"ProgramFiles(x86)", "ProgramFiles", "LOCALAPPDATA"} {
		if b := os.Getenv(env); b != "" {
			roots = append(roots, filepath.Join(b, "Microsoft", "EdgeWebView", "Application"))
		}
	}
	type cand struct {
		ver  []int
		path string
	}
	var cs []cand
	for _, root := range roots {
		ents, err := os.ReadDir(root)
		if err != nil {
			continue
		}
		for _, e := range ents {
			if !e.IsDir() {
				continue
			}
			parts := strings.Split(e.Name(), ".")
			if len(parts) != 4 {
				continue
			}
			var v []int
			ok := true
			for _, p := range parts {
				n, err := strconv.Atoi(p)
				if err != nil {
					ok = false
					break
				}
				v = append(v, n)
			}
			dll := filepath.Join(root, e.Name(), "EBWebView", "x64", "EmbeddedBrowserWebView.dll")
			if _, err := os.Stat(dll); ok && err == nil {
				cs = append(cs, cand{v, dll})
			}
		}
	}
	sort.Slice(cs, func(i, j int) bool {
		for k := 0; k < 4; k++ {
			if cs[i].ver[k] != cs[j].ver[k] {
				return cs[i].ver[k] > cs[j].ver[k]
			}
		}
		return false
	})
	if len(cs) == 0 {
		return ""
	}
	return cs[0].path
}

func startWebView() error {
	dll := findWebView2()
	if dll == "" {
		return fmt.Errorf("environnement WebView2 introuvable")
	}
	hostLog("WebView2 : %s", dll)
	d := syscall.NewLazyDLL(dll)
	proc := d.NewProc("CreateWebViewEnvironmentWithOptionsInternal")
	if err := proc.Find(); err != nil {
		return fmt.Errorf("point d'entrée WebView2 absent : %v", err)
	}
	os.MkdirAll(host.profile, 0o755)
	hr, _, _ := proc.Call(1, 0, uintptr(unsafe.Pointer(u16(host.profile))), 0, uintptr(unsafe.Pointer(envHandler)))
	if failed(hr) {
		return fmt.Errorf("création de l'environnement WebView2 : 0x%08X", uint32(hr))
	}
	pSetTimer.Call(host.hwnd, timerFallback, 20000, 0)
	return nil
}

func onEnvCreated(this, hr, env uintptr) uintptr {
	defer recoverLog("environnement")
	if failed(hr) || env == 0 {
		post(func() { fallbackEdge(fmt.Sprintf("environnement WebView2 refusé : 0x%08X", uint32(hr))) })
		return 0
	}
	comCall(env, 1) // AddRef
	host.env = env
	r := comCall(env, 3, host.hwnd, uintptr(unsafe.Pointer(ctrlHandler))) // CreateCoreWebView2Controller
	if failed(r) {
		post(func() { fallbackEdge(fmt.Sprintf("contrôleur WebView2 : 0x%08X", uint32(r))) })
	}
	return 0
}

func onControllerCreated(this, hr, ctrl uintptr) uintptr {
	defer recoverLog("contrôleur")
	if failed(hr) || ctrl == 0 {
		post(func() { fallbackEdge(fmt.Sprintf("création du contrôleur WebView2 : 0x%08X", uint32(hr))) })
		return 0
	}
	if host.ready || !host.native {
		return 0
	}
	comCall(ctrl, 1) // AddRef
	host.ctrl = ctrl
	var wv uintptr
	comCall(ctrl, 25, uintptr(unsafe.Pointer(&wv))) // get_CoreWebView2
	if wv == 0 {
		post(func() { fallbackEdge("CoreWebView2 indisponible") })
		return 0
	}
	host.webview = wv

	// Fond sombre opaque (évite l'éclair blanc au chargement)
	var c2 uintptr
	if r := comCall(ctrl, 0, uintptr(unsafe.Pointer(&iidController2)), uintptr(unsafe.Pointer(&c2))); !failed(r) && c2 != 0 {
		const a, rr, g, b = 0xFF, 0x07, 0x09, 0x0D
		comCall(c2, 27, uintptr(uint32(a|rr<<8|g<<16|b<<24))) // put_DefaultBackgroundColor
		comCall(c2, 2)                                        // Release
	}

	// Réglages : pas de barre d'état, pas d'outils de développement, pas de zoom Ctrl+molette
	var set uintptr
	comCall(wv, 3, uintptr(unsafe.Pointer(&set))) // get_Settings
	if set != 0 {
		comCall(set, 10, 0) // put_IsStatusBarEnabled
		comCall(set, 12, 0) // put_AreDevToolsEnabled
		comCall(set, 18, 0) // put_IsZoomControlEnabled
		comCall(set, 2)     // Release
	}

	var token, token2 int64
	comCall(wv, 34, uintptr(unsafe.Pointer(msgHandler)), uintptr(unsafe.Pointer(&token)))  // add_WebMessageReceived
	comCall(wv, 15, uintptr(unsafe.Pointer(navHandler)), uintptr(unsafe.Pointer(&token2))) // add_NavigationCompleted

	var ver *uint16
	if host.env != 0 && !failed(comCall(host.env, 5, uintptr(unsafe.Pointer(&ver)))) && ver != nil { // get_BrowserVersionString
		hostLog("version WebView2 : %s", utf16PtrToString(ver))
		pCoTaskMemFree.Call(uintptr(unsafe.Pointer(ver)))
	}

	var rc rect
	pGetWindowRect.Call(host.hwnd, uintptr(unsafe.Pointer(&rc)))
	setBounds(rc.Right-rc.Left, rc.Bottom-rc.Top)
	comCall(wv, 5, uintptr(unsafe.Pointer(u16(host.url)))) // Navigate

	host.ready = true
	pKillTimer.Call(host.hwnd, timerFallback)
	if !startHidden {
		procShowWindow.Call(host.hwnd, swShow)
		procSetForeground.Call(host.hwnd)
	}
	// la WebView a été créée dans une fenêtre encore masquée : on la déclare visible
	comCall(ctrl, 4, 1) // put_IsVisible(TRUE)
	pGetWindowRect.Call(host.hwnd, uintptr(unsafe.Pointer(&rc)))
	setBounds(rc.Right-rc.Left, rc.Bottom-rc.Top)
	comCall(ctrl, 12, 0) // MoveFocus(PROGRAMMATIC) : le clavier fonctionne tout de suite
	hostLog("fenêtre native affichée (%dx%d), chargement de la page", rc.Right-rc.Left, rc.Bottom-rc.Top)

	// garde-fou : si la page ne donne aucun signe de vie, retour à la fenêtre Edge
	go func() {
		time.Sleep(15 * time.Second)
		beatMu.Lock()
		ok := everBeat
		beatMu.Unlock()
		if !ok {
			post(func() { fallbackEdge("la page ne s'est pas affichée dans la fenêtre native") })
		}
	}()
	return 0
}

func onNavCompleted(this, sender, args uintptr) uintptr {
	defer recoverLog("navigation")
	var okv, status int32
	comCall(args, 3, uintptr(unsafe.Pointer(&okv)))    // get_IsSuccess
	comCall(args, 4, uintptr(unsafe.Pointer(&status))) // get_WebErrorStatus
	hostLog("navigation terminée : succès=%d, statut=%d", okv, status)
	return 0
}

func onWebMessage(this, sender, args uintptr) uintptr {
	defer recoverLog("message")
	var p *uint16
	if r := comCall(args, 5, uintptr(unsafe.Pointer(&p))); failed(r) || p == nil { // TryGetWebMessageAsString
		return 0
	}
	s := utf16PtrToString(p)
	pCoTaskMemFree.Call(uintptr(unsafe.Pointer(p)))
	if s == "drag" {
		pPostMessageW.Call(host.hwnd, wmAppDrag, 0, 0)
	}
	return 0
}

func utf16PtrToString(p *uint16) string {
	if p == nil {
		return ""
	}
	var u []uint16
	for ptr := unsafe.Pointer(p); ; ptr = unsafe.Add(ptr, 2) {
		c := *(*uint16)(ptr)
		if c == 0 {
			break
		}
		u = append(u, c)
		if len(u) > 1<<16 {
			break
		}
	}
	return syscall.UTF16ToString(u)
}

func recoverLog(where string) {
	if r := recover(); r != nil {
		hostLog("erreur (%s) : %v", where, r)
	}
}

// fallbackEdge abandonne la fenêtre native et ouvre la fenêtre Edge.
func fallbackEdge(reason string) {
	if !host.native {
		return
	}
	hostLog("bascule en mode compatibilité : %s", reason)
	pKillTimer.Call(host.hwnd, timerFallback)
	writeMode("edge")
	host.native = false
	nativeActive = false
	host.ready = false
	procShowWindow.Call(host.hwnd, swHide)
	pSetWindowRgn.Call(host.hwnd, 0, 0)
	if host.ctrl != 0 {
		comCall(host.ctrl, 24) // Close
		host.ctrl = 0
	}
	startEdge()
}

func startEdge() {
	start := time.Now()
	u := strings.Replace(host.url, "&native=1", "", 1)
	wait, err := launchUI(u, filepath.Join(dataDir(), "EdgeProfile"))
	if err != nil {
		messageBox(AppName, err.Error(), mbIconError)
		pDestroyWindow.Call(host.hwnd)
		return
	}
	go func() {
		if wait != nil {
			wait()
		}
		waitHeartbeats(start)
		post(func() { pDestroyWindow.Call(host.hwnd) })
	}()
}

// ------------------------------------------------------------------ zone de notification

func trayData() *notifyIconData {
	n := &notifyIconData{}
	n.CbSize = uint32(unsafe.Sizeof(*n))
	n.HWnd = host.hwnd
	n.UID = 1
	return n
}

func trayAdd() {
	n := trayData()
	n.UFlags = nifMessage | nifIcon | nifTip
	n.UCallbackMessage = wmAppTray
	n.HIcon = host.iconSm
	copyTip(n.SzTip[:], AppName)
	r, _, _ := pShellNotifyIconW.Call(nimAdd, uintptr(unsafe.Pointer(n)))
	host.trayOn = r != 0
}

func trayTip(s string) {
	if !host.trayOn {
		return
	}
	n := trayData()
	n.UFlags = nifTip
	copyTip(n.SzTip[:], s)
	pShellNotifyIconW.Call(nimModify, uintptr(unsafe.Pointer(n)))
}

func trayRemove() {
	if host.trayOn {
		pShellNotifyIconW.Call(nimDelete, uintptr(unsafe.Pointer(trayData())))
		host.trayOn = false
	}
}

func trayMenu() {
	m, _, _ := pCreatePopupMenu.Call()
	host.smu.Lock()
	st := host.state
	host.smu.Unlock()
	add := func(id uintptr, text string, flags uintptr) {
		pAppendMenuW.Call(m, mfString|flags, id, uintptr(unsafe.Pointer(u16(text))))
	}
	if st.Title != "" {
		t := st.Title
		if r := []rune(t); len(r) > 48 {
			t = string(r[:47]) + "…"
		}
		add(0, t, mfGrayed)
		pAppendMenuW.Call(m, mfSeparator, 0, 0)
	}
	if st.Playing {
		add(1, "Pause", 0)
	} else {
		add(1, "Lecture", 0)
	}
	add(2, "Piste / station suivante", 0)
	add(3, "Piste / station précédente", 0)
	if st.Live {
		if st.Recording {
			add(7, "Arrêter l'enregistrement", 0)
		} else {
			add(7, "Enregistrer la radio", 0)
		}
	}
	pAppendMenuW.Call(m, mfSeparator, 0, 0)
	vis, _, _ := procIsWindowVisible.Call(host.hwnd)
	if host.native && vis != 0 {
		add(4, "Masquer le lecteur", 0)
	} else {
		add(4, "Afficher le lecteur", 0)
	}
	add(5, "Radio en ligne", 0)
	if host.native {
		add(8, "Passer en fenêtre classique (compatibilité)", 0)
	} else {
		add(8, "Essayer la fenêtre sans cadre", 0)
	}
	add(9, "Ouvrir le journal", 0)
	pAppendMenuW.Call(m, mfSeparator, 0, 0)
	add(6, "Quitter "+AppName, 0)

	var pt point
	pGetCursorPos.Call(uintptr(unsafe.Pointer(&pt)))
	procSetForeground.Call(host.hwnd)
	cmd, _, _ := pTrackPopupMenu.Call(m, tpmReturnCmd|tpmRightButton|tpmBottomAlign, uintptr(pt.X), uintptr(pt.Y), 0, host.hwnd, 0)
	pPostMessageW.Call(host.hwnd, wmNull, 0, 0)
	pDestroyMenu.Call(m)
	switch cmd {
	case 1:
		events.emit("toggle")
	case 2:
		events.emit("next")
	case 3:
		events.emit("prev")
	case 4:
		toggleMain()
	case 5:
		showMain()
		events.emit("radio")
	case 6:
		quitHost()
	case 7:
		events.emit("rec")
	case 8:
		if host.native {
			writeMode("edge")
		} else {
			writeMode("natif")
		}
		restartApp()
	case 9:
		exec.Command("notepad.exe", filepath.Join(dataDir(), "journal.txt")).Start()
	}
}

// ------------------------------------------------------------------ barre des tâches

func loadIcon(id uintptr, small bool) uintptr {
	cx, cy := smCxIcon, smCyIcon
	if small {
		cx, cy = smCxSmIcon, smCySmIcon
	}
	w, _, _ := pGetSystemMetrics.Call(uintptr(cx))
	h, _, _ := pGetSystemMetrics.Call(uintptr(cy))
	ic, _, _ := pLoadImageW.Call(host.hinst, id, imageIcon, w, h, 0)
	return ic
}

func thumbBtn(id uint32, icon, tip string) thumbButton {
	b := thumbButton{Mask: thbIcon | thbTooltip | thbFlags, ID: id, Icon: host.tbIcons[icon]}
	copyTip(b.Tip[:], tip)
	return b
}

func taskbarInit() {
	if host.taskbar != 0 {
		return
	}
	var tb uintptr
	r, _, _ := pCoCreateInstance.Call(uintptr(unsafe.Pointer(&clsidTaskbar)), 0, 1,
		uintptr(unsafe.Pointer(&iidTaskbar3)), uintptr(unsafe.Pointer(&tb)))
	if failed(r) || tb == 0 {
		hostLog("ITaskbarList3 indisponible : 0x%08X", uint32(r))
		return
	}
	comCall(tb, 3) // HrInit
	host.taskbar = tb
}

func thumbAdd() {
	taskbarInit()
	if host.taskbar == 0 || !host.native {
		return
	}
	btns := []thumbButton{
		thumbBtn(101, "prev", "Précédent"),
		thumbBtn(102, "play", "Lecture"),
		thumbBtn(103, "next", "Suivant"),
	}
	comCall(host.taskbar, 15, host.hwnd, uintptr(len(btns)), uintptr(unsafe.Pointer(&btns[0]))) // ThumbBarAddButtons
	updateTaskbar()
}

func updateTaskbar() {
	host.smu.Lock()
	st := host.state
	host.smu.Unlock()
	title := AppName
	if st.Title != "" {
		title = AppName + " — " + st.Title
	}
	pSetWindowTextW.Call(host.hwnd, uintptr(unsafe.Pointer(u16(title))))
	tip := title
	if st.Recording {
		tip = "● REC — " + tip
	}
	trayTip(tip)
	if host.taskbar == 0 || !host.native {
		return
	}
	var b thumbButton
	if st.Playing {
		b = thumbBtn(102, "pause", "Pause")
	} else {
		b = thumbBtn(102, "play", "Lecture")
	}
	comCall(host.taskbar, 16, host.hwnd, 1, uintptr(unsafe.Pointer(&b))) // ThumbBarUpdateButtons
	switch {
	case st.Recording:
		comCall(host.taskbar, 10, host.hwnd, tbpfError) // SetProgressState
		comCall(host.taskbar, 9, host.hwnd, 100, 100)
	case st.Live && st.Playing:
		comCall(host.taskbar, 10, host.hwnd, tbpfIndeterminate)
	case st.Progress > 0 && !st.Live:
		if st.Playing {
			comCall(host.taskbar, 10, host.hwnd, tbpfNormal)
		} else {
			comCall(host.taskbar, 10, host.hwnd, tbpfPaused)
		}
		comCall(host.taskbar, 9, host.hwnd, uintptr(st.Progress*1000), 1000) // SetProgressValue
	default:
		comCall(host.taskbar, 10, host.hwnd, tbpfNoProgress)
	}
}

// ------------------------------------------------------------------ procédure de fenêtre

func wndProc(hwnd, msg, wp, lp uintptr) (ret uintptr) {
	defer func() {
		if r := recover(); r != nil {
			hostLog("erreur wndProc %d : %v", msg, r)
			ret = 0
		}
	}()
	switch uint32(msg) {
	case wmAppRun:
		host.qmu.Lock()
		q := host.queue
		host.queue = nil
		host.qmu.Unlock()
		for _, fn := range q {
			fn()
		}
		return 0
	case wmAppTray:
		switch uint32(lp & 0xFFFF) {
		case wmLButtonUp:
			toggleMain()
		case wmRButtonUp:
			trayMenu()
		}
		return 0
	case wmAppDrag:
		vk := uintptr(vkLButton)
		if sw, _, _ := pGetSystemMetrics.Call(smSwapBtn); sw != 0 {
			vk = vkRButton
		}
		if st, _, _ := pGetAsyncKeyState.Call(vk); st&0x8000 != 0 {
			pReleaseCapture.Call()
			pSendMessageW.Call(hwnd, wmNCLButtonDown, htCaption, 0)
		}
		return 0
	case wmCommand:
		if uint32(hiword(wp)&0xFFFF) == thbnClicked {
			switch loword(wp) {
			case 101:
				events.emit("prev")
			case 102:
				events.emit("toggle")
			case 103:
				events.emit("next")
			}
			return 0
		}
	case wmTimer:
		if wp == timerFallback {
			pKillTimer.Call(hwnd, timerFallback)
			if !host.ready {
				fallbackEdge("délai dépassé à la création de la WebView2")
			}
			return 0
		}
	case wmSize:
		if host.ctrl != 0 {
			if wp == 1 { // SIZE_MINIMIZED
				comCall(host.ctrl, 4, 0)
			} else {
				comCall(host.ctrl, 4, 1)
			}
		}
		w, h := loword(lp)&0xFFFF, hiword(lp)&0xFFFF
		if w > 0 && h > 0 {
			setBounds(int32(w), int32(h))
			if int32(w) != host.lastW {
				host.lastW = int32(w)
				applyRegion(int32(w), int32(h))
			}
		}
		return 0
	case wmMove:
		if host.ctrl != 0 {
			comCall(host.ctrl, 23) // NotifyParentWindowPositionChanged
		}
	case 0x0007: // WM_SETFOCUS
		if host.ctrl != 0 {
			comCall(host.ctrl, 12, 0)
		}
	case wmExitSizeMove:
		savePos()
	case wmDpiChanged:
		r := (*rect)(unsafe.Pointer(lp))
		pSetWindowPos.Call(hwnd, 0, uintptr(r.Left), uintptr(r.Top), uintptr(r.Right-r.Left), uintptr(r.Bottom-r.Top), swpNoZOrder|swpNoActivate)
		return 0
	case wmClose:
		quitHost()
		return 0
	case wmDestroy:
		if host.native {
			savePos()
		}
		pPostQuitMessage.Call(0)
		return 0
	}
	if host.tbMsg != 0 && uint32(msg) == host.tbMsg {
		thumbAdd()
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, msg, wp, lp)
	return r
}

// ------------------------------------------------------------------ point d'entrée

// runUI crée la fenêtre et tourne jusqu'à sa fermeture.
func runUI(pageURL, _ string) {
	runtime.LockOSThread()
	pCoInitializeEx.Call(0, 0x2) // COINIT_APARTMENTTHREADED

	host.hinst, _, _ = pGetModuleHandleW.Call(0)
	host.iconBig = loadIcon(1, false)
	host.iconSm = loadIcon(1, true)
	host.tbIcons = map[string]uintptr{
		"prev": loadIcon(2, true), "play": loadIcon(3, true), "pause": loadIcon(4, true), "next": loadIcon(5, true),
	}
	host.profile = filepath.Join(dataDir(), "WebView2")
	host.tbMsg = uint32(must(pRegisterWindowMessageW.Call(uintptr(unsafe.Pointer(u16("TaskbarButtonCreated"))))))

	cursor, _, _ := pLoadCursorW.Call(0, idcArrow)
	brush, _, _ := pCreateSolidBrush.Call(0x000D0907) // COLORREF 0x00BBGGRR
	cls := u16("CassetteDeckHost")
	wc := wndClassEx{
		WndProc: wndProcCB, Instance: host.hinst, Icon: host.iconBig, IconSm: host.iconSm,
		Cursor: cursor, Background: brush, ClassName: cls,
	}
	wc.Size = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	mode := readMode()
	switch {
	case forceMode != "":
		mode = forceMode
	case mode == "essai":
		hostLog("le lancement précédent en fenêtre native n'a pas abouti")
		mode = "edge"
		writeMode("edge")
	}
	host.native = mode != "edge"
	nativeActive = host.native
	host.url = pageURL + "&native=1"

	x, y, w, h := initialRect()
	hwnd, _, err := pCreateWindowExW.Call(wsExAppWindow, uintptr(unsafe.Pointer(cls)), uintptr(unsafe.Pointer(u16(AppName))),
		wsPopup|wsSysMenu|wsMinimizeBox|wsClipChildren, uintptr(x), uintptr(y), uintptr(w), uintptr(h), 0, 0, host.hinst, 0)
	if hwnd == 0 {
		messageBox(AppName, "Impossible de créer la fenêtre : "+err.Error(), mbIconError)
		return
	}
	host.hwnd = hwnd
	host.lastW = w
	applyRegion(w, h)
	trayAdd()
	exitHooks = append(exitHooks, trayRemove)

	hostLog("--- démarrage %s %s (mode %q)", AppName, AppVersion, mode)
	if host.native {
		writeMode("essai")
		if err := startWebView(); err != nil {
			fallbackEdge(err.Error())
		}
	} else {
		startEdge()
	}

	var m msgT
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
	trayRemove()
}

func must(r, _ uintptr, _ error) uintptr { return r }

func hostLogf(format string, a ...any) { hostLog(format, a...) }

// applyUpdate lance l'installateur téléchargé en mode silencieux puis quitte ;
// l'installateur relance le lecteur une fois la mise à jour faite.
func applyUpdate(file string) error {
	hostLog("installation de la mise à jour : %s", file)
	c := exec.Command(file, "/S", "/relaunch")
	if err := c.Start(); err != nil {
		return fmt.Errorf("impossible de lancer l'installateur : %v", err)
	}
	go func() {
		time.Sleep(400 * time.Millisecond)
		post(quitHost)
		time.Sleep(5 * time.Second)
		shutdown(0)
	}()
	return nil
}

// hostCommand traite les demandes de la page (/api/win).
func hostCommand(cmd string, q url.Values) map[string]any {
	switch cmd {
	case "info":
		return map[string]any{"native": host.native, "mode": readMode()}
	case "show":
		post(showMain)
	case "min":
		post(func() { procShowWindow.Call(host.hwnd, swMinimize) })
	case "hide":
		post(func() { procShowWindow.Call(host.hwnd, swHide) })
	case "close":
		post(quitHost)
	case "size":
		if v, err := strconv.Atoi(q.Get("w")); err == nil && host.native {
			post(func() { resizeTo(int32(v) * dpi() / 96) })
		}
	case "zoom":
		if host.native {
			f := 1.1
			if q.Get("d") == "-1" {
				f = 1 / 1.1
			}
			post(func() {
				var r rect
				pGetWindowRect.Call(host.hwnd, uintptr(unsafe.Pointer(&r)))
				resizeTo(int32(float64(r.Right-r.Left) * f))
			})
		}
	case "state":
		p, _ := strconv.ParseFloat(q.Get("prog"), 64)
		host.smu.Lock()
		host.state = PlayerState{Playing: q.Get("playing") == "1", Live: q.Get("live") == "1",
			Recording: q.Get("rec") == "1", Title: q.Get("title"), Progress: math.Max(0, math.Min(1, p))}
		host.smu.Unlock()
		post(updateTaskbar)
	case "mode":
		v := q.Get("v")
		if v != "edge" && v != "natif" {
			return map[string]any{"error": "mode inconnu"}
		}
		writeMode(v)
		post(restartApp)
	}
	return map[string]any{"ok": true, "native": host.native}
}

func restartApp() {
	exe, err := os.Executable()
	if err != nil {
		return
	}
	os.Remove(instanceFile())
	c := exec.Command(exe, "--restart")
	c.Start()
	quitHost()
}

func openExternal(u string) {
	exec.Command("rundll32.exe", "url.dll,FileProtocolHandler", u).Start()
}

func openFolder(d string) {
	exec.Command("explorer.exe", d).Start()
}
