//go:build !windows

package main

import (
	"errors"
	"log"
	"net/url"
	"time"
)

const (
	mbOK        = 0
	mbIconError = 0x10
)

func messageBox(title, text string, flags uint32) int { log.Println(title + ": " + text); return 0 }
func pickDialog(mode string) ([]string, error) {
	return nil, errors.New("dialogue indisponible hors Windows")
}
func launchUI(url, profile string) (func(), error) { log.Println("Ouvrir :", url); return nil, nil }
func focusWindow(prefix string)                    {}
func revealInExplorer(p string)                    {}
func uninstall()                                   { log.Println("désinstallation : Windows uniquement") }

func runUI(u, profile string) {
	start := time.Now()
	log.Println("Ouvrir :", u)
	waitHeartbeats(start)
	select {}
}
func firstBeat()                                          {}
func hostCommand(cmd string, q url.Values) map[string]any { return map[string]any{"native": false} }
func openExternal(u string)                               { log.Println("ouvrir", u) }
func openFolder(d string)                                 { log.Println("dossier", d) }
func hostLogf(format string, a ...any)                    { log.Printf(format, a...) }
func applyUpdate(file string) error                       { log.Println("appliquer", file); return nil }
