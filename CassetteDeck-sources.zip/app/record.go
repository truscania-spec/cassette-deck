package main

// Enregistrement de la radio (découpage par titre) et historique des titres.

import (
	"encoding/json"
	"fmt"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strings"
	"sync"
	"time"
	"unicode/utf16"
)

// ------------------------------------------------------------------ enregistreur

type recorder struct {
	mu      sync.Mutex
	on      bool
	split   bool
	station string
	ext     string
	title   string
	f       *os.File
	file    string
	started time.Time
	files   int
	bytes   int64
}

var rec = &recorder{split: true}

func recordDir() string {
	base := defaultMusicDir()
	if base == "" {
		home, _ := os.UserHomeDir()
		base = home
	}
	return filepath.Join(base, AppName, "Enregistrements")
}

func safeName(s string) string {
	s = strings.Map(func(r rune) rune {
		if r < 32 || strings.ContainsRune(`\/:*?"<>|`, r) {
			return '_'
		}
		return r
	}, s)
	s = strings.Trim(strings.TrimSpace(s), ". ")
	if r := []rune(s); len(r) > 110 {
		s = string(r[:110])
	}
	if s == "" {
		s = "Sans titre"
	}
	return s
}

func utf16Bytes(s string) []byte {
	u := utf16.Encode([]rune(s))
	b := []byte{0xFF, 0xFE}
	for _, v := range u {
		b = append(b, byte(v), byte(v>>8))
	}
	return append(b, 0, 0)
}

// id3Tag fabrique une étiquette ID3v2.3 minimale (titre, artiste, album).
func id3Tag(title, artist, album string) []byte {
	var frames []byte
	add := func(id, v string) {
		if v == "" {
			return
		}
		body := append([]byte{1}, utf16Bytes(v)...)
		n := len(body)
		frames = append(frames, id...)
		frames = append(frames, byte(n>>24), byte(n>>16), byte(n>>8), byte(n), 0, 0)
		frames = append(frames, body...)
	}
	add("TIT2", title)
	add("TPE1", artist)
	add("TALB", album)
	frames = append(frames, make([]byte, 256)...) // remplissage
	n := len(frames)
	h := []byte{'I', 'D', '3', 3, 0, 0, byte(n >> 21 & 0x7f), byte(n >> 14 & 0x7f), byte(n >> 7 & 0x7f), byte(n & 0x7f)}
	return append(h, frames...)
}

func (r *recorder) closeFile() {
	if r.f != nil {
		r.f.Close()
		// un fichier minuscule (changement de titre immédiat) n'a pas d'intérêt
		if st, err := os.Stat(r.file); err == nil && st.Size() < 24*1024 {
			os.Remove(r.file)
		} else {
			r.files++
		}
		r.f = nil
	}
}

func (r *recorder) start(station string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.closeFile()
	r.on, r.station, r.started, r.files, r.bytes, r.file = true, station, time.Now(), 0, 0, ""
}

func (r *recorder) stop() {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.closeFile()
	r.on = false
}

// newTitle est appelé à chaque changement de titre ICY.
func (r *recorder) newTitle(t string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	r.title = t
	if r.on && r.split {
		r.closeFile()
	}
}

func (r *recorder) write(p []byte, ext string) {
	r.mu.Lock()
	defer r.mu.Unlock()
	if !r.on {
		return
	}
	if r.f == nil {
		dir := filepath.Join(recordDir(), safeName(r.station))
		if err := os.MkdirAll(dir, 0o755); err != nil {
			r.on = false
			return
		}
		name := time.Now().Format("2006-01-02 15h04")
		if r.title != "" {
			name += " - " + r.title
		} else {
			name += " - " + r.station
		}
		path := filepath.Join(dir, safeName(name)+ext)
		for i := 2; ; i++ {
			if _, err := os.Stat(path); err != nil {
				break
			}
			path = filepath.Join(dir, safeName(name)+fmt.Sprintf(" (%d)", i)+ext)
		}
		f, err := os.Create(path)
		if err != nil {
			r.on = false
			return
		}
		r.f, r.file, r.ext = f, path, ext
		if ext == ".mp3" {
			artist, title := "", r.title
			if a, t, ok := strings.Cut(r.title, " - "); ok {
				artist, title = strings.TrimSpace(a), strings.TrimSpace(t)
			}
			if title == "" {
				title = r.station
			}
			f.Write(id3Tag(title, artist, r.station))
		}
	}
	n, err := r.f.Write(p)
	r.bytes += int64(n)
	if err != nil {
		r.closeFile()
		r.on = false
	}
}

func (r *recorder) status() map[string]any {
	r.mu.Lock()
	defer r.mu.Unlock()
	el := 0.0
	if r.on {
		el = time.Since(r.started).Seconds()
	}
	return map[string]any{"recording": r.on, "file": filepath.Base(r.file), "files": r.files,
		"bytes": r.bytes, "elapsed": el, "dir": recordDir(), "split": r.split}
}

// ------------------------------------------------------------------ historique

type HistItem struct {
	Time    time.Time `json:"time"`
	Station string    `json:"station"`
	Title   string    `json:"title"`
}

var (
	histMu sync.Mutex
	hist   []HistItem
	histOK bool
)

func histFile() string { return filepath.Join(dataDir(), "historique.json") }

func loadHist() {
	if histOK {
		return
	}
	histOK = true
	if b, err := os.ReadFile(histFile()); err == nil {
		json.Unmarshal(b, &hist)
	}
}

func addHistory(station, title string) {
	if title == "" {
		return
	}
	histMu.Lock()
	defer histMu.Unlock()
	loadHist()
	if n := len(hist); n > 0 && hist[n-1].Title == title && hist[n-1].Station == station {
		return
	}
	hist = append(hist, HistItem{time.Now(), station, title})
	if len(hist) > 500 {
		hist = hist[len(hist)-500:]
	}
	b, _ := json.Marshal(hist)
	os.WriteFile(histFile(), b, 0o644)
}

func recordRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/api/radio/rec", authed(func(w http.ResponseWriter, r *http.Request) {
		q := r.URL.Query()
		if q.Has("split") {
			rec.mu.Lock()
			rec.split = q.Get("split") == "1"
			rec.mu.Unlock()
		}
		switch q.Get("on") {
		case "1":
			name := strings.TrimSpace(q.Get("name"))
			if name == "" {
				name = "Radio"
			}
			radioNow.Lock()
			t := radioNow.title
			radioNow.Unlock()
			rec.start(name)
			rec.mu.Lock()
			rec.title = t
			rec.mu.Unlock()
		case "0":
			rec.stop()
		}
		writeJSON(w, rec.status())
	}))

	mux.HandleFunc("/api/radio/history", authed(func(w http.ResponseWriter, r *http.Request) {
		histMu.Lock()
		defer histMu.Unlock()
		loadHist()
		if r.URL.Query().Get("clear") == "1" {
			hist = nil
			os.Remove(histFile())
		}
		out := make([]HistItem, 0, len(hist))
		for i := len(hist) - 1; i >= 0; i-- {
			out = append(out, hist[i])
		}
		writeJSON(w, map[string]any{"items": out})
	}))

	// Recherche web d'un titre (ouverte dans le navigateur par défaut)
	mux.HandleFunc("/api/websearch", authed(func(w http.ResponseWriter, r *http.Request) {
		q := strings.TrimSpace(r.URL.Query().Get("q"))
		var u string
		switch r.URL.Query().Get("s") {
		case "youtube":
			u = "https://www.youtube.com/results?search_query=" + url.QueryEscape(q)
		case "spotify":
			u = "https://open.spotify.com/search/" + url.PathEscape(q)
		case "deezer":
			u = "https://www.deezer.com/search/" + url.PathEscape(q)
		default:
			u = "https://www.google.com/search?q=" + url.QueryEscape(q)
		}
		if q != "" {
			openExternal(u)
		}
		writeJSON(w, map[string]any{"ok": true})
	}))

	mux.HandleFunc("/api/recdir", authed(func(w http.ResponseWriter, r *http.Request) {
		d := recordDir()
		os.MkdirAll(d, 0o755)
		openFolder(d)
		writeJSON(w, map[string]any{"ok": true, "dir": d})
	}))
}
