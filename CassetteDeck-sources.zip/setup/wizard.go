//go:build windows

package main

// Assistant d'installation : Bienvenue › Licence › Dossier et options ›
// Installation › Terminé. Fenêtre Win32 classique avec bandeau illustré.

import (
	"fmt"
	"path/filepath"
	"strings"
	"sync"
	"syscall"
	"unsafe"
)

// Identifiants des contrôles
const (
	idBack = 100 + iota
	idNext
	idCancel
	idAccept
	idRefuse
	idPath
	idBrowse
	idOptDesktop
	idOptOpenWith
	idOptUpdate
	idOptStartup
	idLaunch
	idVersion
	idTitle
	idProgress
	idStatus
	idLicence
)

const (
	pgWelcome = iota
	pgLicence
	pgOptions
	pgInstall
	pgDone
)

const (
	wmProgress = wmApp + 1
	wmFinished = wmApp + 2
	// dimensions logiques (96 ppp)
	cw, ch   = 620, 420
	bannerW  = 180
	barTop   = 360
	contentX = 200
	contentW = 404
)

var wz struct {
	hwnd      uintptr
	hinst     uintptr
	dpi       int32
	page      int
	opts      options
	installed string
	banner    uintptr
	fontText  uintptr
	fontTitle uintptr
	fontSmall uintptr
	ctl       map[int]uintptr   // contrôles par identifiant
	pages     map[int][]uintptr // contrôles propres à chaque page
	titles    map[uintptr]bool
	grey      map[uintptr]bool

	mu     sync.Mutex
	status string
	err    error
	busy   bool
}

var wndProcCB = syscall.NewCallback(wizProc)

func sc(v int32) int32 { return v * wz.dpi / 96 }

func mkFont(pt int32, weight int32) uintptr {
	h := -(pt * wz.dpi / 72)
	f, _, _ := pCreateFontW.Call(uintptr(h), 0, 0, 0, uintptr(weight), 0, 0, 0, 1, 0, 0, 5, 0, up("Segoe UI"))
	return f
}

// add crée un contrôle enfant aux coordonnées logiques indiquées.
func add(page, id int, class, text string, style uint32, x, y, w, h int32, font uintptr) uintptr {
	ex := uintptr(0)
	if class == "EDIT" && style&esReadOnly == 0 {
		ex = wsExClientEdge
	}
	if class == "EDIT" && style&esMultiline != 0 {
		ex = wsExClientEdge
	}
	hw, _, _ := pCreateWindowExW.Call(ex, up(class), up(text), uintptr(wsChild|style),
		uintptr(sc(x)), uintptr(sc(y)), uintptr(sc(w)), uintptr(sc(h)), wz.hwnd, uintptr(id), wz.hinst, 0)
	if font == 0 {
		font = wz.fontText
	}
	pSendMessageW.Call(hw, wmSetFont, font, 1)
	if id != 0 {
		wz.ctl[id] = hw
	}
	if page >= 0 {
		wz.pages[page] = append(wz.pages[page], hw)
	}
	return hw
}

func title(page int, text string) {
	h := add(page, 0, "STATIC", text, ssNoPrefix, contentX, 22, contentW, 58, wz.fontTitle)
	wz.titles[h] = true
}

func label(page int, text string, x, y, w, h int32) uintptr {
	return add(page, 0, "STATIC", text, ssNoPrefix, x, y, w, h, 0)
}

func checkbox(page, id int, text string, y, h int32, checked bool) {
	st := uint32(bsAutoCheck | wsTabStop)
	if h > 24 {
		st |= bsMultiline
	}
	c := add(page, id, "BUTTON", text, st, contentX, y, contentW, h, 0)
	if checked {
		pSendMessageW.Call(c, bmSetCheck, 1, 0)
	}
}

func checked(id int) bool {
	r, _, _ := pSendMessageW.Call(wz.ctl[id], bmGetCheck, 0, 0)
	return r == 1
}

func getText(id int) string {
	h := wz.ctl[id]
	n, _, _ := pGetWindowTextLenW.Call(h)
	buf := make([]uint16, n+2)
	pGetWindowTextW.Call(h, uintptr(unsafe.Pointer(&buf[0])), n+1)
	return syscall.UTF16ToString(buf)
}

func setText(h uintptr, s string) { pSetWindowTextW.Call(h, up(s)) }
func show(h uintptr, on bool) {
	if on {
		pShowWindow.Call(h, swShow)
	} else {
		pShowWindow.Call(h, swHide)
	}
}
func enable(h uintptr, on bool) {
	v := uintptr(0)
	if on {
		v = 1
	}
	pEnableWindow.Call(h, v)
}

func buildControls() {
	upd := wz.installed != ""

	// ---- Bienvenue
	if upd {
		title(pgWelcome, "Mise à jour de Cassette Deck")
		label(pgWelcome, fmt.Sprintf("Cassette Deck %s est installé sur cet ordinateur.\r\n\r\n"+
			"Cet assistant va le mettre à jour vers la version %s. Vos listes de lecture, "+
			"vos stations favorites, votre historique et vos réglages sont conservés.\r\n\r\n"+
			"Cassette Deck sera fermé pendant la mise à jour s'il est ouvert.\r\n\r\n"+
			"Cliquez sur Suivant pour continuer.", wz.installed, appVersion), contentX, 92, contentW, 250)
	} else {
		title(pgWelcome, "Bienvenue dans l'installation de Cassette Deck")
		label(pgWelcome, fmt.Sprintf("Cet assistant va installer Cassette Deck %s, le mini lecteur audio "+
			"au style cassette, sur votre ordinateur.\r\n\r\n"+
			"• Spectre et VU-mètres en temps réel, bobines animées\r\n"+
			"• Vos fichiers audio et des milliers de radios en ligne\r\n"+
			"• Égaliseur 10 bandes, enregistrement de la radio\r\n\r\n"+
			"Aucun droit administrateur n'est nécessaire : le lecteur est installé pour votre "+
			"compte Windows uniquement.\r\n\r\n"+
			"Cliquez sur Suivant pour continuer.", appVersion), contentX, 92, contentW, 250)
	}

	// ---- Licence
	title(pgLicence, "Contrat de licence")
	label(pgLicence, "Veuillez lire le contrat de licence ci-dessous avant d'installer Cassette Deck.", contentX, 56, contentW, 36)
	add(pgLicence, idLicence, "EDIT", crlf(licenceText), esMultiline|esReadOnly|esAutoVScrl|wsVScroll|wsTabStop, contentX, 92, contentW, 196, wz.fontSmall)
	add(pgLicence, idAccept, "BUTTON", "J'accepte les termes du contrat de licence", bsAutoRadio|wsTabStop|wsGroup, contentX, 296, contentW, 24, 0)
	add(pgLicence, idRefuse, "BUTTON", "Je n'accepte pas les termes du contrat de licence", bsAutoRadio, contentX, 322, contentW, 24, 0)
	pSendMessageW.Call(wz.ctl[idRefuse], bmSetCheck, 1, 0)

	// ---- Dossier et options
	title(pgOptions, "Dossier et options")
	label(pgOptions, "Dossier d'installation :", contentX, 60, contentW, 20)
	add(pgOptions, idPath, "EDIT", wz.opts.Dir, esAutoHScrl|wsTabStop, contentX, 82, 296, 26, 0)
	add(pgOptions, idBrowse, "BUTTON", "Parcourir…", bsPush|wsTabStop, 506, 81, 98, 28, 0)
	g := label(pgOptions, fmt.Sprintf("Espace requis : %.1f Mo", float64(len(payload))/1048576+0.1), contentX, 114, contentW, 20)
	wz.grey[g] = true
	checkbox(pgOptions, idOptDesktop, "Créer un raccourci sur le Bureau", 148, 24, wz.opts.Desktop)
	checkbox(pgOptions, idOptOpenWith, "Proposer Cassette Deck dans « Ouvrir avec » pour les fichiers audio", 176, 24, wz.opts.OpenWith)
	checkbox(pgOptions, idOptUpdate, "Rechercher automatiquement les mises à jour", 204, 24, wz.opts.AutoUpdate)
	checkbox(pgOptions, idOptStartup, "Lancer Cassette Deck au démarrage de Windows (réduit dans la zone de notification)", 232, 40, wz.opts.Startup)
	g = label(pgOptions, "Les raccourcis du menu Démarrer sont toujours créés. Ces options pourront être modifiées en relançant cet assistant.", contentX, 290, contentW, 40)
	wz.grey[g] = true

	// ---- Installation
	title(pgInstall, "Installation en cours")
	wz.ctl[idStatus] = label(pgInstall, "Préparation…", contentX, 92, contentW, 22)
	add(pgInstall, idProgress, "msctls_progress32", "", 0, contentX, 122, contentW, 22, 0)
	pSendMessageW.Call(wz.ctl[idProgress], pbmSetRange32, 0, 100)

	// ---- Terminé
	title(pgDone, "Installation terminée")
	doneText := "Cassette Deck a été installé avec succès.\r\n\r\n" +
		"Vous le trouverez dans le menu Démarrer"
	if wz.opts.Desktop {
		doneText += " et sur le Bureau"
	}
	doneText += ".\r\n\r\nPour le désinstaller : Paramètres › Applications › Applications installées › Cassette Deck."
	if upd {
		doneText = fmt.Sprintf("Cassette Deck a été mis à jour vers la version %s.", appVersion)
	}
	wz.ctl[idStatus+1000] = label(pgDone, doneText, contentX, 92, contentW, 130)
	checkbox(pgDone, idLaunch, "Lancer Cassette Deck maintenant", 236, 24, true)

	// ---- Barre du bas
	v := add(-1, idVersion, "STATIC", "Cassette Deck "+appVersion, ssNoPrefix|wsVisible, 14, 384, 170, 20, wz.fontSmall)
	wz.grey[v] = true
	add(-1, idBack, "BUTTON", "< Précédent", bsPush|wsTabStop|wsVisible, 296, 377, 96, 28, 0)
	add(-1, idNext, "BUTTON", "Suivant >", bsDefPush|wsTabStop|wsVisible, 398, 377, 96, 28, 0)
	add(-1, idCancel, "BUTTON", "Annuler", bsPush|wsTabStop|wsVisible, 510, 377, 96, 28, 0)
}

func setPage(p int) {
	wz.page = p
	for pg, list := range wz.pages {
		for _, h := range list {
			show(h, pg == p)
		}
	}
	back, next, cancel := wz.ctl[idBack], wz.ctl[idNext], wz.ctl[idCancel]
	show(back, p != pgWelcome && p != pgDone)
	enable(back, p != pgInstall)
	show(cancel, p != pgDone)
	enable(cancel, p != pgInstall)
	switch p {
	case pgWelcome:
		setText(next, "Suivant >")
		enable(next, true)
	case pgLicence:
		setText(next, "Suivant >")
		enable(next, checked(idAccept))
	case pgOptions:
		setText(next, "Installer")
		enable(next, true)
	case pgInstall:
		enable(next, false)
	case pgDone:
		setText(next, "Terminer")
		enable(next, true)
	}
	pSetFocus.Call(next)
	pInvalidateRect.Call(wz.hwnd, 0, 1)
}

func browse() {
	var bi browseInfo
	name := make([]uint16, 260)
	bi.Owner = wz.hwnd
	bi.DisplayName = &name[0]
	bi.Title = u16("Choisissez le dossier où installer Cassette Deck :")
	bi.Flags = 0x1 | 0x40 // BIF_RETURNONLYFSDIRS | BIF_NEWDIALOGSTYLE
	pidl, _, _ := pSHBrowseForFolder.Call(uintptr(unsafe.Pointer(&bi)))
	if pidl == 0 {
		return
	}
	buf := make([]uint16, 520)
	pSHGetPathFromIDL.Call(pidl, uintptr(unsafe.Pointer(&buf[0])))
	pCoTaskMemFree.Call(pidl)
	d := syscall.UTF16ToString(buf)
	if d == "" {
		return
	}
	if !strings.EqualFold(filepath.Base(d), appID) {
		d = filepath.Join(d, appID)
	}
	setText(wz.ctl[idPath], d)
}

func startInstall() {
	d := strings.TrimSpace(getText(idPath))
	if d == "" || !filepath.IsAbs(d) {
		msg(wz.hwnd, "Indiquez un dossier d'installation complet, par exemple :\n"+wz.opts.Dir, mbOK|mbIconWarning)
		return
	}
	wz.opts.Dir = filepath.Clean(d)
	wz.opts.Desktop = checked(idOptDesktop)
	wz.opts.OpenWith = checked(idOptOpenWith)
	wz.opts.AutoUpdate = checked(idOptUpdate)
	wz.opts.Startup = checked(idOptStartup)
	setPage(pgInstall)
	wz.busy = true
	o := wz.opts
	go func() {
		err := doInstall(o, func(pct int, s string) {
			wz.mu.Lock()
			wz.status = s
			wz.mu.Unlock()
			pPostMessageW.Call(wz.hwnd, wmProgress, uintptr(pct), 0)
		})
		wz.mu.Lock()
		wz.err = err
		wz.mu.Unlock()
		pPostMessageW.Call(wz.hwnd, wmFinished, 0, 0)
	}()
}

func confirmQuit() bool {
	return msg(wz.hwnd, "Voulez-vous vraiment quitter l'installation de Cassette Deck ?", mbYesNo|mbIconQuest) == idYes
}

func onCommand(id int) {
	switch id {
	case idAccept, idRefuse:
		if wz.page == pgLicence {
			enable(wz.ctl[idNext], checked(idAccept))
		}
	case idBrowse:
		browse()
	case idBack:
		if wz.page > pgWelcome && wz.page <= pgOptions {
			setPage(wz.page - 1)
		}
	case idNext:
		switch wz.page {
		case pgWelcome:
			setPage(pgLicence)
		case pgLicence:
			if checked(idAccept) {
				setPage(pgOptions)
			}
		case pgOptions:
			startInstall()
		case pgDone:
			if checked(idLaunch) {
				launch(wz.opts.Dir)
			}
			pDestroyWindow.Call(wz.hwnd)
		}
	case idCancel:
		if !wz.busy && confirmQuit() {
			pDestroyWindow.Call(wz.hwnd)
		}
	}
}

func paint() {
	var ps paintStruct
	hdc, _, _ := pBeginPaint.Call(wz.hwnd, uintptr(unsafe.Pointer(&ps)))
	// bandeau
	if wz.banner != 0 {
		mem, _, _ := pCreateCompatibleDC.Call(hdc)
		old, _, _ := pSelectObject.Call(mem, wz.banner)
		pSetStretchBltMode.Call(hdc, 4) // HALFTONE
		pSetBrushOrgEx.Call(hdc, 0, 0, 0)
		pStretchBlt.Call(hdc, 0, 0, uintptr(sc(bannerW)), uintptr(sc(barTop)), mem, 0, 0, 360, 720, 0x00CC0020)
		pSelectObject.Call(mem, old)
		pDeleteDC.Call(mem)
	}
	// barre du bas
	face, _, _ := pGetSysColorBrush.Call(15)   // COLOR_BTNFACE
	shadow, _, _ := pGetSysColorBrush.Call(16) // COLOR_BTNSHADOW
	hilite, _, _ := pGetSysColorBrush.Call(20) // COLOR_BTNHIGHLIGHT
	r := rect{0, sc(barTop), sc(cw), sc(ch)}
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&r)), face)
	l1 := rect{0, sc(barTop), sc(cw), sc(barTop) + 1}
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&l1)), shadow)
	l2 := rect{0, sc(barTop) + 1, sc(cw), sc(barTop) + 2}
	pFillRect.Call(hdc, uintptr(unsafe.Pointer(&l2)), hilite)
	pEndPaint.Call(wz.hwnd, uintptr(unsafe.Pointer(&ps)))
}

func wizProc(hwnd, m, wp, lp uintptr) uintptr {
	switch uint32(m) {
	case wmPaint:
		paint()
		return 0
	case wmCtlColorStatic:
		hdc, ctl := wp, lp
		pSetBkMode.Call(hdc, 1) // TRANSPARENT
		switch {
		case wz.titles[ctl]:
			pSetTextColor.Call(hdc, 0x000A50C0) // orange foncé (BGR)
		case wz.grey[ctl]:
			pSetTextColor.Call(hdc, 0x00707070)
		}
		if ctl == wz.ctl[idVersion] {
			b, _, _ := pGetSysColorBrush.Call(15)
			return b
		}
		b, _, _ := pGetStockObject.Call(0) // WHITE_BRUSH
		return b
	case wmCommand:
		if (wp>>16)&0xFFFF == 0 { // BN_CLICKED
			onCommand(int(wp & 0xFFFF))
		}
		return 0
	case wmProgress:
		wz.mu.Lock()
		s := wz.status
		wz.mu.Unlock()
		setText(wz.ctl[idStatus], s)
		pSendMessageW.Call(wz.ctl[idProgress], pbmSetPos, wp, 0)
		return 0
	case wmFinished:
		wz.busy = false
		wz.mu.Lock()
		err := wz.err
		wz.mu.Unlock()
		if err != nil {
			msg(wz.hwnd, "L'installation n'a pas pu se terminer :\n\n"+err.Error(), mbOK|mbIconError)
			setPage(pgOptions)
			return 0
		}
		if wz.installed == "" {
			t := "Cassette Deck a été installé avec succès.\r\n\r\nVous le trouverez dans le menu Démarrer"
			if wz.opts.Desktop {
				t += " et sur le Bureau"
			}
			t += ".\r\n\r\nPour le désinstaller : Paramètres › Applications › Applications installées › Cassette Deck."
			setText(wz.ctl[idStatus+1000], t)
		}
		setPage(pgDone)
		return 0
	case wmClose:
		if !wz.busy && (wz.page == pgDone || confirmQuit()) {
			pDestroyWindow.Call(hwnd)
		}
		return 0
	case wmDestroy:
		pPostQuitMessage.Call(0)
		return 0
	}
	r, _, _ := pDefWindowProcW.Call(hwnd, m, wp, lp)
	return r
}

func runWizard(o options, installed string) {
	wz.opts, wz.installed = o, installed
	wz.ctl = map[int]uintptr{}
	wz.pages = map[int][]uintptr{}
	wz.titles = map[uintptr]bool{}
	wz.grey = map[uintptr]bool{}
	wz.dpi = 96
	if pGetDpiForSystem.Find() == nil {
		if d, _, _ := pGetDpiForSystem.Call(); d > 0 {
			wz.dpi = int32(d)
		}
	}
	pCoInitializeEx.Call(0, 0x2)
	icc := initCommonControls{ICC: 0x20 | 0x4000} // ICC_PROGRESS_CLASS | ICC_STANDARD_CLASSES
	icc.Size = uint32(unsafe.Sizeof(icc))
	pInitCommonControlsEx.Call(uintptr(unsafe.Pointer(&icc)))

	wz.hinst, _, _ = pGetModuleHandleW.Call(0)
	wz.banner, _, _ = pLoadImageW.Call(wz.hinst, 10, 0, 0, 0, 0x2000) // IMAGE_BITMAP, LR_CREATEDIBSECTION
	wz.fontText = mkFont(9, 400)
	wz.fontSmall = mkFont(8, 400)
	wz.fontTitle = mkFont(15, 600)

	icon, _, _ := pLoadImageW.Call(wz.hinst, 1, 1, 32, 32, 0)
	iconSm, _, _ := pLoadImageW.Call(wz.hinst, 1, 1, 16, 16, 0)
	cursor, _, _ := pLoadCursorW.Call(0, 32512)
	cls := u16("CassetteDeckSetup")
	wc := wndClassEx{WndProc: wndProcCB, Instance: wz.hinst, Icon: icon, IconSm: iconSm, Cursor: cursor,
		Background: 5 + 1, ClassName: cls} // COLOR_WINDOW + 1
	wc.Size = uint32(unsafe.Sizeof(wc))
	pRegisterClassExW.Call(uintptr(unsafe.Pointer(&wc)))

	style := uint32(wsCaption | wsSysMenu | wsMinimizeBox | wsClipChildren)
	r := rect{0, 0, sc(cw), sc(ch)}
	pAdjustWindowRectEx.Call(uintptr(unsafe.Pointer(&r)), uintptr(style), 0, 0)
	w, h := r.Right-r.Left, r.Bottom-r.Top
	sw, _, _ := pGetSystemMetrics.Call(0)
	sh, _, _ := pGetSystemMetrics.Call(1)
	titleTxt := "Installation de Cassette Deck " + appVersion
	if installed != "" {
		titleTxt = "Mise à jour de Cassette Deck " + appVersion
	}
	hwnd, _, err := pCreateWindowExW.Call(0, uintptr(unsafe.Pointer(cls)), up(titleTxt), uintptr(style),
		uintptr((int32(sw)-w)/2), uintptr((int32(sh)-h)/2), uintptr(w), uintptr(h), 0, 0, wz.hinst, 0)
	if hwnd == 0 {
		msg(0, "Impossible d'afficher l'assistant : "+err.Error(), mbOK|mbIconError)
		return
	}
	wz.hwnd = hwnd
	buildControls()
	setPage(pgWelcome)
	pShowWindow.Call(hwnd, swShow)
	pUpdateWindow.Call(hwnd)
	pSetForegroundWindow.Call(hwnd)

	var m msgT
	for {
		r, _, _ := pGetMessageW.Call(uintptr(unsafe.Pointer(&m)), 0, 0, 0)
		if int32(r) <= 0 {
			break
		}
		if d, _, _ := pIsDialogMessageW.Call(hwnd, uintptr(unsafe.Pointer(&m))); d != 0 {
			continue
		}
		pTranslateMessage.Call(uintptr(unsafe.Pointer(&m)))
		pDispatchMessageW.Call(uintptr(unsafe.Pointer(&m)))
	}
}
