"""Bandeau vertical de l'assistant d'installation (BMP 24 bits, 2x : 360x720)."""
import sys
from pathlib import Path
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ASSETS = Path(sys.argv[1])   # app/ui/assets
OUT = Path(sys.argv[2])      # res/banner.bmp
W, H = 360, 720

bg = Image.new("RGB", (W, H))
d = ImageDraw.Draw(bg)
for y in range(H):  # dégradé sombre, chaud vers le bas
    t = y / H
    d.line([(0, y), (W, y)], fill=(int(9 + 20 * t), int(11 + 8 * t), int(16 - 4 * t)))
img = bg.convert("RGBA")

# halo orange derrière la bobine
glow = Image.new("RGBA", (W, H), (0, 0, 0, 0))
ImageDraw.Draw(glow).ellipse([W / 2 - 150, 120, W / 2 + 150, 420], outline=(255, 120, 20, 255), width=10)
glow = glow.filter(ImageFilter.GaussianBlur(14))
img.alpha_composite(glow)
ring = Image.new("RGBA", (W, H), (0, 0, 0, 0))
ImageDraw.Draw(ring).ellipse([W / 2 - 146, 124, W / 2 + 146, 416], outline=(255, 150, 40, 255), width=3)
img.alpha_composite(ring)

# bobinage + bobine du lecteur
pack = Image.new("RGBA", (W, H), (0, 0, 0, 0))
ImageDraw.Draw(pack).ellipse([W / 2 - 138, 132, W / 2 + 138, 408], fill=(44, 25, 15, 255))
img.alpha_composite(pack)
reel = Image.open(ASSETS / "reelL.png").convert("RGBA").resize((236, 236), Image.LANCZOS)
img.alpha_composite(reel, (int(W / 2 - 118), 152))

# petites barres de spectre en LED
leds = Image.new("RGBA", (W, H), (0, 0, 0, 0))
ld = ImageDraw.Draw(leds)
heights = [2, 4, 6, 5, 7, 6, 4, 6, 8, 6, 3, 5, 2]
bw, gap = 18, 7
x0 = (W - (len(heights) * (bw + gap) - gap)) / 2
for i, h in enumerate(heights):
    for s in range(8):
        y = 676 - s * 12
        col = (255, 170, 40, 255) if s < h else (255, 110, 20, 28)
        ld.rectangle([x0 + i * (bw + gap), y, x0 + i * (bw + gap) + bw, y + 7], fill=col)
bloom = leds.filter(ImageFilter.GaussianBlur(5))
img.alpha_composite(bloom)
img.alpha_composite(leds)

# titre
fdir = Path("/usr/share/fonts/truetype/google-fonts")
font_big = ImageFont.truetype(str(fdir / "Poppins-Bold.ttf"), 50)
font_small = ImageFont.truetype(str(fdir / "Poppins-Bold.ttf"), 23)
td = ImageDraw.Draw(img)
def center(text, y, font, fill, spacing=0):
    w = td.textlength(text, font=font) + spacing * (len(text) - 1)
    x = (W - w) / 2
    for ch in text:
        td.text((x, y), ch, font=font, fill=fill)
        x += td.textlength(ch, font=font) + spacing
center("CASSETTE", 448, font_big, (255, 160, 50), 4)
center("DECK", 506, font_small, (220, 222, 226), 14)
td.line([(W / 2 - 60, 548), (W / 2 + 60, 548)], fill=(255, 140, 30), width=2)

img.convert("RGB").save(OUT)
img.convert("RGB").save(OUT.with_suffix(".png"))
print("bandeau", OUT)
