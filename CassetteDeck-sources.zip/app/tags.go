package main

import (
	"encoding/binary"
	"io"
	"os"
	"strings"
	"unicode/utf16"
)

// readTags lit titre et artiste (ID3v2 pour MP3, commentaires Vorbis pour FLAC/OGG).
func readTags(path string) (title, artist string) {
	f, err := os.Open(path)
	if err != nil {
		return
	}
	defer f.Close()
	head := make([]byte, 10)
	if _, err := io.ReadFull(f, head); err != nil {
		return
	}
	switch {
	case string(head[:3]) == "ID3":
		return readID3(f, head)
	case string(head[:4]) == "fLaC":
		f.Seek(4, io.SeekStart)
		return readFLAC(f)
	case string(head[:4]) == "OggS":
		f.Seek(0, io.SeekStart)
		buf := make([]byte, 64*1024)
		n, _ := io.ReadFull(f, buf)
		return scanVorbis(buf[:n])
	}
	return
}

func synchsafe(b []byte) int {
	return int(b[0]&0x7f)<<21 | int(b[1]&0x7f)<<14 | int(b[2]&0x7f)<<7 | int(b[3]&0x7f)
}

func readID3(f *os.File, head []byte) (title, artist string) {
	ver := head[3]
	size := synchsafe(head[6:10])
	if size > 512*1024 {
		size = 512 * 1024
	}
	data := make([]byte, size)
	n, _ := io.ReadFull(f, data)
	data = data[:n]
	pos := 0
	if head[5]&0x40 != 0 && len(data) >= 4 { // en-tête étendu
		var ext int
		if ver == 4 {
			ext = synchsafe(data[:4])
		} else {
			ext = int(binary.BigEndian.Uint32(data[:4])) + 4
		}
		pos = ext
	}
	idLen, hdrLen := 4, 10
	if ver == 2 {
		idLen, hdrLen = 3, 6
	}
	for pos+hdrLen <= len(data) && (title == "" || artist == "") {
		id := string(data[pos : pos+idLen])
		if id[0] == 0 {
			break
		}
		var fsize int
		if ver == 2 {
			fsize = int(data[pos+3])<<16 | int(data[pos+4])<<8 | int(data[pos+5])
		} else if ver == 4 {
			fsize = synchsafe(data[pos+4 : pos+8])
		} else {
			fsize = int(binary.BigEndian.Uint32(data[pos+4 : pos+8]))
		}
		pos += hdrLen
		if fsize <= 0 || pos+fsize > len(data) {
			break
		}
		body := data[pos : pos+fsize]
		pos += fsize
		switch id {
		case "TIT2", "TT2":
			title = decodeID3Text(body)
		case "TPE1", "TP1":
			artist = decodeID3Text(body)
		}
	}
	return
}

func decodeID3Text(b []byte) string {
	if len(b) < 1 {
		return ""
	}
	enc, b := b[0], b[1:]
	var s string
	switch enc {
	case 0: // ISO-8859-1
		r := make([]rune, len(b))
		for i, c := range b {
			r[i] = rune(c)
		}
		s = string(r)
	case 1, 2: // UTF-16 (avec BOM) / UTF-16BE
		be := enc == 2
		if len(b) >= 2 {
			if b[0] == 0xFF && b[1] == 0xFE {
				be, b = false, b[2:]
			} else if b[0] == 0xFE && b[1] == 0xFF {
				be, b = true, b[2:]
			}
		}
		u := make([]uint16, 0, len(b)/2)
		for i := 0; i+1 < len(b); i += 2 {
			if be {
				u = append(u, uint16(b[i])<<8|uint16(b[i+1]))
			} else {
				u = append(u, uint16(b[i+1])<<8|uint16(b[i]))
			}
		}
		s = string(utf16.Decode(u))
	default: // UTF-8
		s = string(b)
	}
	if i := strings.IndexRune(s, 0); i >= 0 {
		s = s[:i]
	}
	return strings.TrimSpace(s)
}

func readFLAC(f *os.File) (title, artist string) {
	hdr := make([]byte, 4)
	for i := 0; i < 64; i++ {
		if _, err := io.ReadFull(f, hdr); err != nil {
			return
		}
		last := hdr[0]&0x80 != 0
		typ := hdr[0] & 0x7f
		size := int(hdr[1])<<16 | int(hdr[2])<<8 | int(hdr[3])
		if typ == 4 {
			if size > 1<<20 {
				return
			}
			b := make([]byte, size)
			if _, err := io.ReadFull(f, b); err != nil {
				return
			}
			return parseVorbisComments(b)
		}
		if _, err := f.Seek(int64(size), io.SeekCurrent); err != nil || last {
			return
		}
	}
	return
}

func parseVorbisComments(b []byte) (title, artist string) {
	if len(b) < 8 {
		return
	}
	vlen := int(binary.LittleEndian.Uint32(b))
	p := 4 + vlen
	if p+4 > len(b) {
		return
	}
	n := int(binary.LittleEndian.Uint32(b[p:]))
	p += 4
	for i := 0; i < n && p+4 <= len(b); i++ {
		l := int(binary.LittleEndian.Uint32(b[p:]))
		p += 4
		if l < 0 || p+l > len(b) {
			return
		}
		kv := string(b[p : p+l])
		p += l
		k, v, ok := strings.Cut(kv, "=")
		if !ok {
			continue
		}
		switch strings.ToUpper(k) {
		case "TITLE":
			if title == "" {
				title = strings.TrimSpace(v)
			}
		case "ARTIST":
			if artist == "" {
				artist = strings.TrimSpace(v)
			}
		}
	}
	return
}

// scanVorbis cherche le paquet de commentaires dans les premières pages Ogg.
func scanVorbis(buf []byte) (title, artist string) {
	for _, magic := range []string{"\x03vorbis", "OpusTags"} {
		if i := strings.Index(string(buf), magic); i >= 0 {
			return parseVorbisComments(buf[i+len(magic):])
		}
	}
	return
}
