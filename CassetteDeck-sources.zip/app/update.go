package main

// Mises à jour automatiques.
//
// Le lecteur lit un petit fichier « latest.json » publié par l'éditeur :
//
//	{ "version": "2.2.0", "url": "https://…/CassetteDeck-Setup.exe",
//	  "sha256": "…", "size": 11223344, "notes": "…", "sig": "…" }
//
// « sig » est une signature Ed25519 (clé privée détenue par l'éditeur) de
// "version\nurl\nsha256\nsize". La clé publique est intégrée au programme :
// un fichier modifié ou un serveur compromis ne peut pas faire installer
// autre chose que les mises à jour signées par l'éditeur.

import (
	"crypto/ed25519"
	"crypto/sha256"
	"encoding/base64"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
	"net/url"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"time"
)

// Renseignés à la compilation (build.sh) :
//
//	-X main.UpdateURL=https://…/latest.json -X main.UpdatePubKey=<base64>
var (
	UpdateURL    = ""
	UpdatePubKey = ""
)

type manifest struct {
	Version string `json:"version"`
	URL     string `json:"url"`
	SHA256  string `json:"sha256"`
	Size    int64  `json:"size"`
	Notes   string `json:"notes"`
	Sig     string `json:"sig"`
}

func (m *manifest) signedBytes() []byte {
	return []byte(m.Version + "\n" + m.URL + "\n" + strings.ToLower(m.SHA256) + "\n" + strconv.FormatInt(m.Size, 10))
}

// ------------------------------------------------------------------ réglages

type settings struct {
	AutoUpdate  bool   `json:"autoUpdate"`
	SkipVersion string `json:"skipVersion,omitempty"`
}

var setMu sync.Mutex

func settingsFile() string { return filepath.Join(dataDir(), "settings.json") }

func loadSettings() settings {
	setMu.Lock()
	defer setMu.Unlock()
	s := settings{AutoUpdate: true}
	if b, err := os.ReadFile(settingsFile()); err == nil {
		json.Unmarshal(b, &s)
	}
	return s
}

func saveSettings(s settings) {
	setMu.Lock()
	defer setMu.Unlock()
	m := map[string]any{}
	if b, err := os.ReadFile(settingsFile()); err == nil {
		json.Unmarshal(b, &m) // conserve les clés inconnues
	}
	m["autoUpdate"] = s.AutoUpdate
	m["skipVersion"] = s.SkipVersion
	b, _ := json.MarshalIndent(m, "", "  ")
	os.WriteFile(settingsFile(), b, 0o644)
}

// ------------------------------------------------------------------ état

var upd struct {
	sync.Mutex
	state    string // idle | checking | uptodate | available | downloading | ready | error | disabled
	latest   *manifest
	progress float64
	err      string
	file     string
	checked  time.Time
}

func updConfigured() bool { return UpdateURL != "" && UpdatePubKey != "" }

func setUpd(state, errMsg string) {
	upd.Lock()
	upd.state, upd.err = state, errMsg
	upd.Unlock()
}

func updStatus() map[string]any {
	upd.Lock()
	defer upd.Unlock()
	st := upd.state
	if st == "" {
		st = "idle"
	}
	if !updConfigured() {
		st = "disabled"
	}
	out := map[string]any{"state": st, "current": AppVersion, "progress": upd.progress, "error": upd.err,
		"auto": loadSettings().AutoUpdate}
	if upd.latest != nil {
		out["latest"] = upd.latest.Version
		out["notes"] = upd.latest.Notes
		out["size"] = upd.latest.Size
	}
	if !upd.checked.IsZero() {
		out["checked"] = upd.checked.Format(time.RFC3339)
	}
	return out
}

// newer indique si a > b (versions « 2.1.0 »).
func newer(a, b string) bool {
	pa, pb := strings.Split(strings.TrimPrefix(a, "v"), "."), strings.Split(strings.TrimPrefix(b, "v"), ".")
	for i := 0; i < 4; i++ {
		var x, y int
		if i < len(pa) {
			x, _ = strconv.Atoi(pa[i])
		}
		if i < len(pb) {
			y, _ = strconv.Atoi(pb[i])
		}
		if x != y {
			return x > y
		}
	}
	return false
}

var updClient = &http.Client{Timeout: 30 * time.Second}

func allowedURL(raw string) bool {
	u, err := url.Parse(raw)
	if err != nil {
		return false
	}
	if u.Scheme == "https" {
		return true
	}
	// http uniquement en local (tests)
	return u.Scheme == "http" && (u.Hostname() == "127.0.0.1" || u.Hostname() == "localhost")
}

func fetchManifest() (*manifest, error) {
	if !allowedURL(UpdateURL) {
		return nil, errors.New("adresse de mise à jour non sécurisée")
	}
	req, _ := http.NewRequest(http.MethodGet, UpdateURL, nil)
	req.Header.Set("User-Agent", "CassetteDeck/"+AppVersion)
	req.Header.Set("Cache-Control", "no-cache")
	resp, err := updClient.Do(req)
	if err != nil {
		return nil, errors.New("serveur de mises à jour injoignable")
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		return nil, fmt.Errorf("serveur de mises à jour : %s", resp.Status)
	}
	var m manifest
	if err := json.NewDecoder(io.LimitReader(resp.Body, 256*1024)).Decode(&m); err != nil {
		return nil, errors.New("fichier de mise à jour illisible")
	}
	pub, err := base64.StdEncoding.DecodeString(UpdatePubKey)
	if err != nil || len(pub) != ed25519.PublicKeySize {
		return nil, errors.New("clé de vérification invalide")
	}
	sig, err := base64.StdEncoding.DecodeString(m.Sig)
	if err != nil || !ed25519.Verify(ed25519.PublicKey(pub), m.signedBytes(), sig) {
		return nil, errors.New("signature de la mise à jour invalide : fichier refusé")
	}
	if !allowedURL(m.URL) || len(m.SHA256) != 64 || m.Size <= 0 {
		return nil, errors.New("fichier de mise à jour incomplet")
	}
	return &m, nil
}

// checkUpdate interroge le serveur ; manual = demandé par l'utilisateur.
func checkUpdate(manual bool) {
	if !updConfigured() {
		return
	}
	upd.Lock()
	if upd.state == "checking" || upd.state == "downloading" {
		upd.Unlock()
		return
	}
	upd.state, upd.err = "checking", ""
	upd.Unlock()

	m, err := fetchManifest()
	upd.Lock()
	upd.checked = time.Now()
	upd.Unlock()
	if err != nil {
		setUpd("error", err.Error())
		hostLogf("mise à jour : %v", err)
		return
	}
	if !newer(m.Version, AppVersion) {
		upd.Lock()
		upd.latest = m
		upd.state = "uptodate"
		upd.Unlock()
		return
	}
	upd.Lock()
	upd.latest = m
	upd.state = "available"
	upd.Unlock()
	if manual || loadSettings().SkipVersion != m.Version {
		events.emit("update")
	}
}

func downloadUpdate() {
	upd.Lock()
	m := upd.latest
	if m == nil || upd.state == "downloading" {
		upd.Unlock()
		return
	}
	upd.state, upd.progress, upd.err = "downloading", 0, ""
	upd.Unlock()

	fail := func(msg string) {
		setUpd("error", msg)
		hostLogf("téléchargement de la mise à jour : %s", msg)
	}
	dl := &http.Client{Timeout: 30 * time.Minute}
	req, _ := http.NewRequest(http.MethodGet, m.URL, nil)
	req.Header.Set("User-Agent", "CassetteDeck/"+AppVersion)
	resp, err := dl.Do(req)
	if err != nil {
		fail("téléchargement impossible (connexion ?)")
		return
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		fail("téléchargement refusé : " + resp.Status)
		return
	}
	dst := filepath.Join(os.TempDir(), "CassetteDeck-Setup-"+safeName(m.Version)+".exe")
	f, err := os.Create(dst)
	if err != nil {
		fail("impossible d'écrire le fichier temporaire")
		return
	}
	h := sha256.New()
	var n int64
	buf := make([]byte, 64*1024)
	for {
		k, rerr := resp.Body.Read(buf)
		if k > 0 {
			f.Write(buf[:k])
			h.Write(buf[:k])
			n += int64(k)
			if n > m.Size+1024 {
				break
			}
			upd.Lock()
			upd.progress = float64(n) / float64(m.Size)
			upd.Unlock()
		}
		if rerr != nil {
			break
		}
	}
	f.Close()
	if n != m.Size || !strings.EqualFold(hex.EncodeToString(h.Sum(nil)), m.SHA256) {
		os.Remove(dst)
		fail("fichier téléchargé corrompu (empreinte incorrecte)")
		return
	}
	upd.Lock()
	upd.file, upd.state, upd.progress = dst, "ready", 1
	upd.Unlock()
	hostLogf("mise à jour %s téléchargée et vérifiée", m.Version)
	events.emit("update")
}

func updateLoop() {
	time.Sleep(40 * time.Second)
	for {
		if updConfigured() && loadSettings().AutoUpdate {
			checkUpdate(false)
		}
		time.Sleep(24 * time.Hour)
	}
}

func updateRoutes(mux *http.ServeMux) {
	mux.HandleFunc("/api/update/status", authed(func(w http.ResponseWriter, r *http.Request) {
		writeJSON(w, updStatus())
	}))
	mux.HandleFunc("/api/update/check", authed(func(w http.ResponseWriter, r *http.Request) {
		checkUpdate(true)
		writeJSON(w, updStatus())
	}))
	mux.HandleFunc("/api/update/download", authed(func(w http.ResponseWriter, r *http.Request) {
		go downloadUpdate()
		time.Sleep(100 * time.Millisecond)
		writeJSON(w, updStatus())
	}))
	mux.HandleFunc("/api/update/apply", authed(func(w http.ResponseWriter, r *http.Request) {
		upd.Lock()
		file, st := upd.file, upd.state
		upd.Unlock()
		if st != "ready" || file == "" {
			writeJSON(w, map[string]any{"error": "aucune mise à jour prête"})
			return
		}
		if err := applyUpdate(file); err != nil {
			writeJSON(w, map[string]any{"error": err.Error()})
			return
		}
		writeJSON(w, map[string]any{"ok": true})
	}))
	mux.HandleFunc("/api/update/skip", authed(func(w http.ResponseWriter, r *http.Request) {
		s := loadSettings()
		upd.Lock()
		if upd.latest != nil {
			s.SkipVersion = upd.latest.Version
		}
		upd.Unlock()
		saveSettings(s)
		writeJSON(w, updStatus())
	}))
	mux.HandleFunc("/api/update/auto", authed(func(w http.ResponseWriter, r *http.Request) {
		s := loadSettings()
		s.AutoUpdate = r.URL.Query().Get("on") == "1"
		saveSettings(s)
		if s.AutoUpdate {
			go checkUpdate(false)
		}
		writeJSON(w, updStatus())
	}))
}
